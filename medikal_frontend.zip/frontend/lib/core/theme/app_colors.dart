import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Core Theme Colors (Slate-Teal Medical Theme)
  static const Color primary = Color(0xFF0F766E);      // Calm Teal 700
  static const Color secondary = Color(0xFF0EA5E9);    // Trusting Sky 500
  static const Color background = Color(0xFFF8FAFC);   // Slate 50 (Very clean, calm)
  static const Color card = Color(0xFFFFFFFF);         // Pure White surfaces
  static const Color emergency = Color(0xFFEF4444);    // Reassuring Coral-Red 500

  // Neutral Colors
  static const Color textPrimary = Color(0xFF0F172A);    // Slate 900 (High contrast)
  static const Color textSecondary = Color(0xFF475569);  // Slate 600 (Highly readable body)
  static const Color textMuted = Color(0xFF94A3B8);      // Slate 400 (Secondary details)
  static const Color border = Color(0xFFE2E8F0);         // Slate 200 (Clean divider/borders)

  // Status & Urgency Colors
  static const Color success = Color(0xFF10B981);       // Emerald 500 (Verification/Success)
  static const Color warning = Color(0xFFF59E0B);       // Amber 500 (Moderate Urgency)
  static const Color urgent = Color(0xFFF97316);        // Orange 500 (High Urgency)

  // Soft/Light Variant Colors for Banners and Tags
  static const Color primaryLight = Color(0xFFE6F4F1);   // Very light teal
  static const Color secondaryLight = Color(0xFFE0F2FE); // Very light sky blue
  static const Color emergencyLight = Color(0xFFFEE2E2); // Very light red
  static const Color successLight = Color(0xFFD1FAE5);   // Very light green
  static const Color warningLight = Color(0xFFFEF3C7);   // Very light amber
  static const Color urgentLight = Color(0xFFFFEDD5);    // Very light orange

  // Gradient Palettes
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primary, Color(0xFF0D9488)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient emergencyGradient = LinearGradient(
    colors: [emergency, Color(0xFFDC2626)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
