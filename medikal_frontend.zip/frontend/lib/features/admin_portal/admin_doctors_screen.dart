import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'admin_provider.dart';

class AdminDoctorsScreen extends ConsumerStatefulWidget {
  const AdminDoctorsScreen({super.key});

  @override
  ConsumerState<AdminDoctorsScreen> createState() => _AdminDoctorsScreenState();
}

class _AdminDoctorsScreenState extends ConsumerState<AdminDoctorsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Local Premium Dark Theme Configuration
  static const Color darkBg = Color(0xFF090D16);
  static const Color darkCard = Color(0xFF111827);
  static const Color darkBorder = Color(0xFF1F2937);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF9CA3AF);
  static const Color accentColor = Color(0xFF10B981); // Emerald

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final doctorsState = ref.watch(adminDoctorsProvider);
    final pendingState = ref.watch(pendingDoctorsProvider);

    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        title: const Text(
          'Manage Doctors',
          style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: accentColor),
            onPressed: () {
              ref.read(adminDoctorsProvider.notifier).fetchDoctors();
              ref.read(pendingDoctorsProvider.notifier).fetchPendingDoctors();
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: accentColor,
          unselectedLabelColor: textSecondary,
          indicatorColor: accentColor,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
          tabs: const [
            Tab(text: 'All Doctors'),
            Tab(text: 'Pending Verification'),
          ],
        ),
      ),
      body: SafeArea(
        child: TabBarView(
          controller: _tabController,
          children: [
            // Tab 1: All Doctors
            doctorsState.isLoading
                ? const Center(child: CircularProgressIndicator(color: accentColor))
                : doctorsState.error != null
                    ? _buildErrorWidget(doctorsState.error!, () => ref.read(adminDoctorsProvider.notifier).fetchDoctors())
                    : _buildAllDoctorsTab(doctorsState.doctors),

            // Tab 2: Pending Verifications
            pendingState.isLoading
                ? const Center(child: CircularProgressIndicator(color: accentColor))
                : pendingState.error != null
                    ? _buildErrorWidget(pendingState.error!, () => ref.read(pendingDoctorsProvider.notifier).fetchPendingDoctors())
                    : _buildPendingVerTab(pendingState.doctors),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDoctorDialog(context),
        backgroundColor: accentColor,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add Doctor', style: TextStyle(fontWeight: FontWeight.bold)),
      ).animate().scale(delay: 200.ms, duration: 300.ms),
    );
  }

  Widget _buildErrorWidget(String error, VoidCallback onRetry) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 50, color: Colors.redAccent),
            const SizedBox(height: 16),
            Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: textSecondary),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(backgroundColor: accentColor),
              child: const Text('Retry', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAllDoctorsTab(List<dynamic> doctors) {
    final filtered = doctors.where((doc) {
      final name = (doc['full_name'] ?? '').toString().toLowerCase();
      final email = (doc['email'] ?? '').toString().toLowerCase();
      final spec = (doc['specialization'] ?? '').toString().toLowerCase();
      final q = _searchQuery.toLowerCase();
      return name.contains(q) || email.contains(q) || spec.contains(q);
    }).toList();

    return Column(
      children: [
        _buildSearchField(),
        Expanded(
          child: filtered.isEmpty
              ? _buildEmptyState('No doctors found matching query.')
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(24.0, 8.0, 24.0, 110.0),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final doc = filtered[index];
                    return _buildDoctorCard(doc)
                        .animate()
                        .fadeIn(duration: 300.ms, delay: (index * 50).ms)
                        .slideY(begin: 0.05);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildPendingVerTab(List<dynamic> doctors) {
    return doctors.isEmpty
        ? _buildEmptyState('No pending doctor verifications.')
        : ListView.builder(
            padding: const EdgeInsets.fromLTRB(24.0, 24.0, 24.0, 110.0),
            itemCount: doctors.length,
            itemBuilder: (context, index) {
              final doc = doctors[index];
              return _buildPendingDoctorCard(doc)
                  .animate()
                  .fadeIn(duration: 300.ms, delay: (index * 50).ms)
                  .slideY(begin: 0.05);
            },
          );
  }

  Widget _buildSearchField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
      child: TextField(
        controller: _searchController,
        onChanged: (val) {
          setState(() {
            _searchQuery = val;
          });
        },
        style: const TextStyle(color: textPrimary),
        decoration: InputDecoration(
          hintText: 'Search by name, email, specialty...',
          hintStyle: const TextStyle(color: textSecondary),
          prefixIcon: const Icon(Icons.search_rounded, color: textSecondary),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear_rounded, color: textSecondary),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                    });
                  },
                )
              : null,
          filled: true,
          fillColor: darkCard,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: darkBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: darkBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: accentColor, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(String msg) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline_rounded, size: 60, color: textSecondary.withOpacity(0.4)),
            const SizedBox(height: 16),
            Text(
              msg,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, color: textSecondary, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDoctorCard(Map<String, dynamic> doc) {
    final id = doc['id'];
    final name = doc['full_name'] ?? 'Doctor';
    final email = doc['email'] ?? '';
    final spec = doc['specialization'] ?? '';
    final fee = doc['consultation_fee']?.toString() ?? '0.00';
    final experience = doc['experience']?.toString() ?? '0';
    final status = doc['verification_status'] ?? 'PENDING';
    final rating = doc['rating']?.toString() ?? '5.0';

    Color statusColor = Colors.orange;
    if (status == 'APPROVED') statusColor = Colors.green;
    if (status == 'REJECTED') statusColor = Colors.redAccent;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: darkBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            bottom: -20,
            right: -20,
            child: Icon(
              Icons.medical_services_outlined,
              size: 110,
              color: accentColor.withOpacity(0.035),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: accentColor.withOpacity(0.1),
                      child: const Icon(Icons.person_rounded, color: accentColor, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold, color: textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            email,
                            style: const TextStyle(fontSize: 12, color: textSecondary),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: accentColor.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  spec,
                                  style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: accentColor),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: statusColor.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  status,
                                  style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: statusColor),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Divider(height: 1, color: darkBorder),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.workspace_premium_outlined, size: 14, color: textSecondary),
                        const SizedBox(width: 4),
                        Text('$experience Yrs Exp', style: const TextStyle(fontSize: 12, color: textSecondary)),
                        const SizedBox(width: 12),
                        const Icon(Icons.star_rounded, size: 14, color: Colors.orange),
                        const SizedBox(width: 2),
                        Text(rating, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textPrimary)),
                        const SizedBox(width: 12),
                        const Icon(Icons.payments_outlined, size: 14, color: textSecondary),
                        const SizedBox(width: 4),
                        Text('\$$fee', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textPrimary)),
                      ],
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, color: accentColor, size: 18),
                          constraints: const BoxConstraints(),
                          padding: const EdgeInsets.all(4),
                          onPressed: () => _showEditDoctorDialog(context, doc),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 18),
                          constraints: const BoxConstraints(),
                          padding: const EdgeInsets.all(4),
                          onPressed: () => _confirmDeleteDoctor(context, id, name),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingDoctorCard(Map<String, dynamic> doc) {
    final id = doc['id'];
    final name = doc['full_name'] ?? 'Doctor';
    final email = doc['email'] ?? '';
    final spec = doc['specialization'] ?? '';
    final fee = doc['consultation_fee']?.toString() ?? '0.00';
    final qualification = doc['qualification'] ?? '';
    final experience = doc['experience']?.toString() ?? '0';

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: darkBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            bottom: -20,
            right: -20,
            child: Icon(
              Icons.verified_user_outlined,
              size: 110,
              color: Colors.orange.withOpacity(0.035),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: accentColor.withOpacity(0.1),
                      child: const Icon(Icons.person_rounded, color: accentColor, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold, color: textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            email,
                            style: const TextStyle(fontSize: 12, color: textSecondary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(height: 1, color: darkBorder),
                const SizedBox(height: 12),
                Text(
                  'Specialization: $spec',
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: textPrimary),
                ),
                const SizedBox(height: 4),
                Text(
                  'Qualification: $qualification',
                  style: const TextStyle(fontSize: 12.5, color: textSecondary),
                ),
                const SizedBox(height: 4),
                Text(
                  'Experience: $experience Years  •  Fee: \$$fee',
                  style: const TextStyle(fontSize: 12.5, color: textSecondary),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    OutlinedButton(
                      onPressed: () => _updatePendingStatus(id, 'REJECTED'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.redAccent,
                        side: const BorderSide(color: Colors.redAccent),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ),
                      child: const Text('Reject', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () => _updatePendingStatus(id, 'APPROVED'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        elevation: 0,
                      ),
                      child: const Text('Approve', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _updatePendingStatus(int doctorId, String status) async {
    final success = await ref.read(pendingDoctorsProvider.notifier).verifyDoctor(doctorId, status);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success
              ? 'Doctor successfully marked as $status!'
              : 'Failed to update verification status.'),
          backgroundColor: success ? Colors.green : Colors.redAccent,
        ),
      );
    }
  }

  void _confirmDeleteDoctor(BuildContext context, int id, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: darkCard,
        title: const Text('DELETE DOCTOR', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text(
          'Are you sure you want to permanently delete Dr. $name from the platform? This will delete both their profile and login account.',
          style: const TextStyle(color: textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final error = await ref.read(adminDoctorsProvider.notifier).deleteDoctor(id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error == null ? 'Doctor deleted successfully!' : 'Failed to delete: $error'),
            backgroundColor: error == null ? Colors.green : Colors.redAccent,
          ),
        );
      }
    }
  }

  void _showAddDoctorDialog(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    final emailController = TextEditingController();
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    final passwordController = TextEditingController();
    final qualificationController = TextEditingController();
    final feeController = TextEditingController();
    final expController = TextEditingController();
    final bioController = TextEditingController();
    
    String selectedSpec = 'General Physician';
    final List<String> specialties = ['Cardiologist', 'Dermatologist', 'General Physician', 'Pediatrician', 'Orthopedic'];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: darkCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24.0)),
          title: const Text('ADD NEW DOCTOR', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: 480,
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildDarkTextField(nameController, 'Full Name *', Icons.person_rounded, (val) => val == null || val.trim().isEmpty ? 'Enter full name' : null),
                    const SizedBox(height: 12),
                    _buildDarkTextField(emailController, 'Email Address *', Icons.email_rounded, (val) => val == null || !val.contains('@') ? 'Enter a valid email' : null, keyboardType: TextInputType.emailAddress),
                    const SizedBox(height: 12),
                    _buildDarkTextField(phoneController, 'Phone Number', Icons.phone_rounded, null, keyboardType: TextInputType.phone),
                    const SizedBox(height: 12),
                    _buildDarkTextField(passwordController, 'Password *', Icons.lock_rounded, (val) => val == null || val.length < 6 ? 'Password must be at least 6 characters' : null, obscureText: true),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedSpec,
                      dropdownColor: darkCard,
                      style: const TextStyle(color: textPrimary),
                      decoration: _getDarkInputDecoration('Specialization *', Icons.category_rounded),
                      items: specialties.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(color: textPrimary)))).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setDialogState(() {
                            selectedSpec = val;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    _buildDarkTextField(qualificationController, 'Qualification *', Icons.school_rounded, (val) => val == null || val.trim().isEmpty ? 'Enter qualification' : null),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _buildDarkTextField(expController, 'Experience (Yrs) *', Icons.work_history_rounded, (val) {
                            if (val == null || val.trim().isEmpty) return 'Enter years';
                            if (int.tryParse(val) == null) return 'Must be number';
                            return null;
                          }, keyboardType: TextInputType.number),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildDarkTextField(feeController, 'Consultation Fee (\$) *', Icons.payments_rounded, (val) {
                            if (val == null || val.trim().isEmpty) return 'Enter fee';
                            if (double.tryParse(val) == null) return 'Must be decimal';
                            return null;
                          }, keyboardType: const TextInputType.numberWithOptions(decimal: true)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildDarkTextField(bioController, 'Professional Bio', Icons.info_rounded, null, maxLines: 2),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState?.validate() == true) {
                  final data = {
                    'full_name': nameController.text.trim(),
                    'email': emailController.text.trim().toLowerCase(),
                    'phone': phoneController.text.trim(),
                    'password': passwordController.text,
                    'specialization': selectedSpec,
                    'qualification': qualificationController.text.trim(),
                    'experience': int.parse(expController.text.trim()),
                    'consultation_fee': double.parse(feeController.text.trim()),
                    'bio': bioController.text.trim(),
                  };
                  
                  final error = await ref.read(adminDoctorsProvider.notifier).addDoctor(data);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(error == null ? 'Doctor account added successfully!' : 'Failed to add doctor: $error'),
                        backgroundColor: error == null ? Colors.green : Colors.redAccent,
                      ),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: accentColor),
              child: const Text('Save Doctor', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditDoctorDialog(BuildContext context, Map<String, dynamic> doc) {
    final formKey = GlobalKey<FormState>();
    final id = doc['id'];
    
    final emailController = TextEditingController(text: doc['email']);
    final nameController = TextEditingController(text: doc['full_name']);
    final phoneController = TextEditingController(text: doc['phone'] ?? '');
    final qualificationController = TextEditingController(text: doc['qualification'] ?? '');
    final feeController = TextEditingController(text: doc['consultation_fee']?.toString() ?? '');
    final expController = TextEditingController(text: doc['experience']?.toString() ?? '');
    final bioController = TextEditingController(text: doc['bio'] ?? '');
    
    String selectedSpec = doc['specialization'] ?? 'General Physician';
    String selectedStatus = doc['verification_status'] ?? 'PENDING';

    final List<String> specialties = ['Cardiologist', 'Dermatologist', 'General Physician', 'Pediatrician', 'Orthopedic'];
    final List<String> statuses = ['PENDING', 'APPROVED', 'REJECTED'];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: darkCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24.0)),
          title: const Text('EDIT DOCTOR ACCOUNT', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: 480,
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildDarkTextField(nameController, 'Full Name *', Icons.person_rounded, (val) => val == null || val.trim().isEmpty ? 'Enter full name' : null),
                    const SizedBox(height: 12),
                    _buildDarkTextField(emailController, 'Email Address *', Icons.email_rounded, (val) => val == null || !val.contains('@') ? 'Enter a valid email' : null, keyboardType: TextInputType.emailAddress),
                    const SizedBox(height: 12),
                    _buildDarkTextField(phoneController, 'Phone Number', Icons.phone_rounded, null, keyboardType: TextInputType.phone),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedSpec,
                      dropdownColor: darkCard,
                      style: const TextStyle(color: textPrimary),
                      decoration: _getDarkInputDecoration('Specialization *', Icons.category_rounded),
                      items: specialties.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(color: textPrimary)))).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setDialogState(() {
                            selectedSpec = val;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedStatus,
                      dropdownColor: darkCard,
                      style: const TextStyle(color: textPrimary),
                      decoration: _getDarkInputDecoration('Verification Status *', Icons.verified_user_rounded),
                      items: statuses.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(color: textPrimary)))).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setDialogState(() {
                            selectedStatus = val;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    _buildDarkTextField(qualificationController, 'Qualification *', Icons.school_rounded, (val) => val == null || val.trim().isEmpty ? 'Enter qualification' : null),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _buildDarkTextField(expController, 'Experience (Yrs) *', Icons.work_history_rounded, (val) {
                            if (val == null || val.trim().isEmpty) return 'Enter years';
                            if (int.tryParse(val) == null) return 'Must be number';
                            return null;
                          }, keyboardType: TextInputType.number),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildDarkTextField(feeController, 'Consultation Fee (\$) *', Icons.payments_rounded, (val) {
                            if (val == null || val.trim().isEmpty) return 'Enter fee';
                            if (double.tryParse(val) == null) return 'Must be decimal';
                            return null;
                          }, keyboardType: const TextInputType.numberWithOptions(decimal: true)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildDarkTextField(bioController, 'Professional Bio', Icons.info_rounded, null, maxLines: 2),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState?.validate() == true) {
                  final data = {
                    'user': {
                      'full_name': nameController.text.trim(),
                      'email': emailController.text.trim().toLowerCase(),
                      'phone': phoneController.text.trim(),
                    },
                    'specialization': selectedSpec,
                    'verification_status': selectedStatus,
                    'qualification': qualificationController.text.trim(),
                    'experience': int.parse(expController.text.trim()),
                    'consultation_fee': double.parse(feeController.text.trim()),
                    'bio': bioController.text.trim(),
                  };
                  
                  final error = await ref.read(adminDoctorsProvider.notifier).updateDoctor(id, data);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(error == null ? 'Doctor updated successfully!' : 'Failed to update: $error'),
                        backgroundColor: error == null ? Colors.green : Colors.redAccent,
                      ),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: accentColor),
              child: const Text('Save Changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkTextField(
    TextEditingController controller,
    String label,
    IconData icon,
    String? Function(String?)? validator, {
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLines: maxLines,
      style: const TextStyle(color: textPrimary),
      validator: validator,
      decoration: _getDarkInputDecoration(label, icon),
    );
  }

  InputDecoration _getDarkInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: textSecondary),
      prefixIcon: Icon(icon, color: textSecondary),
      filled: true,
      fillColor: const Color(0xFF090D16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accentColor, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
    );
  }
}
