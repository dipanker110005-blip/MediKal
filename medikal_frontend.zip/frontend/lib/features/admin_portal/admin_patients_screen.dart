import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'admin_provider.dart';

class AdminPatientsScreen extends ConsumerStatefulWidget {
  const AdminPatientsScreen({super.key});

  @override
  ConsumerState<AdminPatientsScreen> createState() => _AdminPatientsScreenState();
}

class _AdminPatientsScreenState extends ConsumerState<AdminPatientsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Local Premium Dark Theme Configuration
  static const Color darkBg = Color(0xFF090D16);
  static const Color darkCard = Color(0xFF111827);
  static const Color darkBorder = Color(0xFF1F2937);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF9CA3AF);
  static const Color accentColor = Color(0xFF10B981); // Emerald Green Accent

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final patientsState = ref.watch(adminPatientsProvider);

    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        title: const Text(
          'Manage Patients',
          style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: accentColor),
            onPressed: () => ref.read(adminPatientsProvider.notifier).fetchPatients(),
          ),
        ],
      ),
      body: SafeArea(
        child: patientsState.isLoading
            ? const Center(child: CircularProgressIndicator(color: accentColor))
            : patientsState.error != null
                ? _buildErrorWidget(patientsState.error!)
                : _buildPatientsList(patientsState.patients),
      ),
    );
  }

  Widget _buildErrorWidget(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 50, color: Colors.redAccent),
            const SizedBox(height: 16),
            Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: textSecondary),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => ref.read(adminPatientsProvider.notifier).fetchPatients(),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Retry', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientsList(List<dynamic> patients) {
    final filtered = patients.where((pat) {
      final name = (pat['full_name'] ?? '').toString().toLowerCase();
      final email = (pat['email'] ?? '').toString().toLowerCase();
      final addr = (pat['address'] ?? '').toString().toLowerCase();
      final blood = (pat['blood_group'] ?? '').toString().toLowerCase();
      final q = _searchQuery.toLowerCase();
      return name.contains(q) || email.contains(q) || addr.contains(q) || blood.contains(q);
    }).toList();

    return Column(
      children: [
        _buildSearchField(),
        Expanded(
          child: filtered.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(24.0, 8.0, 24.0, 110.0),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final pat = filtered[index];
                    return _buildPatientCard(pat)
                        .animate()
                        .fadeIn(duration: 300.ms, delay: (index * 50).ms)
                        .slideY(begin: 0.05);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildSearchField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
      child: TextField(
        controller: _searchController,
        onChanged: (val) {
          setState(() {
            _searchQuery = val;
          });
        },
        style: const TextStyle(color: textPrimary),
        decoration: InputDecoration(
          hintText: 'Search by name, email, blood group...',
          hintStyle: const TextStyle(color: textSecondary),
          prefixIcon: const Icon(Icons.search_rounded, color: textSecondary),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear_rounded, color: textSecondary),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                    });
                  },
                )
              : null,
          filled: true,
          fillColor: darkCard,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: darkBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: darkBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: const BorderSide(color: accentColor, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline_rounded, size: 60, color: textSecondary.withOpacity(0.4)),
            const SizedBox(height: 16),
            const Text(
              'No patients found matching query.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: textSecondary, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientCard(Map<String, dynamic> pat) {
    final id = pat['id'];
    final name = pat['full_name'] ?? 'Patient';
    final email = pat['email'] ?? '';
    final phone = pat['phone'] ?? 'No phone';
    final age = pat['age']?.toString() ?? 'N/A';
    final bloodGroup = pat['blood_group'] ?? 'N/A';
    final address = pat['address'] ?? 'No address listed';
    final emergencyContact = pat['emergency_contact'] ?? 'No emergency contact';
    final isActive = pat['is_active'] ?? true;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: darkBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            bottom: -20,
            right: -20,
            child: Icon(
              Icons.people_outline_rounded,
              size: 110,
              color: accentColor.withOpacity(0.035),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: accentColor.withOpacity(0.1),
                      child: const Icon(Icons.person_outline_rounded, color: accentColor, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textPrimary),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            email,
                            style: const TextStyle(fontSize: 12, color: textSecondary),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Phone: $phone',
                            style: const TextStyle(fontSize: 12, color: textSecondary),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: isActive ? Colors.green.withOpacity(0.12) : Colors.orange.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: isActive ? Colors.green.withOpacity(0.3) : Colors.orange.withOpacity(0.3)),
                      ),
                      child: Text(
                        isActive ? 'ACTIVE' : 'SUSPENDED',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: isActive ? Colors.greenAccent : Colors.orangeAccent,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Divider(height: 1, color: darkBorder),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(Icons.calendar_month_outlined, size: 14, color: textSecondary),
                    const SizedBox(width: 4),
                    Text('Age: $age', style: const TextStyle(fontSize: 12, color: textSecondary)),
                    const SizedBox(width: 20),
                    const Icon(Icons.bloodtype_outlined, size: 14, color: Colors.redAccent),
                    const SizedBox(width: 4),
                    Text('Blood Group: $bloodGroup', style: const TextStyle(fontSize: 12, color: textSecondary)),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.location_on_outlined, size: 14, color: textSecondary),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'Address: $address',
                        style: const TextStyle(fontSize: 12, color: textSecondary),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.contact_phone_outlined, size: 14, color: textSecondary),
                    const SizedBox(width: 4),
                    Text('Emergency Contact: $emergencyContact', style: const TextStyle(fontSize: 12, color: textSecondary)),
                  ],
                ),
                const SizedBox(height: 16),
                const Divider(height: 1, color: darkBorder),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton.icon(
                      icon: Icon(isActive ? Icons.block_flipped : Icons.check_circle_outline_rounded, size: 16),
                      label: Text(isActive ? 'Suspend' : 'Activate', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      style: TextButton.styleFrom(
                        foregroundColor: isActive ? Colors.orangeAccent : Colors.greenAccent,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: () => _togglePatientStatus(id, isActive),
                    ),
                    const SizedBox(width: 12),
                    TextButton.icon(
                      icon: const Icon(Icons.edit_outlined, size: 16),
                      label: const Text('Edit Profile', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      style: TextButton.styleFrom(
                        foregroundColor: accentColor,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: () => _showEditPatientDialog(context, pat),
                    ),
                    const SizedBox(width: 12),
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 18),
                      constraints: const BoxConstraints(),
                      padding: const EdgeInsets.all(8),
                      onPressed: () => _confirmDeletePatient(id, name),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _togglePatientStatus(int id, bool currentActive) async {
    final data = {
      'user': {
        'is_active': !currentActive,
      }
    };
    final error = await ref.read(adminPatientsProvider.notifier).updatePatient(id, data);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(error == null
              ? 'Patient account status updated successfully!'
              : 'Failed to update status: $error'),
          backgroundColor: error == null ? Colors.green : Colors.redAccent,
        ),
      );
    }
  }

  void _confirmDeletePatient(int id, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: darkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('DELETE PATIENT', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text(
          'Are you sure you want to permanently delete $name\'s patient profile from the system? This will delete both their health records and their auth login account.',
          style: const TextStyle(color: textSecondary, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel', style: TextStyle(color: textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
            child: const Text('Delete', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final error = await ref.read(adminPatientsProvider.notifier).deletePatient(id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error == null ? 'Patient deleted successfully!' : 'Failed to delete: $error'),
            backgroundColor: error == null ? Colors.green : Colors.redAccent,
          ),
        );
      }
    }
  }

  void _showEditPatientDialog(BuildContext context, Map<String, dynamic> pat) {
    final formKey = GlobalKey<FormState>();
    final id = pat['id'];
    
    final nameController = TextEditingController(text: pat['full_name']);
    final emailController = TextEditingController(text: pat['email']);
    final phoneController = TextEditingController(text: pat['phone'] ?? '');
    final ageController = TextEditingController(text: pat['age']?.toString() ?? '');
    final addressController = TextEditingController(text: pat['address'] ?? '');
    final contactController = TextEditingController(text: pat['emergency_contact'] ?? '');
    
    String selectedBlood = pat['blood_group'] ?? 'O+';
    final List<String> bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: darkCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24.0)),
          title: const Text('EDIT PATIENT PROFILE', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: 440,
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildDarkTextField(nameController, 'Full Name *', Icons.person_rounded, (val) => val == null || val.trim().isEmpty ? 'Enter full name' : null),
                    const SizedBox(height: 12),
                    _buildDarkTextField(emailController, 'Email Address *', Icons.email_rounded, (val) => val == null || !val.contains('@') ? 'Enter valid email' : null, keyboardType: TextInputType.emailAddress),
                    const SizedBox(height: 12),
                    _buildDarkTextField(phoneController, 'Phone Number', Icons.phone_rounded, null, keyboardType: TextInputType.phone),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _buildDarkTextField(ageController, 'Age *', Icons.calendar_today_rounded, (val) {
                            if (val == null || val.trim().isEmpty) return 'Enter age';
                            if (int.tryParse(val) == null) return 'Must be integer';
                            return null;
                          }, keyboardType: TextInputType.number),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: selectedBlood,
                            dropdownColor: darkCard,
                            style: const TextStyle(color: textPrimary),
                            decoration: _getDarkInputDecoration('Blood Group *', Icons.bloodtype_rounded),
                            items: bloodGroups.map((bg) => DropdownMenuItem(value: bg, child: Text(bg, style: const TextStyle(color: textPrimary)))).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                setDialogState(() {
                                  selectedBlood = val;
                                });
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildDarkTextField(addressController, 'Address', Icons.location_on_rounded, null),
                    const SizedBox(height: 12),
                    _buildDarkTextField(contactController, 'Emergency Contact', Icons.contact_phone_rounded, null),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel', style: TextStyle(color: textSecondary)),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState?.validate() == true) {
                  final data = {
                    'user': {
                      'full_name': nameController.text.trim(),
                      'email': emailController.text.trim().toLowerCase(),
                      'phone': phoneController.text.trim(),
                    },
                    'age': int.parse(ageController.text.trim()),
                    'blood_group': selectedBlood,
                    'address': addressController.text.trim(),
                    'emergency_contact': contactController.text.trim(),
                  };

                  final error = await ref.read(adminPatientsProvider.notifier).updatePatient(id, data);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(error == null ? 'Patient updated successfully!' : 'Failed to update: $error'),
                        backgroundColor: error == null ? Colors.green : Colors.redAccent,
                      ),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Save Changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkTextField(
    TextEditingController controller,
    String label,
    IconData icon,
    String? Function(String?)? validator, {
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLines: maxLines,
      style: const TextStyle(color: textPrimary),
      validator: validator,
      decoration: _getDarkInputDecoration(label, icon),
    );
  }

  InputDecoration _getDarkInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: textSecondary),
      prefixIcon: Icon(icon, color: textSecondary),
      filled: true,
      fillColor: const Color(0xFF090D16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accentColor, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
    );
  }
}
