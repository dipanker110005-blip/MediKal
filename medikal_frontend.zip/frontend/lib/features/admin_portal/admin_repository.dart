import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final adminRepositoryProvider = Provider<AdminRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return AdminRepositoryImpl(apiService);
});

abstract class AdminRepository {
  Future<Map<String, dynamic>> fetchAnalytics();
  Future<List<dynamic>> fetchPendingDoctors();
  Future<Map<String, dynamic>> verifyDoctor(int doctorId, String status);
  
  // Administrative Doctor CRUD
  Future<List<dynamic>> fetchDoctors();
  Future<Map<String, dynamic>> addDoctor(Map<String, dynamic> data);
  Future<Map<String, dynamic>> updateDoctor(int id, Map<String, dynamic> data);
  Future<void> deleteDoctor(int id);

  // Administrative Patient CRUD
  Future<List<dynamic>> fetchPatients();
  Future<Map<String, dynamic>> updatePatient(int id, Map<String, dynamic> data);
  Future<void> deletePatient(int id);
}

class AdminRepositoryImpl implements AdminRepository {
  final ApiService _apiService;

  AdminRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> fetchAnalytics() async {
    try {
      final response = await _apiService.get('/api/analytics/dashboard/');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load system analytics.');
    }
  }

  @override
  Future<List<dynamic>> fetchPendingDoctors() async {
    try {
      final response = await _apiService.get(
        '/api/doctors/verification/',
        queryParameters: {'status': 'PENDING'},
      );
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to fetch pending doctor profiles.');
    }
  }

  @override
  Future<Map<String, dynamic>> verifyDoctor(int doctorId, String status) async {
    try {
      final response = await _apiService.put(
        '/api/doctors/$doctorId/verify/',
        data: {'verification_status': status},
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to submit doctor verification status.');
    }
  }

  @override
  Future<List<dynamic>> fetchDoctors() async {
    try {
      final response = await _apiService.get('/api/doctors/admin/');
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to fetch doctor accounts.');
    }
  }

  @override
  Future<Map<String, dynamic>> addDoctor(Map<String, dynamic> data) async {
    try {
      final response = await _apiService.post('/api/doctors/admin/', data: data);
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to add doctor account.');
    }
  }

  @override
  Future<Map<String, dynamic>> updateDoctor(int id, Map<String, dynamic> data) async {
    try {
      final response = await _apiService.patch('/api/doctors/admin/$id/', data: data);
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to update doctor profile.');
    }
  }

  @override
  Future<void> deleteDoctor(int id) async {
    try {
      await _apiService.delete('/api/doctors/admin/$id/');
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to delete doctor account.');
    }
  }

  @override
  Future<List<dynamic>> fetchPatients() async {
    try {
      final response = await _apiService.get('/api/patients/admin/');
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to fetch patient accounts.');
    }
  }

  @override
  Future<Map<String, dynamic>> updatePatient(int id, Map<String, dynamic> data) async {
    try {
      final response = await _apiService.patch('/api/patients/admin/$id/', data: data);
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to update patient profile.');
    }
  }

  @override
  Future<void> deletePatient(int id) async {
    try {
      await _apiService.delete('/api/patients/admin/$id/');
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to delete patient account.');
    }
  }
}
