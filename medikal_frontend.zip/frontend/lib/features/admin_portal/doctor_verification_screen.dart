import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'admin_provider.dart';

class DoctorVerificationScreen extends ConsumerWidget {
  const DoctorVerificationScreen({super.key});

  // Local Premium Dark Theme Configuration
  static const Color darkBg = Color(0xFF090D16);
  static const Color darkCard = Color(0xFF111827);
  static const Color darkBorder = Color(0xFF1F2937);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF9CA3AF);
  static const Color accentColor = Color(0xFF10B981); // Emerald

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pendingState = ref.watch(pendingDoctorsProvider);

    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        title: const Text(
          'Doctor Approvals',
          style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: accentColor),
            onPressed: () => ref.read(pendingDoctorsProvider.notifier).fetchPendingDoctors(),
          ),
        ],
      ),
      body: SafeArea(
        child: pendingState.isLoading
            ? const Center(child: CircularProgressIndicator(color: accentColor))
            : pendingState.error != null
                ? _buildErrorWidget(ref, pendingState.error!)
                : pendingState.doctors.isEmpty
                    ? _buildEmptyWidget()
                    : RefreshIndicator(
                        onRefresh: () => ref.read(pendingDoctorsProvider.notifier).fetchPendingDoctors(),
                        backgroundColor: darkCard,
                        color: accentColor,
                        child: ListView.builder(
                          padding: const EdgeInsets.all(24.0),
                          itemCount: pendingState.doctors.length,
                          itemBuilder: (context, index) {
                            final doctor = pendingState.doctors[index];
                            return _buildDoctorCard(context, ref, doctor)
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 100).ms)
                                .slideY(begin: 0.05);
                          },
                        ),
                      ),
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle_outline_rounded,
                size: 80,
                color: Colors.greenAccent,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'No Pending Approvals',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: textPrimary),
            ),
            const SizedBox(height: 8),
            const Text(
              'All registered medical practitioners have been reviewed and verified.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: textSecondary, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorWidget(WidgetRef ref, String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 60, color: Colors.redAccent),
            const SizedBox(height: 16),
            const Text(
              'Failed to load pending list',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.redAccent),
            ),
            const SizedBox(height: 8),
            Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: textSecondary),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => ref.read(pendingDoctorsProvider.notifier).fetchPendingDoctors(),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Try Again', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDoctorCard(BuildContext context, WidgetRef ref, Map<String, dynamic> doctor) {
    final doctorId = doctor['id'];
    final name = doctor['full_name'] ?? 'Practitioner';
    final specialization = doctor['specialization'] ?? '';
    final qualification = doctor['qualification'] ?? '';
    final experience = doctor['experience']?.toString() ?? '0';
    final fee = doctor['consultation_fee']?.toString() ?? '0.00';
    final bio = doctor['bio'] ?? 'No bio description provided.';
    final initials = name.isNotEmpty ? name[0].toUpperCase() : 'D';

    return Container(
      margin: const EdgeInsets.only(bottom: 20.0),
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(24.0),
        border: Border.all(color: darkBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            bottom: -20,
            right: -20,
            child: Icon(
              Icons.medical_services_outlined,
              size: 110,
              color: accentColor.withOpacity(0.035),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: accentColor.withOpacity(0.1),
                      child: Text(
                        initials,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: accentColor),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Dr. $name',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '$specialization • $qualification',
                            style: const TextStyle(fontSize: 12, color: textSecondary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const Divider(color: darkBorder),
                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          const Icon(Icons.work_history_outlined, size: 16, color: textSecondary),
                          const SizedBox(width: 8),
                          Text(
                            '$experience Years Exp',
                            style: const TextStyle(fontSize: 12.5, color: textPrimary, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Row(
                        children: [
                          const Icon(Icons.payments_outlined, size: 16, color: textSecondary),
                          const SizedBox(width: 8),
                          Text(
                            'Fee: \$$fee',
                            style: const TextStyle(fontSize: 12.5, color: textPrimary, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    color: darkBg,
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: Text(
                    bio,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: textSecondary, height: 1.35),
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(color: darkBorder),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _updateStatus(context, ref, doctorId, name, 'REJECTED'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.redAccent,
                          side: const BorderSide(color: Colors.redAccent, width: 1.5),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                        ),
                        child: const Text('Reject Profile', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _updateStatus(context, ref, doctorId, name, 'APPROVED'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                          elevation: 0,
                        ),
                        child: const Text('Approve Doctor', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

  void _updateStatus(BuildContext context, WidgetRef ref, int id, String doctorName, String status) async {
    final actionText = status == 'APPROVED' ? 'approve' : 'reject';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: darkCard,
        title: Text('${actionText.toUpperCase()} PRACTITIONER', style: const TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('Are you sure you want to $actionText Dr. $doctorName\'s medical profile?', style: const TextStyle(color: textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel', style: TextStyle(color: textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: status == 'APPROVED' ? Colors.green : Colors.redAccent),
            child: Text('Yes, $status', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final success = await ref.read(pendingDoctorsProvider.notifier).verifyDoctor(id, status);
      if (success && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Dr. $doctorName has been $status!'),
            backgroundColor: status == 'APPROVED' ? Colors.green : Colors.redAccent,
          ),
        );
      }
    }
  }
}
