import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'ai_provider.dart';
import '../doctors/doctors_screen.dart';
import '../emergency/emergency_screen.dart';
import 'voice_recognition_stub.dart';

class AIChatScreen extends ConsumerStatefulWidget {
  const AIChatScreen({super.key});

  @override
  ConsumerState<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends ConsumerState<AIChatScreen> {
  final _textController = TextEditingController();
  final _scrollController = ScrollController();
  bool _isListening = false;
  String _listeningStatus = "Listening for symptoms...";
  late final VoiceRecognizer _voiceRecognizer;
  String _voiceTranscript = "";

  @override
  void initState() {
    super.initState();
    _voiceRecognizer = getVoiceRecognizer(
      onStart: () {
        setState(() {
          _isListening = true;
          _listeningStatus = "Listening... Speak your symptoms clearly";
          _voiceTranscript = "";
        });
      },
      onResult: (transcript) {
        setState(() {
          _voiceTranscript = transcript;
          _listeningStatus = 'Heard: "$transcript"';
        });
      },
      onEnd: () {
        setState(() {
          _isListening = false;
        });
        if (_voiceTranscript.trim().isNotEmpty) {
          _sendMessage(_voiceTranscript);
        }
      },
      onError: (error) {
        setState(() {
          _isListening = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Voice Recognition: $error"),
            backgroundColor: AppColors.emergency,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _voiceRecognizer.stop();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _sendMessage([String? text]) {
    final prompt = text ?? _textController.text;
    if (prompt.trim().isEmpty) return;

    ref.read(aiChatProvider.notifier).sendMessage(prompt);
    
    if (text == null) {
      _textController.clear();
    }
    
    _scrollToBottom();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 150), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _activateVoiceInput() {
    if (_voiceRecognizer.isSupported) {
      _voiceRecognizer.start();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("Voice recognition is not supported in this browser. Please type your symptoms manually or try Google Chrome/Edge."),
          backgroundColor: AppColors.textSecondary,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatState = ref.watch(aiChatProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.smart_toy_rounded, color: AppColors.primary, size: 20),
            ),
            const SizedBox(width: 10),
            Text(
              'Clinical Al Assistant',
              style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.textSecondary),
            onPressed: () => ref.read(aiChatProvider.notifier).clearChat(),
            tooltip: 'Clear Chat',
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Messages Listing
              Expanded(
                child: chatState.messages.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
                        itemCount: chatState.messages.length,
                        itemBuilder: (context, index) {
                          final message = chatState.messages[index];
                          return _buildChatBubble(message)
                              .animate()
                              .fadeIn(duration: 250.ms)
                              .slideY(begin: 0.03);
                        },
                      ),
              ),

              // Loading typing indicator
              if (chatState.isLoading)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.smart_toy_rounded, size: 14, color: AppColors.primary),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        'Analyzing symptoms...',
                        style: AppTheme.bodySmall.copyWith(
                          color: AppColors.textSecondary,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),

              // Quick Action Chip Shortcuts
              if (chatState.messages.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: SizedBox(
                    height: 36,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      children: [
                        _buildQuickActionChip('Symptom Checker', 'I want to check my symptoms'),
                        _buildQuickActionChip('Emergency Guidance', 'Show me emergency precautions'),
                        _buildQuickActionChip('Fever Info', 'What should I do for a sudden fever?'),
                        _buildQuickActionChip('Health Tips', 'Give me heart hygiene tips'),
                      ],
                    ),
                  ),
                ),

              // Input Box
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: const Border(top: BorderSide(color: AppColors.border)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.02),
                      blurRadius: 10,
                      offset: const Offset(0, -4),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: Row(
                    children: [
                      // Voice Search Button (Prominent & Elegant)
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.mic_none_rounded, color: AppColors.primary, size: 24),
                          onPressed: _activateVoiceInput,
                          tooltip: 'Speak Symptoms',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            borderRadius: AppTheme.borderL,
                            border: Border.all(color: AppColors.border),
                          ),
                          child: TextField(
                            controller: _textController,
                            style: AppTheme.bodyMedium,
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) => _sendMessage(),
                            decoration: InputDecoration(
                              hintText: 'Describe symptoms (e.g. cough, fever)...',
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
                              hintStyle: AppTheme.bodyMedium.copyWith(color: AppColors.textMuted),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Send Action
                      Container(
                        decoration: const BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_upward_rounded, color: Colors.white, size: 22),
                          onPressed: () => _sendMessage(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          // Glowing Voice-Listening Overlay Modal (Delightful Micro-Interaction)
          if (_isListening)
            Positioned.fill(
              child: ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
                  child: Container(
                    color: const Color(0xFF0F172A).withOpacity(0.75), // Slate 900 Glassmorphic overlay
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'MEDIKAL VOICE ASSIST',
                            style: GoogleFonts.inter(
                              color: AppColors.primaryLight,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 24),
                          // Pulsing Waves (Visualizing audio listening)
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 130,
                                height: 130,
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.15),
                                  shape: BoxShape.circle,
                                ),
                              )
                                  .animate(onPlay: (controller) => controller.repeat(reverse: true))
                                  .scale(duration: 800.ms, begin: const Offset(0.85, 0.85), end: const Offset(1.15, 1.15)),
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.3),
                                  shape: BoxShape.circle,
                                ),
                              )
                                  .animate(onPlay: (controller) => controller.repeat(reverse: true))
                                  .scale(duration: 1000.ms, begin: const Offset(0.9, 0.9), end: const Offset(1.1, 1.1)),
                              Container(
                                width: 70,
                                height: 70,
                                decoration: const BoxDecoration(
                                  color: AppColors.primary,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.mic_rounded, color: Colors.white, size: 36),
                              ),
                            ],
                          ),
                          const SizedBox(height: 32),
                          Text(
                            _listeningStatus,
                            style: AppTheme.h3.copyWith(color: Colors.white),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Please speak clearly. We will process your symptoms instantly.',
                            textAlign: TextAlign.center,
                            style: AppTheme.bodySmall.copyWith(color: Colors.white.withOpacity(0.5)),
                          ),
                          const SizedBox(height: 48),
                          OutlinedButton(
                            onPressed: () {
                              _voiceRecognizer.stop();
                              setState(() {
                                _isListening = false;
                              });
                            },
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.white24),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                            ),
                            child: const Text('Cancel'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceXL),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.06),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.smart_toy_outlined,
                size: 64,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'AI Symptom Triage',
              style: AppTheme.h3.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(
              'Describe how you feel, or use Voice input. Our clinical assistant will parse your symptoms and recommend steps.',
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 36),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                _buildPresetPromptCard('Chest tightness', 'I am feeling tightness in my chest and breathlessness'),
                _buildPresetPromptCard('Stomach cramps', 'Sharp stomach pain after lunch'),
                _buildPresetPromptCard('High fever', 'I have a 102°F fever with chills'),
              ],
            ),
          ],
        ),
      ).animate().fadeIn(duration: 400.ms),
    );
  }

  Widget _buildPresetPromptCard(String label, String prompt) {
    return GestureDetector(
      onTap: () => _sendMessage(prompt),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: AppTheme.borderM,
          border: Border.all(color: AppColors.border),
          boxShadow: AppTheme.shadowSubtle,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.add_circle_outline, size: 14, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(
              label,
              style: AppTheme.bodySmall.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionChip(String label, String promptText) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: ActionChip(
        label: Text(label),
        onPressed: () => _sendMessage(promptText),
        backgroundColor: AppColors.card,
        labelStyle: AppTheme.bodySmall.copyWith(color: AppColors.primary, fontWeight: FontWeight.w700),
        shape: RoundedRectangleBorder(borderRadius: AppTheme.borderS),
        side: const BorderSide(color: AppColors.border),
      ),
    );
  }

  Widget _buildChatBubble(ChatMessage message) {
    final alignRight = message.isUser;
    
    // Check if message is a medical report from AI
    final isStructuredReport = !alignRight && 
        (message.text.contains('1. Summary:') || message.text.contains('1.  **Summary:'));

    if (isStructuredReport) {
      return _buildClinicalReportCard(message.text);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: alignRight ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!alignRight) ...[
            CircleAvatar(
              radius: 15,
              backgroundColor: AppColors.primaryLight,
              child: const Icon(Icons.smart_toy_rounded, size: 16, color: AppColors.primary),
            ),
            const SizedBox(width: 10),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              decoration: BoxDecoration(
                color: alignRight ? AppColors.primary : AppColors.card,
                border: alignRight ? null : Border.all(color: AppColors.border),
                boxShadow: alignRight ? null : AppTheme.shadowSubtle,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16.0),
                  topRight: const Radius.circular(16.0),
                  bottomLeft: Radius.circular(alignRight ? 16.0 : 0.0),
                  bottomRight: Radius.circular(alignRight ? 0.0 : 16.0),
                ),
              ),
              child: Text(
                message.text,
                style: AppTheme.bodyMedium.copyWith(
                  color: alignRight ? Colors.white : AppColors.textPrimary,
                  height: 1.45,
                ),
              ),
            ),
          ),
          if (alignRight) ...[
            const SizedBox(width: 10),
            CircleAvatar(
              radius: 15,
              backgroundColor: AppColors.secondaryLight,
              child: const Icon(Icons.person_rounded, size: 16, color: AppColors.secondary),
            ),
          ]
        ],
      ),
    );
  }

  // Parses raw structured medical recommendations into beautiful components
  Widget _buildClinicalReportCard(String text) {
    // Basic Parsing logic
    final sections = <String, String>{};
    final regExp = RegExp(
      r'(?=\b(?:1\.\s*\*?\*?Summary|2\.\s*\*?\*?Urgency|3\.\s*\*?\*?Possible\s*Conditions|4\.\s*\*?\*?What\s*You\s*Can\s*Do|5\.\s*\*?\*?Medicines|6\.\s*\*?\*?When\s*To\s*Seek|7\.\s*\*?\*?Follow-up|8\.\s*\*?\*?Disclaimer|Disclaimer):)', 
      caseSensitive: false
    );
    final parts = text.split(regExp);
    
    for (var part in parts) {
      part = part.trim();
      if (part.isEmpty) continue;
      final cleanText = part.replaceFirst(RegExp(r'^\d+\.\s*\*?\*?[a-zA-Z\s]+(?:\(.*\))?\*?\*?:\s*'), '').trim();
      if (part.toLowerCase().contains('summary')) {
        sections['summary'] = cleanText;
      } else if (part.toLowerCase().contains('urgency')) {
        sections['urgency'] = cleanText;
      } else if (part.toLowerCase().contains('possible conditions') || part.toLowerCase().contains('conditions')) {
        sections['conditions'] = cleanText;
      } else if (part.toLowerCase().contains('what you can do') || part.toLowerCase().contains('prevention')) {
        sections['what_to_do'] = cleanText;
      } else if (part.toLowerCase().contains('medicines')) {
        sections['medicines'] = cleanText;
      } else if (part.toLowerCase().contains('when to seek')) {
        sections['when_to_seek'] = cleanText;
      } else if (part.toLowerCase().contains('follow-up')) {
        sections['questions'] = cleanText;
      } else if (part.toLowerCase().contains('disclaimer')) {
        sections['disclaimer'] = cleanText;
      }
    }

    // Determine Urgency Styling
    final urgencyText = sections['urgency']?.toLowerCase() ?? '';
    Color urgencyColor = AppColors.success;
    Color urgencyBg = AppColors.successLight;
    IconData urgencyIcon = Icons.check_circle_outline_rounded;
    String urgencyLabel = "ROUTINE CARE";

    if (urgencyText.contains('emergency') || urgencyText.contains('serious') || urgencyText.contains('immediate')) {
      urgencyColor = AppColors.emergency;
      urgencyBg = AppColors.emergencyLight;
      urgencyIcon = Icons.warning_rounded;
      urgencyLabel = "EMERGENCY CARE";
    } else if (urgencyText.contains('medium') || urgencyText.contains('moderate') || urgencyText.contains('seek help') || urgencyText.contains('requires medical attention')) {
      urgencyColor = AppColors.urgent;
      urgencyBg = AppColors.urgentLight;
      urgencyIcon = Icons.info_outline;
      urgencyLabel = "MODERATE URGENCY";
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: AppTheme.borderXL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowCard,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Urgency Header Tag
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            decoration: BoxDecoration(
              color: urgencyBg.withOpacity(0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(AppTheme.radiusXL),
                topRight: Radius.circular(AppTheme.radiusXL),
              ),
              border: Border(bottom: BorderSide(color: urgencyColor.withOpacity(0.12))),
            ),
            child: Row(
              children: [
                Icon(urgencyIcon, color: urgencyColor, size: 20),
                const SizedBox(width: 10),
                Text(
                  urgencyLabel,
                  style: GoogleFonts.inter(
                    color: urgencyColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.0,
                  ),
                ),
                const Spacer(),
                Text(
                  'AI TRIAGE REPORT',
                  style: GoogleFonts.inter(
                    color: AppColors.textMuted,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 1. Summary
                if (sections.containsKey('summary')) ...[
                  Text('Summary', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(sections['summary']!, style: AppTheme.bodyMedium),
                  const Divider(height: 28, color: AppColors.border),
                ],

                // 2. Possible Conditions
                if (sections.containsKey('conditions')) ...[
                  Text('Possible Causes', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  _buildBulletPoints(sections['conditions']!),
                  const Divider(height: 28, color: AppColors.border),
                ],

                // 3. What You Can Do
                if (sections.containsKey('what_to_do')) ...[
                  Text('What You Can Do Now', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  _buildBulletPoints(sections['what_to_do']!),
                  const Divider(height: 28, color: AppColors.border),
                ],

                // 4. Medicines Advice (Structured display)
                if (sections.containsKey('medicines')) ...[
                  Text('Care & Medication Cautions', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(sections['medicines']!, style: AppTheme.bodyMedium),
                  const Divider(height: 28, color: AppColors.border),
                ],

                // 5. When to Seek Help
                if (sections.containsKey('when_to_seek')) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.warningLight.withOpacity(0.3),
                      borderRadius: AppTheme.borderM,
                      border: Border.all(color: AppColors.warning.withOpacity(0.2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              'Seek Professional Attention If:',
                              style: AppTheme.h4.copyWith(fontSize: 14, color: AppColors.textPrimary, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(sections['when_to_seek']!, style: AppTheme.bodyMedium.copyWith(fontSize: 13, height: 1.4)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // Action Buttons for Next Best Step
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text('Book Specialist'),
                      ),
                    ),
                    if (urgencyColor == AppColors.emergency) ...[
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const EmergencyScreen()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.emergency,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: const Text('Emergency Care'),
                        ),
                      ),
                    ],
                  ],
                ),

                // Disclaimer Footer
                if (sections.containsKey('disclaimer')) ...[
                  const SizedBox(height: 20),
                  Text(
                    sections['disclaimer']!,
                    style: AppTheme.bodySmall.copyWith(
                      color: AppColors.textMuted,
                      fontSize: 11,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBulletPoints(String text) {
    final cleanText = text.replaceAll(RegExp(r'^\s*-\s*|^\s*\*\s*'), '');
    final lines = cleanText.split('\n').where((line) => line.trim().isNotEmpty).toList();
    if (lines.isEmpty) return Text(text, style: AppTheme.bodyMedium);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: lines.map((line) {
        final lineClean = line.replaceFirst(RegExp(r'^\s*[\-\*]\s*|^\s*\d+\.\s*'), '').trim();
        return Padding(
          padding: const EdgeInsets.only(bottom: 6.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 6.0, right: 10.0),
                child: Icon(Icons.circle, size: 5, color: AppColors.primary),
              ),
              Expanded(
                child: Text(
                  lineClean,
                  style: AppTheme.bodyMedium.copyWith(height: 1.4),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
