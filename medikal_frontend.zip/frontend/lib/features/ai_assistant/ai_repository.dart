import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final aiRepositoryProvider = Provider<AIRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return AIRepositoryImpl(apiService);
});

abstract class AIRepository {
  Future<String> sendChatMessage(String message, List<Map<String, dynamic>> history);
}

class AIRepositoryImpl implements AIRepository {
  final ApiService _apiService;

  AIRepositoryImpl(this._apiService);

  @override
  Future<String> sendChatMessage(String message, List<Map<String, dynamic>> history) async {
    try {
      final response = await _apiService.post(
        '/api/ai-assistant/chat/',
        data: {
          'prompt': message,
          'history': history,
        },
      );
      final data = response.data as Map<String, dynamic>;
      return data['response'] ?? 'I could not process that request.';
    } on DioException catch (e) {
      throw Exception(e.response?.data?['error'] ?? 'AI service connection failed.');
    }
  }
}
