import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class SymptomCheckRecord {
  final String date;
  final String symptomsChecked;
  final String urgency; // 'Urgent', 'Routine', 'Self-care'
  final String outcomeSummary;
  final String adviceGiven;

  const SymptomCheckRecord({
    required this.date,
    required this.symptomsChecked,
    required this.urgency,
    required this.outcomeSummary,
    required this.adviceGiven,
  });
}

class SymptomHistoryScreen extends StatelessWidget {
  const SymptomHistoryScreen({super.key});

  final List<SymptomCheckRecord> _history = const [
    SymptomCheckRecord(
      date: 'Jun 08, 2026',
      symptomsChecked: 'Chest Tightness & Coughing (Exacerbation)',
      urgency: 'Urgent',
      outcomeSummary: 'Probable bronchial airway constriction. Prompt Albuterol intake advised.',
      adviceGiven: 'Use rescue inhaler. Seek immediate clinical assessment if breathing does not stabilize.',
    ),
    SymptomCheckRecord(
      date: 'May 20, 2026',
      symptomsChecked: 'Mild Sore Throat & Nasal Congestion',
      urgency: 'Self-care',
      outcomeSummary: 'Suspected viral upper respiratory tract infection.',
      adviceGiven: 'Rest, hydration, and over-the-counter pain relief (e.g. Paracetamol) if fever develops.',
    ),
    SymptomCheckRecord(
      date: 'Apr 12, 2026',
      symptomsChecked: 'Persistent High Blood Pressure (148/92 mmHg)',
      urgency: 'Routine',
      outcomeSummary: 'Elevated blood pressure values exceeding personal targets.',
      adviceGiven: 'Verify Lisinopril dose compliance. Log measurements twice daily and book routine consult.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Symptom Check History', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: ListView.builder(
              padding: const EdgeInsets.all(24.0),
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final record = _history[index];
                return _buildHistoryCard(context, record)
                    .animate()
                    .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                    .slideY(begin: 0.03);
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryCard(BuildContext context, SymptomCheckRecord record) {
    Color urgencyColor = AppColors.success;
    Color urgencyBgColor = const Color(0xFFD1FAE5);

    if (record.urgency == 'Urgent') {
      urgencyColor = AppColors.emergency;
      urgencyBgColor = AppColors.emergencyLight;
    } else if (record.urgency == 'Routine') {
      urgencyColor = AppColors.urgent;
      urgencyBgColor = AppColors.urgentLight;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  record.date,
                  style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(color: urgencyBgColor, borderRadius: BorderRadius.circular(10)),
                  child: Text(
                    record.urgency.toUpperCase(),
                    style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.bold, color: urgencyColor),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              record.symptomsChecked,
              style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            Text(
              record.outcomeSummary,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
            ),
            const SizedBox(height: 12),
            const Divider(color: AppColors.border, height: 1),
            const SizedBox(height: 12),
            Text(
              'Clinician Guidance:',
              style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              record.adviceGiven,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, height: 1.4),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Symptom history log shared securely.')),
                    );
                  },
                  icon: const Icon(Icons.share_outlined, size: 14),
                  label: const Text('Share Report'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
