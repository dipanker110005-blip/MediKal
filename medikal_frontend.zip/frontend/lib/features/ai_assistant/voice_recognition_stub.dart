export 'voice_recognition_stub_impl.dart' if (dart.library.html) 'voice_recognition_web.dart';
