import 'package:flutter/foundation.dart';

VoiceRecognizer getVoiceRecognizer({
  required VoidCallback onStart,
  required void Function(String transcript) onResult,
  required VoidCallback onEnd,
  required void Function(String error) onError,
}) {
  return VoiceRecognizerMock(
    onStart: onStart,
    onResult: onResult,
    onEnd: onEnd,
    onError: onError,
  );
}

abstract class VoiceRecognizer {
  bool get isSupported;
  void start();
  void stop();
}

class VoiceRecognizerMock implements VoiceRecognizer {
  final VoidCallback onStart;
  final void Function(String transcript) onResult;
  final VoidCallback onEnd;
  final void Function(String error) onError;

  VoiceRecognizerMock({
    required this.onStart,
    required this.onResult,
    required this.onEnd,
    required this.onError,
  });

  @override
  bool get isSupported => false;

  @override
  void start() {
    onStart();
    Future.delayed(const Duration(milliseconds: 1500), () {
      onResult("Hello, I am testing the voice assistant.");
    });
    Future.delayed(const Duration(milliseconds: 3000), () {
      onEnd();
    });
  }

  @override
  void stop() {}
}
