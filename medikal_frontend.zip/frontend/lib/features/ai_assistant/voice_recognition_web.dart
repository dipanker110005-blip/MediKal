import 'dart:js' as js;
import 'package:flutter/foundation.dart';
import 'voice_recognition_stub_impl.dart';

export 'voice_recognition_stub_impl.dart' show VoiceRecognizer;

VoiceRecognizer getVoiceRecognizer({
  required VoidCallback onStart,
  required void Function(String transcript) onResult,
  required VoidCallback onEnd,
  required void Function(String error) onError,
}) {
  return VoiceRecognizerImpl(
    onStart: onStart,
    onResult: onResult,
    onEnd: onEnd,
    onError: onError,
  );
}

class VoiceRecognizerImpl implements VoiceRecognizer {
  final VoidCallback onStart;
  final void Function(String transcript) onResult;
  final VoidCallback onEnd;
  final void Function(String error) onError;

  dynamic _jsRecognition;

  VoiceRecognizerImpl({
    required this.onStart,
    required this.onResult,
    required this.onEnd,
    required this.onError,
  });

  @override
  bool get isSupported {
    try {
      if (js.context.hasProperty('isSpeechRecognitionSupported')) {
        return js.context.callMethod('isSpeechRecognitionSupported') as bool;
      }
      return js.context.hasProperty('SpeechRecognition') ||
             js.context.hasProperty('webkitSpeechRecognition');
    } catch (e) {
      debugPrint("isSupported check error: $e");
    }
    return false;
  }

  @override
  void start() {
    try {
      // 1. Try index.html helper first if available
      if (js.context.hasProperty('startSpeechRecognition')) {
        _jsRecognition = js.context.callMethod('startSpeechRecognition', [
          js.allowInterop(() {
            onStart();
          }),
          js.allowInterop((String transcript) {
            onResult(transcript);
          }),
          js.allowInterop(() {
            onEnd();
          }),
          js.allowInterop((String error) {
            onError(error);
          }),
        ]);
        return;
      }

      // 2. Fallback to native constructor call
      final speechClass = js.context['SpeechRecognition'] ?? js.context['webkitSpeechRecognition'];
      if (speechClass != null) {
        final recognition = js.JsObject(speechClass);
        recognition['continuous'] = false;
        recognition['interimResults'] = true;
        recognition['lang'] = 'en-US';

        recognition['onstart'] = js.allowInterop(() {
          onStart();
        });

        recognition['onresult'] = js.allowInterop((event) {
          try {
            final results = event['results'];
            final int resultIndex = event['resultIndex'] as int;
            if (results != null && results['length'] > resultIndex) {
              final lastResult = results[resultIndex];
              if (lastResult != null && lastResult['length'] > 0) {
                final String? transcript = lastResult[0]['transcript'] as String?;
                if (transcript != null) {
                  onResult(transcript);
                }
              }
            }
          } catch (e) {
            debugPrint("Error parsing results: $e");
          }
        });

        recognition['onend'] = js.allowInterop(() {
          onEnd();
        });

        recognition['onerror'] = js.allowInterop((event) {
          onError(event['error'] ?? "Unknown error");
        });

        _jsRecognition = recognition;
        recognition.callMethod('start');
      } else {
        onError("Speech recognition is not supported in this browser.");
      }
    } catch (e) {
      onError("Error starting speech recognition: $e");
    }
  }

  @override
  void stop() {
    if (_jsRecognition != null) {
      try {
        if (js.context.hasProperty('stopSpeechRecognition')) {
          js.context.callMethod('stopSpeechRecognition', [_jsRecognition]);
        } else {
          _jsRecognition.callMethod('stop');
        }
        _jsRecognition = null;
      } catch (e) {
        debugPrint("Error stopping speech recognition: $e");
      }
    }
  }
}
