import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'appointments_repository.dart';

// Async status for creating bookings
abstract class BookingState {
  const BookingState();
}

class BookingIdle extends BookingState {
  const BookingIdle();
}

class BookingLoading extends BookingState {
  const BookingLoading();
}

class BookingSuccess extends BookingState {
  final Map<String, dynamic> appointment;
  const BookingSuccess(this.appointment);
}

class BookingError extends BookingState {
  final String message;
  const BookingError(this.message);
}

// State notifier to handle booking submissions
class BookingNotifier extends StateNotifier<BookingState> {
  final AppointmentsRepository _repository;

  BookingNotifier(this._repository) : super(const BookingIdle());

  Future<Map<String, dynamic>?> bookAppointment({
    required int doctorId,
    required String date,
    required String time,
    required String consultationType,
    String? referralCode,
  }) async {
    state = const BookingLoading();
    try {
      final appointment = await _repository.createAppointment(
        doctorId: doctorId,
        date: date,
        time: time,
        consultationType: consultationType,
        referralCode: referralCode,
      );
      state = BookingSuccess(appointment);
      return appointment;
    } catch (e) {
      state = BookingError(e.toString().replaceAll('Exception: ', ''));
      return null;
    }
  }

  Future<bool> verifyPayment({
    required int appointmentId,
    required String paymentId,
    required String signature,
  }) async {
    state = const BookingLoading();
    try {
      final result = await _repository.verifyPayment(
        appointmentId: appointmentId,
        paymentId: paymentId,
        signature: signature,
      );
      state = BookingSuccess(result);
      return true;
    } catch (e) {
      state = BookingError(e.toString().replaceAll('Exception: ', ''));
      return false;
    }
  }

  void reset() {
    state = const BookingIdle();
  }
}

// Expose the list of booked appointments
final patientAppointmentsProvider = FutureProvider<List<Map<String, dynamic>>>((ref) {
  final repository = ref.read(appointmentsRepositoryProvider);
  return repository.fetchAppointments();
});

// Expose the booking action state notifier
final bookingStateProvider = StateNotifierProvider<BookingNotifier, BookingState>((ref) {
  final repository = ref.read(appointmentsRepositoryProvider);
  return BookingNotifier(repository);
});
