import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final appointmentsRepositoryProvider = Provider<AppointmentsRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return AppointmentsRepositoryImpl(apiService);
});

abstract class AppointmentsRepository {
  Future<List<Map<String, dynamic>>> fetchAppointments();
  Future<Map<String, dynamic>> createAppointment({
    required int doctorId,
    required String date,
    required String time,
    required String consultationType,
    String? referralCode,
  });
  Future<Map<String, dynamic>> cancelAppointment(int appointmentId);
  Future<Map<String, dynamic>> verifyPayment({
    required int appointmentId,
    required String paymentId,
    required String signature,
  });
}

class AppointmentsRepositoryImpl implements AppointmentsRepository {
  final ApiService _apiService;

  AppointmentsRepositoryImpl(this._apiService);

  @override
  Future<List<Map<String, dynamic>>> fetchAppointments() async {
    try {
      final response = await _apiService.get('/api/appointments/');
      final list = response.data as List<dynamic>;
      return list.map((item) => item as Map<String, dynamic>).toList();
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load appointments.');
    }
  }

  @override
  Future<Map<String, dynamic>> createAppointment({
    required int doctorId,
    required String date,
    required String time,
    required String consultationType,
    String? referralCode,
  }) async {
    try {
      final data = <String, dynamic>{
        'doctor': doctorId,
        'date': date,
        'time': time,
        'consultation_type': consultationType,
      };
      if (referralCode != null && referralCode.isNotEmpty) {
        data['referral_code'] = referralCode;
      }

      final response = await _apiService.post(
        '/api/appointments/',
        data: data,
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      final errorData = e.response?.data;
      if (errorData is Map) {
        final firstError = errorData.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        } else if (firstError is String) {
          throw Exception(firstError);
        }
      }
      throw Exception('Failed to book appointment. Please try again.');
    }
  }

  @override
  Future<Map<String, dynamic>> cancelAppointment(int appointmentId) async {
    try {
      final response = await _apiService.patch(
        '/api/appointments/$appointmentId/',
        data: {'status': 'CANCELLED'},
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      final errorData = e.response?.data;
      if (errorData is Map) {
        final firstError = errorData.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        } else if (firstError is String) {
          throw Exception(firstError);
        }
      }
      throw Exception(e.response?.data?['detail'] ?? 'Failed to cancel appointment.');
    }
  }

  @override
  Future<Map<String, dynamic>> verifyPayment({
    required int appointmentId,
    required String paymentId,
    required String signature,
  }) async {
    try {
      final response = await _apiService.post(
        '/api/appointments/$appointmentId/verify_payment/',
        data: {
          'razorpay_payment_id': paymentId,
          'razorpay_signature': signature,
        },
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      final errorData = e.response?.data;
      if (errorData is Map) {
        final firstError = errorData.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        } else if (firstError is String) {
          throw Exception(firstError);
        }
      }
      throw Exception(e.response?.data?['detail'] ?? 'Payment verification failed.');
    }
  }
}
