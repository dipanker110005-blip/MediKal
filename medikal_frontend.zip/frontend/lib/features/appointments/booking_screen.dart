import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:js' as js;
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'appointments_provider.dart';
import 'summary_screen.dart';
import '../../core/services/api_service.dart';

class BookingScreen extends ConsumerStatefulWidget {
  final Map<String, dynamic> doctor;
  final DateTime selectedDate;
  final String selectedSlot;

  const BookingScreen({
    super.key,
    required this.doctor,
    required this.selectedDate,
    required this.selectedSlot,
  });

  @override
  ConsumerState<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends ConsumerState<BookingScreen> {
  String _consultationType = 'ONLINE';
  final _referralController = TextEditingController();
  
  double _baseFee = 0.0;
  double _totalFee = 0.0;
  bool _discountApplied = false;

  String _razorpayKeyId = '';

  @override
  void initState() {
    super.initState();
    _baseFee = double.tryParse(widget.doctor['consultation_fee']?.toString() ?? '0.0') ?? 0.0;
    _totalFee = _baseFee;
    _referralController.addListener(_applyDiscountCheck);
    _fetchRazorpayKey();
  }

  @override
  void dispose() {
    _referralController.dispose();
    super.dispose();
  }

  void _fetchRazorpayKey() async {
    try {
      final apiService = ref.read(apiServiceProvider);
      final response = await apiService.get('/api/appointments/config/');
      if (response.statusCode == 200 && response.data is Map) {
        final key = response.data['key_id'];
        if (key != null && key.toString().isNotEmpty) {
          setState(() {
            _razorpayKeyId = key.toString();
          });
        }
      }
    } catch (_) {}
  }

  void _applyDiscountCheck() {
    final code = _referralController.text.trim().toUpperCase();
    setState(() {
      if (code == 'MEDIKAL20') {
        _totalFee = _baseFee * 0.8;
        _discountApplied = true;
      } else {
        _totalFee = _baseFee;
        _discountApplied = false;
      }
    });
  }

  void _handleConfirmBooking() async {
    final formattedDate = DateFormat('yyyy-MM-dd').format(widget.selectedDate);
    
    // 1. Create the pending appointment and generate Razorpay Order
    final appointment = await ref.read(bookingStateProvider.notifier).bookAppointment(
          doctorId: widget.doctor['id'],
          date: formattedDate,
          time: widget.selectedSlot,
          consultationType: _consultationType,
          referralCode: _referralController.text.trim(),
        );

    if (appointment != null && mounted) {
      final orderId = appointment['razorpay_order_id'] ?? '';
      final appointmentId = appointment['id'] as int;
      final amountPaisa = (appointment['total_fee'] != null 
        ? (double.tryParse(appointment['total_fee'].toString()) ?? 0.0) * 100 
        : _totalFee * 100).toInt().toString();

      final keyId = _razorpayKeyId.isNotEmpty ? _razorpayKeyId : 'rzp_test_TYooMQauvdEDq5';

      // 2. Open Razorpay secure overlay
      _startRazorpayPayment(
        keyId: keyId,
        amountPaisa: amountPaisa,
        orderId: orderId,
        doctorName: widget.doctor['full_name'] ?? 'Doctor',
        amountDouble: _totalFee,
        appointmentId: appointmentId,
      );
    }
  }

  void _startRazorpayPayment({
    required String keyId,
    required String amountPaisa,
    required String orderId,
    required String doctorName,
    required double amountDouble,
    required int appointmentId,
  }) {
    try {
      js.context.callMethod('openRazorpay', [
        keyId,
        amountPaisa,
        'INR',
        'MediKal Healthcare',
        'Consultation with Dr. $doctorName',
        orderId,
        'patient@medikal.com',
        '9999999999',
        js.allowInterop((paymentId, rOrderId, signature) {
          _handleRazorpaySuccess(
            appointmentId: appointmentId,
            paymentId: paymentId,
            signature: signature,
          );
        }),
        js.allowInterop(() {
          _handleRazorpayDismiss();
        }),
      ]);
    } catch (e) {
      // Fallback for local testing if Razorpay script is blocked or offline
      debugPrint('Razorpay JS call failed: $e. Running Sandbox simulation.');
      _showMockRazorpayDialog(
        appointmentId: appointmentId,
        orderId: orderId,
        doctorName: doctorName,
        amountDouble: amountDouble,
      );
    }
  }

  void _handleRazorpaySuccess({
    required int appointmentId,
    required String paymentId,
    required String signature,
  }) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(color: AppColors.primary),
      ),
    );

    final success = await ref.read(bookingStateProvider.notifier).verifyPayment(
          appointmentId: appointmentId,
          paymentId: paymentId,
          signature: signature,
        );

    if (mounted) {
      Navigator.of(context).pop(); // close spinner
    }

    if (success && mounted) {
      ref.invalidate(patientAppointmentsProvider);
      
      final state = ref.read(bookingStateProvider);
      if (state is BookingSuccess) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (context) => AppointmentSummaryScreen(
              appointment: state.appointment,
            ),
          ),
          (route) => route.isFirst,
        );
      }
    }
  }

  void _handleRazorpayDismiss() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Payment checkout cancelled.'),
        backgroundColor: AppColors.emergency,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _showMockRazorpayDialog({
    required int appointmentId,
    required String orderId,
    required String doctorName,
    required double amountDouble,
  }) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.payment_rounded, color: AppColors.primary, size: 28),
            const SizedBox(width: 12),
            Text('Razorpay Sandbox', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Simulating Razorpay Standard Checkout overlay.', style: AppTheme.bodyMedium),
            const SizedBox(height: 12),
            Text('Doctor: Dr. $doctorName', style: AppTheme.bodySmall),
            Text('Order ID: $orderId', style: AppTheme.bodySmall),
            Text('Amount: ₹${(amountDouble * 80).toStringAsFixed(2)} (Estimated INR)', style: AppTheme.bodySmall),
            const SizedBox(height: 16),
            Text(
              'Click verify to mock a successful transaction callback.',
              style: AppTheme.bodySmall.copyWith(fontStyle: FontStyle.italic, color: AppColors.textSecondary),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              _handleRazorpayDismiss();
            },
            child: const Text('Cancel Payment'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              _handleRazorpaySuccess(
                appointmentId: appointmentId,
                paymentId: 'pay_mock_${DateTime.now().millisecondsSinceEpoch}',
                signature: 'sig_mock_${DateTime.now().millisecondsSinceEpoch}',
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
            child: const Text('Verify & Pay'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bookingState = ref.watch(bookingStateProvider);
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 600;

    ref.listen<BookingState>(bookingStateProvider, (previous, next) {
      if (next is BookingError) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.message),
            backgroundColor: AppColors.emergency,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Confirm Booking',
          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Container(
            constraints: BoxConstraints(
              maxWidth: isTablet ? 500 : double.infinity,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Doctor Summary Card
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: AppTheme.borderL,
                    border: Border.all(color: AppColors.border),
                    boxShadow: AppTheme.shadowSubtle,
                  ),
                  child: Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.border, width: 1.5),
                        ),
                        child: CircleAvatar(
                          radius: 26,
                          backgroundColor: AppColors.primaryLight,
                          backgroundImage: widget.doctor['profile_image'] != null
                              ? NetworkImage(widget.doctor['profile_image'])
                              : null,
                          child: widget.doctor['profile_image'] == null
                              ? const Icon(Icons.person_rounded, color: AppColors.primary)
                              : null,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Dr. ${widget.doctor['full_name'] ?? 'Doctor'}',
                              style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              widget.doctor['specialization'] ?? 'Specialist',
                              style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
                    .animate()
                    .fadeIn(duration: 400.ms)
                    .slideY(begin: -0.05),
                const SizedBox(height: 24),

                // Selected Schedule Info
                Text(
                  'Appointment Schedule',
                  style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: AppTheme.borderM,
                    border: Border.all(color: AppColors.border),
                    boxShadow: AppTheme.shadowSubtle,
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today_rounded, color: AppColors.primary, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          '${DateFormat('EEEE, MMM d, yyyy').format(widget.selectedDate)} at ${widget.selectedSlot}',
                          style: AppTheme.bodyMedium.copyWith(
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
                    .animate()
                    .fadeIn(delay: 100.ms, duration: 400.ms),
                const SizedBox(height: 24),

                // Consultation Type Section
                Text(
                  'Consultation Type',
                  style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _buildTypeSelector(
                      title: 'Online Video',
                      value: 'ONLINE',
                      icon: Icons.video_camera_back_outlined,
                    ),
                    const SizedBox(width: 16),
                    _buildTypeSelector(
                      title: 'In-Person Visit',
                      value: 'OFFLINE',
                      icon: Icons.store_mall_directory_outlined,
                    ),
                  ],
                )
                    .animate()
                    .fadeIn(delay: 200.ms, duration: 400.ms),
                const SizedBox(height: 24),

                // Referral Code Input
                Text(
                  'Referral / Promo Code',
                  style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _referralController,
                  textCapitalization: TextCapitalization.characters,
                  style: AppTheme.bodyMedium,
                  decoration: InputDecoration(
                    hintText: 'Enter code (e.g. MEDIKAL20)',
                    prefixIcon: const Icon(Icons.confirmation_number_outlined, color: AppColors.primary, size: 20),
                    suffixIcon: _discountApplied
                        ? const Icon(Icons.check_circle_rounded, color: AppColors.success)
                        : null,
                  ),
                ),
                if (_discountApplied) ...[
                  const SizedBox(height: 8),
                  Text(
                    '🎉 20% discount code applied successfully!',
                    style: AppTheme.bodySmall.copyWith(color: AppColors.success, fontWeight: FontWeight.w700),
                  ),
                ],
                const SizedBox(height: 28),

                // Booking Fee Details
                Container(
                  padding: const EdgeInsets.all(20.0),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight.withOpacity(0.4),
                    borderRadius: AppTheme.borderL,
                    border: Border.all(color: AppColors.primary.withOpacity(0.1)),
                    boxShadow: AppTheme.shadowSubtle,
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Consultation Fee', style: AppTheme.bodyMedium),
                          Text('\$${_baseFee.toStringAsFixed(2)}', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      if (_discountApplied) ...[
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Promo Discount (20%)', style: AppTheme.bodyMedium.copyWith(color: AppColors.success)),
                            Text('-\$${(_baseFee * 0.2).toStringAsFixed(2)}',
                                style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.success)),
                          ],
                        ),
                      ],
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12.0),
                        child: Divider(color: AppColors.border),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Total Due',
                            style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                          ),
                          Text(
                            '\$${_totalFee.toStringAsFixed(2)}',
                            style: AppTheme.h3.copyWith(
                              fontWeight: FontWeight.w800,
                              color: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                )
                    .animate()
                    .fadeIn(delay: 300.ms, duration: 400.ms),
                const SizedBox(height: 32),

                // Action Confirm Button
                ElevatedButton(
                  onPressed: bookingState is BookingLoading ? null : _handleConfirmBooking,
                  child: bookingState is BookingLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                        )
                      : const Text('Confirm & Pay securely'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTypeSelector({
    required String title,
    required String value,
    required IconData icon,
  }) {
    final isSelected = _consultationType == value;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _consultationType = value;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primaryLight.withOpacity(0.5) : AppColors.card,
            borderRadius: AppTheme.borderM,
            border: Border.all(
              color: isSelected ? AppColors.primary : AppColors.border,
              width: isSelected ? 1.5 : 1.0,
            ),
            boxShadow: AppTheme.shadowSubtle,
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? AppColors.primary : AppColors.textSecondary, size: 26),
              const SizedBox(height: 10),
              Text(
                title,
                textAlign: TextAlign.center,
                style: AppTheme.bodySmall.copyWith(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  color: isSelected ? AppColors.primary : AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
