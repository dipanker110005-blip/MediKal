import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class ClinicalIntakeScreen extends StatefulWidget {
  const ClinicalIntakeScreen({super.key});

  @override
  State<ClinicalIntakeScreen> createState() => _ClinicalIntakeScreenState();
}

class _ClinicalIntakeScreenState extends State<ClinicalIntakeScreen> {
  // Intake Form State
  final _reasonController = TextEditingController();
  final _symptomsController = TextEditingController();
  final _allergiesController = TextEditingController();
  final _medsController = TextEditingController();
  double _severity = 3.0;

  // Second Opinion State
  bool _includeLabs = true;
  bool _includeScans = true;
  bool _includeSummaries = true;
  bool _bundlePrepared = false;

  @override
  void dispose() {
    _reasonController.dispose();
    _symptomsController.dispose();
    _allergiesController.dispose();
    _medsController.dispose();
    super.dispose();
  }

  void _submitIntake() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Pre-visit clinical intake shared with your doctor.'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
      ),
    );
    Navigator.pop(context);
  }

  void _prepareSecondOpinionBundle() {
    setState(() {
      _bundlePrepared = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Dossier bundled successfully. Encrypted link generated.'),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text('Clinical Intake Hub', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
          bottom: TabBar(
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.textSecondary,
            indicatorColor: AppColors.primary,
            labelStyle: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold),
            tabs: const [
              Tab(text: 'Pre-Visit Intake', icon: Icon(Icons.description_outlined, size: 20)),
              Tab(text: 'Second Opinion', icon: Icon(Icons.folder_zip_outlined, size: 20)),
            ],
          ),
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 800),
              child: TabBarView(
                children: [
                  _buildIntakeFormView(),
                  _buildSecondOpinionView(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIntakeFormView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Info banner
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryLight.withOpacity(0.4),
              borderRadius: AppTheme.borderM,
              border: Border.all(color: AppColors.primary.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Speed up your check-in process. Prefill this questionnaire and it will be shared securely with your provider prior to your arrival.',
                    style: AppTheme.bodySmall.copyWith(color: AppColors.textPrimary, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          Text('Reason for Visit', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(
            controller: _reasonController,
            style: AppTheme.bodyMedium,
            decoration: InputDecoration(
              hintText: 'e.g. Chronic hypertension follow-up',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(height: 16),

          Text('Describe Current Symptoms', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(
            controller: _symptomsController,
            style: AppTheme.bodyMedium,
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'e.g. Mild headache in mornings, fatigue...',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(height: 16),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Severity level (1-5)', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
              Text(_severity.toInt().toString(), style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
            ],
          ),
          Slider(
            value: _severity,
            min: 1.0,
            max: 5.0,
            divisions: 4,
            activeColor: AppColors.primary,
            inactiveColor: AppColors.border,
            onChanged: (val) {
              setState(() {
                _severity = val;
              });
            },
          ),
          const SizedBox(height: 16),

          Text('Known Drug / Food Allergies', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(
            controller: _allergiesController,
            style: AppTheme.bodyMedium,
            decoration: InputDecoration(
              hintText: 'e.g. Penicillin, Peanuts (or None)',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(height: 16),

          Text('Current Daily Medications', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(
            controller: _medsController,
            style: AppTheme.bodyMedium,
            decoration: InputDecoration(
              hintText: 'e.g. Lisinopril 10mg, Metformin 500mg',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(height: 28),

          ElevatedButton(
            onPressed: _submitIntake,
            child: const Text('Submit Intake Form'),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms);
  }

  Widget _buildSecondOpinionView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Second opinion explain
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryLight.withOpacity(0.4),
              borderRadius: AppTheme.borderM,
              border: Border.all(color: AppColors.primary.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(Icons.folder_shared_outlined, color: AppColors.primary, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Need another expert opinion? Pack your medical history, recent diagnostic files, and vitals logs into a single secure dossier.',
                    style: AppTheme.bodySmall.copyWith(color: AppColors.textPrimary, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          Text('Select Files to Bundle', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          CheckboxListTile(
            title: const Text('Recent Lab Reports (e.g. CBC, Lipid Profile)', style: TextStyle(fontSize: 14)),
            value: _includeLabs,
            activeColor: AppColors.primary,
            onChanged: (val) {
              if (val != null) setState(() => _includeLabs = val);
            },
          ),
          CheckboxListTile(
            title: const Text('Imaging Scans (CT Stents, X-Ray sheets)', style: TextStyle(fontSize: 14)),
            value: _includeScans,
            activeColor: AppColors.primary,
            onChanged: (val) {
              if (val != null) setState(() => _includeScans = val);
            },
          ),
          CheckboxListTile(
            title: const Text('Hospital Discharge Summaries & Visit Notes', style: TextStyle(fontSize: 14)),
            value: _includeSummaries,
            activeColor: AppColors.primary,
            onChanged: (val) {
              if (val != null) setState(() => _includeSummaries = val);
            },
          ),

          const SizedBox(height: 24),

          ElevatedButton.icon(
            onPressed: _prepareSecondOpinionBundle,
            icon: const Icon(Icons.folder_zip_rounded, size: 18),
            label: const Text('Prepare Secure Dossier'),
          ),

          if (_bundlePrepared) ...[
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: AppTheme.borderL,
                border: Border.all(color: AppColors.border),
                boxShadow: AppTheme.shadowSubtle,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.lock_outline_rounded, color: AppColors.success, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        'Secure Packet Ready',
                        style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.success),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Dossier size: 11.7 MB. The packet has been locked with standard HIPAA-compliant 256-bit encryption.',
                    style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, height: 1.4),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Dossier link copied to clipboard.')),
                            );
                          },
                          child: const Text('Copy Link'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Dossier sent to secondary specialist.')),
                            );
                          },
                          child: const Text('Send to Doctor'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ).animate().scale(begin: const Offset(0.97, 0.97)),
          ],
        ],
      ),
    ).animate().fadeIn(duration: 300.ms);
  }
}
