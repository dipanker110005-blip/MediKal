import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'booking_screen.dart';

class DoctorProfileScreen extends StatefulWidget {
  final Map<String, dynamic> doctor;

  const DoctorProfileScreen({super.key, required this.doctor});

  @override
  State<DoctorProfileScreen> createState() => _DoctorProfileScreenState();
}

class _DoctorProfileScreenState extends State<DoctorProfileScreen> {
  late DateTime _selectedDate;
  String? _selectedSlot;
  late final ScrollController _dateScrollController;
  bool _showLeftArrow = false;
  bool _showRightArrow = true;

  final List<String> _timeSlots = const [
    '09:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '02:00 PM',
    '03:00 PM',
    '04:00 PM',
    '05:00 PM'
  ];

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now().add(const Duration(days: 1));
    _dateScrollController = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateArrowVisibility();
      _dateScrollController.addListener(_scrollListener);
    });
  }

  void _scrollListener() {
    _updateArrowVisibility();
  }

  void _updateArrowVisibility() {
    if (_dateScrollController.hasClients) {
      final maxScroll = _dateScrollController.position.maxScrollExtent;
      final currentScroll = _dateScrollController.position.pixels;
      
      final showLeft = currentScroll > 10;
      final showRight = maxScroll > 0 && currentScroll < (maxScroll - 10);
      
      if (showLeft != _showLeftArrow || showRight != _showRightArrow) {
        setState(() {
          _showLeftArrow = showLeft;
          _showRightArrow = showRight;
        });
      }
    }
  }

  void _scrollDates(bool scrollRight) {
    if (_dateScrollController.hasClients) {
      final double offset = scrollRight ? 180.0 : -180.0;
      final double target = (_dateScrollController.offset + offset)
          .clamp(0.0, _dateScrollController.position.maxScrollExtent);
          
      _dateScrollController.animateTo(
        target,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  void dispose() {
    _dateScrollController.removeListener(_scrollListener);
    _dateScrollController.dispose();
    super.dispose();
  }

  void _handleBookAppointment() {
    if (_selectedSlot == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please select an available time slot.'),
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => BookingScreen(
          doctor: widget.doctor,
          selectedDate: _selectedDate,
          selectedSlot: _selectedSlot!,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double rating = double.tryParse(widget.doctor['rating']?.toString() ?? '5.0') ?? 5.0;
    final fee = widget.doctor['consultation_fee'] ?? '0.0';
    final bio = widget.doctor['bio'] ?? 'No bio provided by the practitioner.';

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Doctor Profile',
          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 800),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Doctor Profile Card
                      Container(
                        padding: const EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: AppTheme.borderXL,
                          border: Border.all(color: AppColors.border),
                          boxShadow: AppTheme.shadowCard,
                        ),
                        child: Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColors.border, width: 2),
                              ),
                              child: CircleAvatar(
                                radius: 42,
                                backgroundColor: AppColors.primaryLight,
                                backgroundImage: widget.doctor['profile_image'] != null
                                    ? NetworkImage(widget.doctor['profile_image'])
                                    : null,
                                child: widget.doctor['profile_image'] == null
                                    ? const Icon(Icons.person_rounded, size: 42, color: AppColors.primary)
                                    : null,
                              ),
                            ),
                            const SizedBox(width: 20),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Dr. ${widget.doctor['full_name'] ?? 'Doctor'}',
                                    style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    widget.doctor['specialization'] ?? 'Specialist',
                                    style: AppTheme.bodyMedium.copyWith(
                                      color: AppColors.textSecondary,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    widget.doctor['qualification'] ?? 'M.B.B.S • MD',
                                    style: AppTheme.bodySmall.copyWith(
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                          .animate()
                          .fadeIn(duration: 400.ms)
                          .slideY(begin: 0.05),
                      
                      const SizedBox(height: 20),

                      // Stats Row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildStatCard('Rating', rating.toStringAsFixed(1), Icons.star_rounded, Colors.amber),
                          _buildStatCard('Experience', '${widget.doctor['experience'] ?? 0} yrs', Icons.work_outline_rounded, AppColors.secondary),
                          _buildStatCard('Consult Fee', '\$$fee', Icons.credit_card_rounded, AppColors.primary),
                        ],
                      )
                          .animate()
                          .fadeIn(delay: 100.ms, duration: 400.ms)
                          .scale(begin: const Offset(0.97, 0.97)),
                      
                      const SizedBox(height: 28),

                      // About Section
                      Text(
                        'About Doctor',
                        style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        bio,
                        style: AppTheme.bodyMedium.copyWith(
                          color: AppColors.textSecondary,
                          height: 1.45,
                        ),
                      )
                          .animate()
                          .fadeIn(delay: 150.ms, duration: 400.ms),
                      
                      const SizedBox(height: 28),

                      // Select Date Section
                      Text(
                        'Select Appointment Date',
                        style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildDatePicker(),
                      
                      const SizedBox(height: 28),

                      // Select Time Slots Section
                      Text(
                        'Available Time Slots',
                        style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildTimeSlotsGrid()
                          .animate()
                          .fadeIn(delay: 250.ms, duration: 400.ms),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
          
          // Sticky Bottom Action Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            decoration: BoxDecoration(
              color: Colors.white,
              border: const Border(top: BorderSide(color: AppColors.border)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.03),
                  blurRadius: 10,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 800),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _handleBookAppointment,
                      child: const Text('Continue to Booking'),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color iconColor) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4.0),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: AppTheme.borderM,
          border: Border.all(color: AppColors.border),
          boxShadow: AppTheme.shadowSubtle,
        ),
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: AppTheme.h4.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: AppTheme.bodySmall.copyWith(
                color: AppColors.textSecondary,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDatePicker() {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        SizedBox(
          height: 80,
          child: ListView.builder(
            controller: _dateScrollController,
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: 30,
            itemBuilder: (context, index) {
              final date = DateTime.now().add(Duration(days: index + 1));
              final isSelected = DateUtils.isSameDay(_selectedDate, date);
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedDate = date;
                  });
                },
                child: Container(
                  width: 65,
                  margin: const EdgeInsets.only(right: 12.0),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primary : AppColors.card,
                    borderRadius: AppTheme.borderM,
                    border: Border.all(
                      color: isSelected ? AppColors.primary : AppColors.border,
                    ),
                    boxShadow: isSelected ? [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.25),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      )
                    ] : AppTheme.shadowSubtle,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        DateFormat('E').format(date).toUpperCase(),
                        style: GoogleFonts.inter(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: isSelected ? Colors.white.withOpacity(0.85) : AppColors.textSecondary,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        DateFormat('d').format(date),
                        style: AppTheme.h4.copyWith(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: isSelected ? Colors.white : AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        
        // Left Carousel Navigation Button
        if (_showLeftArrow)
          Positioned(
            left: -12,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.border, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 8,
                    offset: const Offset(-1, 2),
                  )
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _scrollDates(false),
                  borderRadius: BorderRadius.circular(18),
                  child: const Icon(
                    Icons.chevron_left_rounded,
                    color: AppColors.textPrimary,
                    size: 22,
                  ),
                ),
              ),
            ),
          ),

        // Right Carousel Navigation Button
        if (_showRightArrow)
          Positioned(
            right: -12,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.border, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 8,
                    offset: const Offset(1, 2),
                  )
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _scrollDates(true),
                  borderRadius: BorderRadius.circular(18),
                  child: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.textPrimary,
                    size: 22,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTimeSlotsGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 2.3,
      ),
      itemCount: _timeSlots.length,
      itemBuilder: (context, index) {
        final slot = _timeSlots[index];
        final isSelected = _selectedSlot == slot;
        
        return ChoiceChip(
          label: Text(slot),
          selected: isSelected,
          onSelected: (val) {
            setState(() {
              _selectedSlot = val ? slot : null;
            });
          },
          selectedColor: AppColors.primary,
          labelStyle: AppTheme.bodySmall.copyWith(
            color: isSelected ? Colors.white : AppColors.textPrimary,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
          ),
          backgroundColor: AppColors.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          side: BorderSide(
            color: isSelected ? AppColors.primary : AppColors.border,
          ),
          showCheckmark: false,
        );
      },
    );
  }
}
