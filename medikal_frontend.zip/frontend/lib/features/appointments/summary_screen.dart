import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class DashedDivider extends StatelessWidget {
  final double height;
  final Color color;
  final double dashWidth;
  final double dashSpace;

  const DashedDivider({
    super.key,
    this.height = 1,
    this.color = AppColors.border,
    this.dashWidth = 6,
    this.dashSpace = 4,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final boxWidth = constraints.constrainWidth();
        final dashCount = (boxWidth / (dashWidth + dashSpace)).floor();
        return Flex(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          direction: Axis.horizontal,
          children: List.generate(dashCount, (_) {
            return SizedBox(
              width: dashWidth,
              height: height,
              child: DecoratedBox(
                decoration: BoxDecoration(color: color),
              ),
            );
          }),
        );
      },
    );
  }
}

class AppointmentSummaryScreen extends StatelessWidget {
  final Map<String, dynamic> appointment;

  const AppointmentSummaryScreen({super.key, required this.appointment});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isDesktop = size.width > 800;
    
    // Format date string from backend (yyyy-MM-dd)
    String dateStr = appointment['date'] ?? '';
    try {
      final date = DateTime.parse(dateStr);
      dateStr = DateFormat('EEEE, MMMM d, yyyy').format(date);
    } catch (_) {}

    final consultationType = appointment['consultation_type'] == 'ONLINE'
        ? 'Online Video'
        : 'In-Person Visit';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
            child: Container(
              constraints: BoxConstraints(
                maxWidth: isDesktop ? 500 : double.infinity,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 10),
                  // Glowing Success Circular Icon
                  Center(
                    child: Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: AppColors.successLight,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.success.withOpacity(0.12),
                            blurRadius: 20,
                            spreadRadius: 4,
                          )
                        ],
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.check_circle_rounded,
                          size: 52,
                          color: AppColors.success,
                        ),
                      ),
                    ),
                  )
                      .animate()
                      .scale(duration: 600.ms, curve: Curves.elasticOut)
                      .fadeIn(duration: 300.ms),
                  const SizedBox(height: 24),
                  
                  Text(
                    'Booking Confirmed!',
                    textAlign: TextAlign.center,
                    style: AppTheme.h2.copyWith(color: AppColors.textPrimary),
                  )
                      .animate()
                      .fadeIn(delay: 150.ms, duration: 400.ms)
                      .slideY(begin: 0.08, curve: Curves.easeOutQuad),
                  const SizedBox(height: 8),
                  Text(
                    'Your appointment has been successfully scheduled. A confirmation email with details has been sent.',
                    textAlign: TextAlign.center,
                    style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
                  )
                      .animate()
                      .fadeIn(delay: 250.ms, duration: 400.ms)
                      .slideY(begin: 0.08, curve: Curves.easeOutQuad),
                  const SizedBox(height: 32),

                  // Appointment Details Summary Ticket Card
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: AppTheme.borderL,
                      border: Border.all(color: AppColors.border),
                      boxShadow: AppTheme.shadowCard,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Ticket Header (Practitioner & Specialty)
                        Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            children: [
                              Text(
                                'Dr. ${appointment['doctor_name'] ?? 'Doctor'}',
                                style: AppTheme.h3.copyWith(color: AppColors.textPrimary),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                appointment['doctor_specialization'] ?? 'Specialist',
                                style: AppTheme.bodyMedium.copyWith(
                                  color: AppColors.primary,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                        
                        // Dashed Ticket tear-off separator line
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                          child: DashedDivider(height: 1.5, color: AppColors.border),
                        ),
                        
                        // Ticket Details list
                        Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            children: [
                              _buildDetailRow('Date', dateStr),
                              const SizedBox(height: 14),
                              _buildDetailRow('Time Slot', appointment['time'] ?? ''),
                              const SizedBox(height: 14),
                              _buildDetailRow('Consultation Type', consultationType),
                              const SizedBox(height: 14),
                              _buildDetailRow(
                                'Status', 
                                appointment['status'] != null
                                    ? (appointment['status'].toString()[0].toUpperCase() + appointment['status'].toString().substring(1).toLowerCase())
                                    : 'Confirmed',
                                valueColor: appointment['status'] == 'CONFIRMED' ? AppColors.success : AppColors.primary,
                              ),
                              const SizedBox(height: 18),
                              const Divider(color: AppColors.border, height: 1),
                              const SizedBox(height: 18),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Consultation Fee',
                                    style: AppTheme.bodyLarge.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                  Text(
                                    '\$${appointment['total_fee'] ?? '0.00'}',
                                    style: AppTheme.h3.copyWith(
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                      .animate()
                      .fadeIn(delay: 350.ms, duration: 500.ms)
                      .scale(begin: const Offset(0.97, 0.97), curve: Curves.easeOutQuad),
                  const SizedBox(height: 36),

                  // Back to Dashboard Action Button
                  SizedBox(
                    height: 56,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: AppTheme.borderM,
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        'Back to Home Dashboard',
                        style: AppTheme.buttonText.copyWith(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  )
                      .animate()
                      .fadeIn(delay: 450.ms, duration: 400.ms),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(
    String label, 
    String value, {
    Color? valueColor,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: AppTheme.bodyMedium.copyWith(
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: AppTheme.bodyMedium.copyWith(
            color: valueColor ?? AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
