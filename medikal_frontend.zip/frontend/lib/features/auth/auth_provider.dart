import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth_repository.dart';

// Authentication States
abstract class AuthState {
  const AuthState();
}

class AuthInitial extends AuthState {
  const AuthInitial();
}

class AuthLoading extends AuthState {
  const AuthLoading();
}

class Authenticated extends AuthState {
  final Map<String, dynamic> user;
  const Authenticated(this.user);
}

class Unauthenticated extends AuthState {
  const Unauthenticated();
}

class AuthError extends AuthState {
  final String message;
  const AuthError(this.message);
}

class AuthOtpRequired extends AuthState {
  final String email;
  final String? errorMessage;
  const AuthOtpRequired(this.email, {this.errorMessage});
}

// Auth State Notifier
class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _authRepository;

  AuthNotifier(this._authRepository) : super(const AuthInitial()) {
    checkAuthStatus();
  }

  // Check login status on app startup
  Future<void> checkAuthStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    
    if (token == null || token.isEmpty) {
      state = const Unauthenticated();
      return;
    }

    state = const AuthLoading();
    try {
      final profile = await _authRepository.fetchUserProfile();
      if (profile != null && profile.containsKey('user')) {
        state = Authenticated(profile['user']);
      } else {
        state = const Unauthenticated();
      }
    } catch (e) {
      state = const Unauthenticated(); // If check fails (network/invalid token)
    }
  }

  // Login action
  Future<void> login(String email, String password) async {
    state = const AuthLoading();
    try {
      final result = await _authRepository.login(email: email, password: password);
      state = Authenticated(result);
    } catch (e) {
      state = AuthError(e.toString().replaceAll('Exception: ', ''));
    }
  }



  // Patient registration action
  Future<bool> registerPatient({
    required String name,
    required String email,
    required String phone,
    required String password,
    required int age,
    required String bloodGroup,
  }) async {
    state = const AuthLoading();
    try {
      final result = await _authRepository.registerPatient(
        name: name,
        email: email,
        phone: phone,
        password: password,
        age: age,
        bloodGroup: bloodGroup,
      );
      state = Authenticated(result);
      return true;
    } catch (e) {
      state = AuthError(e.toString().replaceAll('Exception: ', ''));
      return false;
    }
  }

  // Logout action
  Future<void> logout() async {
    state = const AuthLoading();
    await _authRepository.logout();
    state = const Unauthenticated();
  }
}

// Provider definition
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final authRepository = ref.read(authRepositoryProvider);
  return AuthNotifier(authRepository);
});
