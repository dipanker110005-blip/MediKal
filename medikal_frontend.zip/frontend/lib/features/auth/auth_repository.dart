import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/services/api_service.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return AuthRepositoryImpl(apiService);
});

abstract class AuthRepository {
  Future<Map<String, dynamic>> login({required String email, required String password});
  Future<String?> sendRegistrationOTP({required String type, required String value, String? email});
  Future<bool> verifyRegistrationOTP({required String type, required String value, required String otp});
  Future<Map<String, dynamic>> registerPatient({
    required String name,
    required String email,
    required String phone,
    required String password,
    required int age,
    required String bloodGroup,
  });
  Future<Map<String, dynamic>?> fetchUserProfile();
  Future<void> logout();
}

class AuthRepositoryImpl implements AuthRepository {
  final ApiService _apiService;

  AuthRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    try {
      final response = await _apiService.post(
        '/api/auth/login/',
        data: {
          'email': email,
          'password': password,
        },
      );
      
      final data = response.data as Map<String, dynamic>;
      
      // Save JWT Tokens locally
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('access_token', data['access']);
      await prefs.setString('refresh_token', data['refresh']);
      await prefs.setString('user_role', data['role']);
      
      return data;
    } on DioException catch (e) {
      final backendMessage = e.response?.data?['detail'];
      final message = backendMessage ?? 'Login failed: [Type: ${e.type}] [Error: ${e.error}] [Msg: ${e.message}] [Status: ${e.response?.statusCode}]';
      throw Exception(message);
    }
  }

  @override
  Future<String?> sendRegistrationOTP({required String type, required String value, String? email}) async {
    try {
      final response = await _apiService.post(
        '/api/auth/register/send-otp/',
        data: {
          'type': type,
          'value': value,
          if (email != null) 'email': email,
        },
      );
      final data = response.data as Map<String, dynamic>;
      return data['debug_otp'] as String?;
    } on DioException catch (e) {
      final backendMessage = e.response?.data?['detail'];
      final message = backendMessage ?? 'Failed to send OTP: [Type: ${e.type}] [Error: ${e.error}] [Msg: ${e.message}] [Status: ${e.response?.statusCode}]';
      throw Exception(message);
    }
  }

  @override
  Future<bool> verifyRegistrationOTP({required String type, required String value, required String otp}) async {
    try {
      final response = await _apiService.post(
        '/api/auth/register/verify-otp/',
        data: {
          'type': type,
          'value': value,
          'otp': otp,
        },
      );
      final data = response.data as Map<String, dynamic>;
      return data['verified'] == true;
    } on DioException catch (e) {
      final backendMessage = e.response?.data?['detail'];
      final message = backendMessage ?? 'Verification failed: [Type: ${e.type}] [Error: ${e.error}] [Msg: ${e.message}] [Status: ${e.response?.statusCode}]';
      throw Exception(message);
    }
  }

  @override
  Future<Map<String, dynamic>> registerPatient({
    required String name,
    required String email,
    required String phone,
    required String password,
    required int age,
    required String bloodGroup,
  }) async {
    try {
      final response = await _apiService.post(
        '/api/auth/register/patient/',
        data: {
          'full_name': name,
          'email': email,
          'phone': phone,
          'password': password,
          'age': age,
          'blood_group': bloodGroup,
        },
      );
      final data = response.data as Map<String, dynamic>;

      // Save JWT Tokens locally
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('access_token', data['access']);
      await prefs.setString('refresh_token', data['refresh']);
      await prefs.setString('user_role', data['role']);

      return data;
    } on DioException catch (e) {
      final errors = e.response?.data;
      if (errors is Map) {
        final detail = errors['detail'];
        if (detail != null) {
          throw Exception(detail);
        }
        final firstError = errors.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        }
      }
      final message = 'Registration failed: [Type: ${e.type}] [Error: ${e.error}] [Msg: ${e.message}] [Status: ${e.response?.statusCode}]';
      throw Exception(message);
    }
  }

  @override
  Future<Map<String, dynamic>?> fetchUserProfile() async {
    try {
      final response = await _apiService.get('/api/auth/profile/');
      return response.data as Map<String, dynamic>;
    } on DioException {
      return null;
    }
  }

  @override
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('access_token');
    await prefs.remove('refresh_token');
    await prefs.remove('user_role');
  }
}
