import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'auth_provider.dart';
import 'auth_repository.dart';
import 'login_screen.dart';
import '../dashboard/patient_main_layout.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _ageController = TextEditingController();
  
  final _emailOtpController = TextEditingController();
  final _phoneOtpController = TextEditingController();
  
  String _selectedBloodGroup = 'O+';
  bool _obscurePassword = true;

  final List<String> _bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  // Inline OTP states
  bool _emailOtpSent = false;
  bool _phoneOtpSent = false;
  bool _emailVerified = false;
  bool _phoneVerified = false;
  bool _emailLoading = false;
  bool _phoneLoading = false;
  int _emailCooldown = 0;
  int _phoneCooldown = 0;
  Timer? _emailTimer;
  Timer? _phoneTimer;
  String? _emailDebugOtp;
  String? _phoneDebugOtp;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _ageController.dispose();
    _emailOtpController.dispose();
    _phoneOtpController.dispose();
    _emailTimer?.cancel();
    _phoneTimer?.cancel();
    super.dispose();
  }

  void _startEmailCooldown() {
    setState(() {
      _emailCooldown = 60;
      _emailOtpSent = true;
    });
    _emailTimer?.cancel();
    _emailTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_emailCooldown <= 1) {
        timer.cancel();
        setState(() {
          _emailCooldown = 0;
        });
      } else {
        setState(() {
          _emailCooldown--;
        });
      }
    });
  }

  void _startPhoneCooldown() {
    setState(() {
      _phoneCooldown = 60;
      _phoneOtpSent = true;
    });
    _phoneTimer?.cancel();
    _phoneTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_phoneCooldown <= 1) {
        timer.cancel();
        setState(() {
          _phoneCooldown = 0;
        });
      } else {
        setState(() {
          _phoneCooldown--;
        });
      }
    });
  }

  void _sendEmailOtp() async {
    final email = _emailController.text.trim();
    if (email.isEmpty || !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,6}$').hasMatch(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter a valid email address first.'), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    setState(() { _emailLoading = true; });
    try {
      final otp = await ref.read(authRepositoryProvider).sendRegistrationOTP(type: 'email', value: email);
      setState(() {
        _emailDebugOtp = otp;
      });
      _startEmailCooldown();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Verification code sent to your email.'), 
          backgroundColor: AppColors.success,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } finally {
      setState(() { _emailLoading = false; });
    }
  }

  void _verifyEmailOtp() async {
    final email = _emailController.text.trim();
    final otp = _emailOtpController.text.trim();
    if (otp.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter the 6-digit OTP code.'), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    setState(() { _emailLoading = true; });
    try {
      final verified = await ref.read(authRepositoryProvider).verifyRegistrationOTP(type: 'email', value: email, otp: otp);
      if (verified) {
        setState(() {
          _emailVerified = true;
          _emailOtpSent = false;
        });
        _emailTimer?.cancel();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Email verified successfully!'), 
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } finally {
      setState(() { _emailLoading = false; });
    }
  }

  void _sendPhoneOtp() async {
    final phone = _phoneController.text.trim();
    final email = _emailController.text.trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter a phone number first.'), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    setState(() { _phoneLoading = true; });
    try {
      final otp = await ref.read(authRepositoryProvider).sendRegistrationOTP(
        type: 'phone',
        value: phone,
        email: email.isNotEmpty ? email : null,
      );
      setState(() {
        _phoneDebugOtp = otp;
      });
      _startPhoneCooldown();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Verification code sent to your phone.'), 
          backgroundColor: AppColors.success,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } finally {
      setState(() { _phoneLoading = false; });
    }
  }

  void _verifyPhoneOtp() async {
    final phone = _phoneController.text.trim();
    final otp = _phoneOtpController.text.trim();
    if (otp.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter the 6-digit OTP code.'), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    setState(() { _phoneLoading = true; });
    try {
      final verified = await ref.read(authRepositoryProvider).verifyRegistrationOTP(type: 'phone', value: phone, otp: otp);
      if (verified) {
        setState(() {
          _phoneVerified = true;
          _phoneOtpSent = false;
        });
        _phoneTimer?.cancel();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Phone number verified successfully!'), 
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')), 
          backgroundColor: AppColors.emergency,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } finally {
      setState(() { _phoneLoading = false; });
    }
  }

  void _handleRegister() async {
    if (_formKey.currentState!.validate()) {
      if (!_emailVerified || !_phoneVerified) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Please verify both your email and phone number via OTP first.'), 
            backgroundColor: AppColors.emergency,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
        return;
      }
      await ref.read(authProvider.notifier).registerPatient(
            name: _nameController.text.trim(),
            email: _emailController.text.trim(),
            phone: _phoneController.text.trim(),
            password: _passwordController.text,
            age: int.parse(_ageController.text.trim()),
            bloodGroup: _selectedBloodGroup,
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 650;

    // Observe state changes
    ref.listen<AuthState>(authProvider, (previous, next) {
      if (next is Authenticated) {
        _passwordController.clear();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Registration successful! Welcome, ${next.user['full_name'] ?? 'User'}!'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const PatientMainLayout()),
          (route) => false,
        );
      } else if (next is AuthError) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.message),
            backgroundColor: AppColors.emergency,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Container(
            constraints: BoxConstraints(
              maxWidth: isTablet ? 540 : double.infinity,
            ),
            decoration: isTablet
                ? BoxDecoration(
                    color: AppColors.card,
                    borderRadius: AppTheme.borderXL,
                    boxShadow: AppTheme.shadowCard,
                    border: Border.all(color: AppColors.border),
                  )
                : null,
            padding: isTablet ? const EdgeInsets.all(AppTheme.spaceXXL) : EdgeInsets.zero,
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Create Account',
                    textAlign: TextAlign.center,
                    style: AppTheme.h2.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Join MediKal to secure appointments & consult our Al Assistant.',
                    textAlign: TextAlign.center,
                    style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 32),

                  // Name Field
                  TextFormField(
                    controller: _nameController,
                    keyboardType: TextInputType.name,
                    style: AppTheme.bodyMedium,
                    decoration: const InputDecoration(
                      labelText: 'Full Name',
                      prefixIcon: Icon(Icons.person_outline_rounded, color: AppColors.primary, size: 20),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter your full name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),

                  // Email Field Container with inline OTP verification
                  Container(
                    decoration: BoxDecoration(
                      color: _emailVerified ? AppColors.successLight.withOpacity(0.3) : Colors.transparent,
                      borderRadius: AppTheme.borderM,
                      border: _emailVerified ? Border.all(color: AppColors.success.withOpacity(0.3)) : null,
                    ),
                    padding: _emailVerified ? const EdgeInsets.all(AppTheme.spaceM) : EdgeInsets.zero,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          enabled: !_emailVerified,
                          style: AppTheme.bodyMedium,
                          decoration: InputDecoration(
                            labelText: 'Email Address',
                            prefixIcon: const Icon(Icons.email_outlined, color: AppColors.primary, size: 20),
                            suffixIcon: _emailVerified 
                                ? const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 22) 
                                : null,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your email';
                            }
                            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,6}$').hasMatch(value.trim())) {
                              return 'Please enter a valid email address';
                            }
                            return null;
                          },
                        ),
                        if (!_emailVerified) ...[
                          const SizedBox(height: 8),
                          if (_emailOtpSent) ...[
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    controller: _emailOtpController,
                                    keyboardType: TextInputType.number,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(6),
                                    ],
                                    decoration: const InputDecoration(
                                      labelText: 'Enter Email OTP',
                                      prefixIcon: Icon(Icons.lock_clock_outlined, color: AppColors.primary, size: 20),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: _emailLoading ? null : _verifyEmailOtp,
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                  ),
                                  child: _emailLoading 
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                      : const Text('Verify'),
                                ),
                              ],
                            ),
                            if (_emailDebugOtp != null) ...[
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: AppColors.successLight.withOpacity(0.5),
                                  borderRadius: AppTheme.borderS,
                                  border: Border.all(color: AppColors.success.withOpacity(0.2)),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.info_outline, color: AppColors.success, size: 16),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'Demo OTP: $_emailDebugOtp',
                                        style: AppTheme.bodySmall.copyWith(
                                          color: AppColors.success,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _emailCooldown > 0 ? 'Resend in ${_emailCooldown}s' : 'Didn\'t receive code?',
                                  style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                                ),
                                if (_emailCooldown == 0)
                                  TextButton(
                                    onPressed: _sendEmailOtp,
                                    child: const Text('Resend Code', style: TextStyle(fontSize: 12)),
                                  ),
                              ],
                            ),
                          ] else ...[
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton.icon(
                                onPressed: _emailLoading ? null : _sendEmailOtp,
                                icon: _emailLoading 
                                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Icon(Icons.send_rounded, size: 14),
                                label: const Text('Send Verification OTP'),
                              ),
                            ),
                          ],
                        ]
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Phone Field Container with inline OTP verification
                  Container(
                    decoration: BoxDecoration(
                      color: _phoneVerified ? AppColors.successLight.withOpacity(0.3) : Colors.transparent,
                      borderRadius: AppTheme.borderM,
                      border: _phoneVerified ? Border.all(color: AppColors.success.withOpacity(0.3)) : null,
                    ),
                    padding: _phoneVerified ? const EdgeInsets.all(AppTheme.spaceM) : EdgeInsets.zero,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextFormField(
                          controller: _phoneController,
                          keyboardType: TextInputType.phone,
                          enabled: !_phoneVerified,
                          style: AppTheme.bodyMedium,
                          decoration: InputDecoration(
                            labelText: 'Phone Number',
                            prefixIcon: const Icon(Icons.phone_outlined, color: AppColors.primary, size: 20),
                            suffixIcon: _phoneVerified 
                                ? const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 22) 
                                : null,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            return null;
                          },
                        ),
                        if (!_phoneVerified) ...[
                          const SizedBox(height: 8),
                          if (_phoneOtpSent) ...[
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    controller: _phoneOtpController,
                                    keyboardType: TextInputType.number,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(6),
                                    ],
                                    decoration: const InputDecoration(
                                      labelText: 'Enter Phone OTP',
                                      prefixIcon: Icon(Icons.lock_clock_outlined, color: AppColors.primary, size: 20),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: _phoneLoading ? null : _verifyPhoneOtp,
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                  ),
                                  child: _phoneLoading 
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                      : const Text('Verify'),
                                ),
                              ],
                            ),
                            if (_phoneDebugOtp != null) ...[
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: AppColors.successLight.withOpacity(0.5),
                                  borderRadius: AppTheme.borderS,
                                  border: Border.all(color: AppColors.success.withOpacity(0.2)),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.info_outline, color: AppColors.success, size: 16),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'Demo OTP: $_phoneDebugOtp',
                                        style: AppTheme.bodySmall.copyWith(
                                          color: AppColors.success,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _phoneCooldown > 0 ? 'Resend in ${_phoneCooldown}s' : 'Didn\'t receive code?',
                                  style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                                ),
                                if (_phoneCooldown == 0)
                                  TextButton(
                                    onPressed: _sendPhoneOtp,
                                    child: const Text('Resend Code', style: TextStyle(fontSize: 12)),
                                  ),
                              ],
                            ),
                          ] else ...[
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton.icon(
                                onPressed: _phoneLoading ? null : _sendPhoneOtp,
                                icon: _phoneLoading 
                                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Icon(Icons.send_rounded, size: 14),
                                label: const Text('Send Verification OTP'),
                              ),
                            ),
                          ],
                        ]
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Age and Blood Group side by side
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Age Field
                      Expanded(
                        flex: 4,
                        child: TextFormField(
                          controller: _ageController,
                          keyboardType: TextInputType.number,
                          style: AppTheme.bodyMedium,
                          decoration: const InputDecoration(
                            labelText: 'Age',
                            prefixIcon: Icon(Icons.calendar_today_outlined, color: AppColors.primary, size: 18),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Age required';
                            }
                            final age = int.tryParse(value);
                            if (age == null || age <= 0 || age > 120) {
                              return 'Invalid';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Blood Group Dropdown
                      Expanded(
                        flex: 5,
                        child: DropdownButtonFormField<String>(
                          value: _selectedBloodGroup,
                          style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary),
                          decoration: const InputDecoration(
                            labelText: 'Blood Group',
                            prefixIcon: Icon(Icons.bloodtype_outlined, color: AppColors.primary, size: 18),
                          ),
                          items: _bloodGroups.map((group) {
                            return DropdownMenuItem(
                              value: group,
                              child: Text(group),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setState(() {
                              _selectedBloodGroup = val!;
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Password Field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    style: AppTheme.bodyMedium,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock_outlined, color: AppColors.primary, size: 20),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                          color: AppColors.textMuted,
                          size: 20,
                        ),
                        onPressed: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a password';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 36),

                  // Register Button
                  ElevatedButton(
                    onPressed: (authState is AuthLoading || !_emailVerified || !_phoneVerified) 
                        ? null 
                        : _handleRegister,
                    child: authState is AuthLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                          )
                        : Text(
                            (!_emailVerified || !_phoneVerified) 
                                ? 'Verify Email & Phone First' 
                                : 'Register',
                          ),
                  ),
                  const SizedBox(height: 24),

                  // Route back to Login
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account? ",
                        style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (context) => const LoginScreen()),
                          );
                        },
                        child: Text(
                          'Login Here',
                          style: AppTheme.bodySmall.copyWith(
                            color: AppColors.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
