import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class MedicalFacility {
  final String name;
  final String category; // 'Hospital', 'Pharmacy', 'Lab', 'Ambulance'
  final String distance;
  final String address;
  final String phone;
  final bool isEmergency247;
  final bool isOpenNow;

  const MedicalFacility({
    required this.name,
    required this.category,
    required this.distance,
    required this.address,
    required this.phone,
    required this.isEmergency247,
    required this.isOpenNow,
  });
}

class CareFinderScreen extends StatefulWidget {
  const CareFinderScreen({super.key});

  @override
  State<CareFinderScreen> createState() => _CareFinderScreenState();
}

class _CareFinderScreenState extends State<CareFinderScreen> {
  String _selectedCategory = 'All';

  final List<String> _categories = const [
    'All',
    'Hospital',
    'Pharmacy',
    'Lab',
    'Ambulance'
  ];

  final List<MedicalFacility> _facilities = const [
    MedicalFacility(
      name: 'Metro Trauma Hospital',
      category: 'Hospital',
      distance: '0.8 miles',
      address: '742 Clinical Boulevard, Center City',
      phone: '+1 (555) 911-3000',
      isEmergency247: true,
      isOpenNow: true,
    ),
    MedicalFacility(
      name: '24/7 Wellness Pharmacy',
      category: 'Pharmacy',
      distance: '1.2 miles',
      address: '109 Apothecary Lane, East District',
      phone: '+1 (555) 322-8000',
      isEmergency247: true,
      isOpenNow: true,
    ),
    MedicalFacility(
      name: 'MediKal Diagnostic Labs',
      category: 'Lab',
      distance: '1.8 miles',
      address: '228 Hematology Way, North Plaza',
      phone: '+1 (555) 455-7000',
      isEmergency247: false,
      isOpenNow: true,
    ),
    MedicalFacility(
      name: 'Express Cardiac Ambulance Support',
      category: 'Ambulance',
      distance: 'Immediate Dispatch',
      address: 'Standby Unit 4, Downtown Sector',
      phone: '+1 (555) 911-4444',
      isEmergency247: true,
      isOpenNow: true,
    ),
    MedicalFacility(
      name: 'Mercy Community Clinic',
      category: 'Hospital',
      distance: '2.5 miles',
      address: '88 Care Parkway, West End',
      phone: '+1 (555) 677-2000',
      isEmergency247: false,
      isOpenNow: false,
    ),
    MedicalFacility(
      name: 'CareRight Neighborhood Pharmacy',
      category: 'Pharmacy',
      distance: '3.1 miles',
      address: '44 Dispensary Row, South Gate',
      phone: '+1 (555) 788-1000',
      isEmergency247: false,
      isOpenNow: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final filteredFacilities = _facilities.where((fac) {
      return _selectedCategory == 'All' || fac.category == _selectedCategory;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Nearby Care Finder', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              children: [
                // Top filter bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Locate Nearest Medical Assistance',
                        style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 38,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _categories.length,
                          itemBuilder: (context, idx) {
                            final cat = _categories[idx];
                            final isSelected = _selectedCategory == cat;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text(cat),
                                selected: isSelected,
                                selectedColor: AppColors.primary,
                                backgroundColor: AppColors.card,
                                labelStyle: AppTheme.bodySmall.copyWith(
                                  color: isSelected ? Colors.white : AppColors.textPrimary,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                                ),
                                onSelected: (val) {
                                  setState(() => _selectedCategory = cat);
                                },
                                showCheckmark: false,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                                side: BorderSide(color: isSelected ? AppColors.primary : AppColors.border),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const Divider(color: AppColors.border, height: 1),

                // Facilities List
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(24.0),
                    itemCount: filteredFacilities.length,
                    itemBuilder: (context, index) {
                      final facility = filteredFacilities[index];
                      return _buildFacilityCard(facility)
                          .animate()
                          .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                          .slideY(begin: 0.03);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFacilityCard(MedicalFacility facility) {
    IconData cardIcon = Icons.local_hospital_outlined;
    Color cardColor = AppColors.primary;
    Color lightBgColor = AppColors.primaryLight;

    switch (facility.category) {
      case 'Hospital':
        cardIcon = Icons.local_hospital_rounded;
        cardColor = AppColors.primary;
        lightBgColor = AppColors.primaryLight;
        break;
      case 'Pharmacy':
        cardIcon = Icons.local_pharmacy_rounded;
        cardColor = Colors.orange.shade700;
        lightBgColor = Colors.orange.shade50;
        break;
      case 'Lab':
        cardIcon = Icons.biotech_rounded;
        cardColor = Colors.teal.shade700;
        lightBgColor = Colors.teal.shade50;
        break;
      case 'Ambulance':
        cardIcon = Icons.airport_shuttle_rounded;
        cardColor = AppColors.emergency;
        lightBgColor = AppColors.emergencyLight;
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: lightBgColor, shape: BoxShape.circle),
                  child: Icon(cardIcon, color: cardColor, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        facility.name,
                        style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            facility.distance,
                            style: AppTheme.bodySmall.copyWith(color: AppColors.primary, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(width: 10),
                          Text('•  ${facility.category}', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
                        ],
                      ),
                    ],
                  ),
                ),
                if (facility.isEmergency247)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: AppColors.emergencyLight, borderRadius: BorderRadius.circular(10)),
                    child: Text(
                      '24/7 ER',
                      style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.bold, color: AppColors.emergency),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              facility.address,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: facility.isOpenNow ? AppColors.success : AppColors.textMuted,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  facility.isOpenNow ? 'Open Now' : 'Closed',
                  style: AppTheme.bodySmall.copyWith(
                    color: facility.isOpenNow ? AppColors.success : AppColors.textSecondary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Starting voice call to ${facility.phone}')),
                    );
                  },
                  icon: const Icon(Icons.call_rounded, size: 14),
                  label: const Text('Call'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Navigating via secure maps routing...')),
                    );
                  },
                  icon: const Icon(Icons.navigation_outlined, size: 14),
                  label: const Text('Directions'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
