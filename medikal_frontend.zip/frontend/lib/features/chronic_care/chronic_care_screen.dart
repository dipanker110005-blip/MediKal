import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class ChronicCarePlan {
  final String title;
  final String description;
  final IconData icon;
  final Color themeColor;
  final List<String> targets;
  final List<String> dailyChecklist;
  final String carePlanSummary;

  const ChronicCarePlan({
    required this.title,
    required this.description,
    required this.icon,
    required this.themeColor,
    required this.targets,
    required this.dailyChecklist,
    required this.carePlanSummary,
  });
}

class ChronicCareScreen extends StatefulWidget {
  const ChronicCareScreen({super.key});

  @override
  State<ChronicCareScreen> createState() => _ChronicCareScreenState();
}

class _ChronicCareScreenState extends State<ChronicCareScreen> {
  String _selectedPlanTitle = 'Type-2 Diabetes Management';

  final List<ChronicCarePlan> _plans = const [
    ChronicCarePlan(
      title: 'Type-2 Diabetes Management',
      description: 'Glycemic control parameters, HbA1c tracking, and medication logging.',
      icon: Icons.bloodtype_rounded,
      themeColor: AppColors.secondary,
      targets: [
        'Fasting Blood Glucose: 80 - 130 mg/dL',
        'Post-Meal Blood Glucose: < 180 mg/dL',
        'Target HbA1c: < 7.0%',
      ],
      dailyChecklist: [
        'Log fasting blood glucose reading',
        'Take Metformin (500mg) with breakfast',
        'Perform 30 minutes of cardiovascular walking',
        'Inspect feet for dry skin or minor lesions',
      ],
      carePlanSummary: 'Focus on glycemic stability via steady dietary habits, carb counting, and regular physical activity. Ensure regular kidney function tests and retinal scans every 12 months.',
    ),
    ChronicCarePlan(
      title: 'Hypertension Management',
      description: 'Systolic/diastolic targets, sodium restriction logs, and vascular protection.',
      icon: Icons.favorite_rounded,
      themeColor: AppColors.primary,
      targets: [
        'Optimal Blood Pressure: < 120/80 mmHg',
        'Acceptable Clinical Range: < 130/80 mmHg',
        'Resting Heart Rate: 60 - 90 BPM',
      ],
      dailyChecklist: [
        'Log blood pressure (morning & evening)',
        'Take Lisinopril (10mg) with water',
        'Limit total dietary sodium to < 1,500 mg',
        'Perform breathing or stress check-in exercises',
      ],
      carePlanSummary: 'Maintain peripheral arterial compliance by limiting processed salts and managing mental stressors. Immediate clinical consult is required if systolic readings exceed 180 mmHg.',
    ),
    ChronicCarePlan(
      title: 'Asthma & Airway Action Plan',
      description: 'Peak flow logs, trigger protection, and bronchodilator guidelines.',
      icon: Icons.air_rounded,
      themeColor: Colors.blueAccent,
      targets: [
        'Green Zone Peak Flow: 80% - 100% of personal best',
        'Yellow Zone Peak Flow: 50% - 79% of personal best',
        'Red Zone Peak Flow: < 50% (Emergency status)',
      ],
      dailyChecklist: [
        'Measure and log peak expiratory flow (PEF)',
        'Check inhaler doses remaining (Albuterol)',
        'Avoid known triggers (pollen, severe dust)',
        'Sanitize bedroom spaces regularly',
      ],
      carePlanSummary: 'Optimize lung elasticity. Use your rescue inhaler (Albuterol) immediately if experiencing chest tightness or yellow zone peak flow values. Carry your inhaler at all times.',
    ),
    ChronicCarePlan(
      title: 'Thyroid Care (Hypothyroidism)',
      description: 'Hormone replacement adherence, TSH monitoring, and energy logs.',
      icon: Icons.shield_rounded,
      themeColor: Colors.purple,
      targets: [
        'Target TSH levels: 0.4 - 4.0 mIU/L',
        'Target Free T4: 0.9 - 1.7 ng/dL',
      ],
      dailyChecklist: [
        'Take Levothyroxine on empty stomach (30 mins before breakfast)',
        'Avoid calcium or iron supplements within 4 hours of dose',
        'Log energy levels and muscle fatigue states',
      ],
      carePlanSummary: 'Maintain stable hormone replacement levels. Levothyroxine absorption is highly sensitive to food and other supplements. Blood tests for TSH are required every 6 to 12 weeks during dose adjustments.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final activePlan = _plans.firstWhere((p) => p.title == _selectedPlanTitle, orElse: () => _plans.first);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Chronic Care Plans', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Top Plan Selector
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Select Active Care Program',
                        style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 38,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _plans.length,
                          itemBuilder: (context, idx) {
                            final plan = _plans[idx];
                            final isSelected = _selectedPlanTitle == plan.title;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text(plan.title.split(' ')[0] == 'Type-2' ? 'Diabetes' : plan.title.split(' ')[0]),
                                selected: isSelected,
                                selectedColor: plan.themeColor,
                                backgroundColor: AppColors.card,
                                labelStyle: AppTheme.bodySmall.copyWith(
                                  color: isSelected ? Colors.white : AppColors.textPrimary,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                                ),
                                onSelected: (val) {
                                  setState(() => _selectedPlanTitle = plan.title);
                                },
                                showCheckmark: false,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                                side: BorderSide(color: isSelected ? plan.themeColor : AppColors.border),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const Divider(color: AppColors.border, height: 1),

                // Selected Care Plan Detail View
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Care Plan Description Card
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: AppTheme.borderXL,
                            border: Border.all(color: AppColors.border),
                            boxShadow: AppTheme.shadowCard,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: activePlan.themeColor.withOpacity(0.08),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(activePlan.icon, color: activePlan.themeColor, size: 24),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          activePlan.title,
                                          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          'Assigned Clinical Program',
                                          style: AppTheme.bodySmall.copyWith(color: activePlan.themeColor, fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Text(
                                activePlan.description,
                                style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
                              ),
                            ],
                          ),
                        ).animate().fadeIn(duration: 400.ms),

                        const SizedBox(height: 24),

                        // Targets Section
                        _buildSectionCard(
                          title: 'Physiological Care Targets',
                          icon: Icons.track_changes_rounded,
                          iconColor: Colors.orange.shade700,
                          bgColor: Colors.orange.shade50,
                          content: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: activePlan.targets.map((target) => _buildTargetRow(target)).toList(),
                          ),
                        ).animate().fadeIn(duration: 400.ms, delay: 100.ms),

                        const SizedBox(height: 16),

                        // Checklists
                        _buildSectionCard(
                          title: 'Daily Care Checklist',
                          icon: Icons.checklist_rounded,
                          iconColor: Colors.teal.shade700,
                          bgColor: Colors.teal.shade50,
                          content: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: activePlan.dailyChecklist.map((item) => _buildChecklistRow(item)).toList(),
                          ),
                        ).animate().fadeIn(duration: 400.ms, delay: 150.ms),

                        const SizedBox(height: 16),

                        // Doctor Care Plan Instructions
                        _buildSectionCard(
                          title: 'Clinical Care Summary',
                          icon: Icons.assignment_outlined,
                          iconColor: AppColors.primary,
                          bgColor: AppColors.primaryLight,
                          content: Text(
                            activePlan.carePlanSummary,
                            style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, height: 1.45),
                          ),
                        ).animate().fadeIn(duration: 400.ms, delay: 200.ms),

                        const SizedBox(height: 24),

                        // Red Warning Box
                        Container(
                          padding: const EdgeInsets.all(16.0),
                          decoration: BoxDecoration(
                            color: AppColors.emergencyLight.withOpacity(0.4),
                            borderRadius: AppTheme.borderM,
                            border: Border.all(color: AppColors.emergency.withOpacity(0.25), width: 1.2),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 18),
                                  const SizedBox(width: 10),
                                  Text(
                                    'When to Seek Urgent Care',
                                    style: AppTheme.bodyLarge.copyWith(
                                      color: AppColors.textPrimary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13.5,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                activePlan.title.contains('Diabetes')
                                    ? 'Seek emergency consult immediately if blood glucose readings fall below 55 mg/dL (severe hypoglycemia) or exceed 250 mg/dL with symptoms of confusion, deep rapid breathing, or fruity breath odor.'
                                    : activePlan.title.contains('Hypertension')
                                        ? 'Immediate medical intervention is required if your systolic BP exceeds 180 mmHg or diastolic exceeds 120 mmHg, particularly if accompanied by chest pain, headache, or visual blur.'
                                        : 'Contact emergency medical dispatch immediately if you experience severe shortness of breath that does not improve within 10 minutes of using your Albuterol rescue inhaler.',
                                style: AppTheme.bodyMedium.copyWith(
                                  color: AppColors.textPrimary,
                                  fontSize: 12.5,
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ).animate().fadeIn(duration: 400.ms, delay: 250.ms),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required Widget content,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6.0),
                decoration: BoxDecoration(color: bgColor, shape: BoxShape.circle),
                child: Icon(icon, color: iconColor, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
              ),
            ],
          ),
          const SizedBox(height: 16),
          content,
        ],
      ),
    );
  }

  Widget _buildTargetRow(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          const Icon(Icons.check_circle_rounded, size: 16, color: Colors.green),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _buildChecklistRow(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          const Icon(Icons.circle_outlined, size: 16, color: AppColors.textMuted),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary))),
        ],
      ),
    );
  }
}
