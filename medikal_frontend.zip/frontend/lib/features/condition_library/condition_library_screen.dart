import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class ConditionArticle {
  final String title;
  final String category;
  final String snippet;
  final String symptoms;
  final String lifestyleAdvice;
  final String whenToSeeDoctor;

  const ConditionArticle({
    required this.title,
    required this.category,
    required this.snippet,
    required this.symptoms,
    required this.lifestyleAdvice,
    required this.whenToSeeDoctor,
  });
}

class ConditionLibraryScreen extends StatefulWidget {
  const ConditionLibraryScreen({super.key});

  @override
  State<ConditionLibraryScreen> createState() => _ConditionLibraryScreenState();
}

class _ConditionLibraryScreenState extends State<ConditionLibraryScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  final List<ConditionArticle> _articles = const [
    ConditionArticle(
      title: 'Understanding Hypertension (High Blood Pressure)',
      category: 'Cardiology',
      snippet: 'Often called the "silent killer," hypertension occurs when the force of blood pushing against arterial walls is persistently elevated.',
      symptoms: 'Typically asymptomatic. Severe elevation can cause headaches, shortness of breath, nosebleeds, or dizziness.',
      lifestyleAdvice: 'Limit dietary sodium to < 1,500mg daily, engage in 150 mins of moderate physical activity weekly, and manage emotional stress.',
      whenToSeeDoctor: 'Schedule regular checkups. Seek emergency services if systolic BP exceeds 180 mmHg with chest pains or visual blur.',
    ),
    ConditionArticle(
      title: 'Managing Type-2 Diabetes Mellitus',
      category: 'Endocrinology',
      snippet: 'A chronic metabolic disorder characterized by high blood glucose levels caused by cellular insulin resistance.',
      symptoms: 'Increased thirst, frequent urination, fatigue, blurred vision, and slow-healing sores.',
      lifestyleAdvice: 'Focus on low-glycemic foods, carb counting, maintaining a healthy weight, and daily foot checks.',
      whenToSeeDoctor: 'Coordinate regular checks with your endocrinologist. Seek urgent care if experiencing deep/rapid breathing or confusion.',
    ),
    ConditionArticle(
      title: 'Asthma Trigger Management',
      category: 'Pulmonology',
      snippet: 'A respiratory condition characterized by narrowing and inflammation of the airways, often triggered by environmental allergens.',
      symptoms: 'Wheezing, coughing, chest tightness, and acute shortness of breath.',
      lifestyleAdvice: 'Monitor daily peak flow rates, maintain clean dust-free indoor spaces, and avoid tobacco smoke.',
      whenToSeeDoctor: 'Immediate emergency care is required if rescue inhaler doses fail to stabilize breathing difficulty.',
    ),
    ConditionArticle(
      title: 'Thyroid Hormonal Imbalance (Hypothyroidism)',
      category: 'Endocrinology',
      snippet: 'Occurs when the thyroid gland produces insufficient thyroid hormones, slowing general cellular metabolism.',
      symptoms: 'Fatigue, unexplained weight gain, sensitivity to cold, dry skin, and muscle weakness.',
      lifestyleAdvice: 'Take thyroid replacement medication (Levothyroxine) on an empty stomach. Ensure regular blood TSH level screenings.',
      whenToSeeDoctor: 'Consult a physician if you experience persistent symptoms or sudden changes in heart rate.',
    ),
    ConditionArticle(
      title: 'Migraine Headers & Aura Triggers',
      category: 'Neurology',
      snippet: 'A neurological condition characterized by severe pulsating headaches, typically affecting one side of the head.',
      symptoms: 'Throbbing pain, nausea, visual auric disturbances, and sensitivity to light or sound.',
      lifestyleAdvice: 'Keep a trigger diary (identifying foods, sleep patterns, bright screens), stay hydrated, and maintain regular sleep cycles.',
      whenToSeeDoctor: 'Consult a neurologist for chronic headaches. Seek emergency help for a sudden "thunderclap" headache.',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _articles.where((art) {
      final query = _searchQuery.toLowerCase();
      return art.title.toLowerCase().contains(query) ||
          art.snippet.toLowerCase().contains(query) ||
          art.category.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Condition Reference Library', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              children: [
                // Top Search Bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: AppTheme.borderM,
                      border: Border.all(color: AppColors.border),
                      boxShadow: AppTheme.shadowSubtle,
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: (val) => setState(() => _searchQuery = val),
                      style: AppTheme.bodyMedium,
                      decoration: InputDecoration(
                        hintText: 'Search conditions, symptoms, medical areas...',
                        prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textMuted),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        hintStyle: AppTheme.bodyMedium.copyWith(color: AppColors.textMuted),
                      ),
                    ),
                  ),
                ),

                // Clinical Disclaimer Box
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight.withOpacity(0.4),
                      borderRadius: AppTheme.borderM,
                      border: Border.all(color: AppColors.primary.withOpacity(0.2)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 16),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'EDUCATIONAL INFORMATION ONLY • NOT DIAGNOSTIC\nThis guide serves strictly to inform. It does not replace professional clinical diagnosis or consultation.',
                            style: GoogleFonts.inter(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Articles List
                Expanded(
                  child: filtered.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.all(24.0),
                          itemCount: filtered.length,
                          itemBuilder: (context, index) {
                            final article = filtered[index];
                            return _buildArticleCard(article)
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                                .slideY(begin: 0.03);
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.menu_book_rounded, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 16),
            Text('No Articles Found', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('No reference articles match your search parameters. Try searching "hypertension" or "asthma".', textAlign: TextAlign.center, style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }

  Widget _buildArticleCard(ConditionArticle article) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: InkWell(
        onTap: () => _showArticleDetails(article),
        borderRadius: AppTheme.borderL,
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      article.category.toUpperCase(),
                      style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.bold, color: AppColors.primary),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                article.title,
                style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              Text(
                article.snippet,
                style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showArticleDetails(ConditionArticle article) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          padding: const EdgeInsets.all(24.0),
          child: ListView(
            controller: scrollController,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                    child: const Icon(Icons.menu_book_rounded, color: AppColors.primary, size: 24),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(article.title, style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
                        Text('Clinical Specialty: ${article.category}', style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: AppColors.border),
              const SizedBox(height: 16),

              Text('Condition Description', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(article.snippet, style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary)),
              const SizedBox(height: 20),

              Text('Prevalent Symptoms', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(article.symptoms, style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary)),
              const SizedBox(height: 20),

              Text('Lifestyle & Management Advice', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(article.lifestyleAdvice, style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary)),
              const SizedBox(height: 20),

              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: AppColors.emergencyLight.withOpacity(0.4),
                  borderRadius: AppTheme.borderM,
                  border: Border.all(color: AppColors.emergency.withOpacity(0.2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          'When to Call your Doctor',
                          style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      article.whenToSeeDoctor,
                      style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }
}
