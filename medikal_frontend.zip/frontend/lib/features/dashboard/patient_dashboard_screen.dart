import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../auth/auth_provider.dart';
import '../doctors/doctors_screen.dart';
import '../emergency/emergency_screen.dart';
import '../ai_assistant/ai_chat_screen.dart';
import '../medicines/medicines_hub_screen.dart';
import '../notifications/notifications_screen.dart';
import '../notifications/notifications_provider.dart';
import '../doctors/doctors_provider.dart';
import '../landing/landing_screen.dart';
import '../profile/profile_screen.dart';
import '../health_records/health_records_screen.dart';
import '../vitals/vitals_screen.dart';
import '../reminders/reminders_screen.dart';
import '../family_profiles/family_profiles_screen.dart';
import '../care_finder/care_finder_screen.dart';
import '../chronic_care/chronic_care_screen.dart';
import '../emergency/offline_emergency_card_screen.dart';
import '../condition_library/condition_library_screen.dart';
import '../appointments/clinical_intake_screen.dart';
import '../appointments/appointments_provider.dart';
import '../appointments/appointments_repository.dart';
import 'package:intl/intl.dart';

class PatientDashboardScreen extends ConsumerStatefulWidget {
  const PatientDashboardScreen({super.key});

  @override
  ConsumerState<PatientDashboardScreen> createState() => _PatientDashboardScreenState();
}

class _PatientDashboardScreenState extends ConsumerState<PatientDashboardScreen> {
  late final ScrollController _portalsScrollController;
  late final ScrollController _specialistsScrollController;
  bool _isMockCancelled = false;

  @override
  void initState() {
    super.initState();
    _portalsScrollController = ScrollController();
    _specialistsScrollController = ScrollController();
  }

  @override
  void dispose() {
    _portalsScrollController.dispose();
    _specialistsScrollController.dispose();
    super.dispose();
  }

  String _getServiceSubtitle(String title) {
    switch (title) {
      case 'Bookings':
        return 'Manage schedules';
      case 'Doctors':
        return 'Find specialists';
      case 'Emergency':
        return 'Instant dispatch';
      case 'Medicines':
        return 'Home delivery';
      case 'Records':
        return 'Medical history';
      case 'Vitals':
        return 'BP, glucose logs';
      case 'Reminders':
        return 'Pill & refill alerts';
      case 'Family':
        return 'Manage profiles';
      case 'Care Finder':
        return 'Clinics & ERs';
      case 'Chronic Care':
        return 'Target plans';
      case 'ICE Card':
        return 'Offline info';
      case 'Library':
        return 'Condition guide';
      case 'Intake':
        return 'Pre-visit check';
      default:
        return 'Access services';
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);
    String patientName = 'Patient';
    
    if (authState is Authenticated) {
      patientName = authState.user['full_name'] ?? 'Patient';
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1000),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 1. Greeting & Wellness Status Welcome Bar
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Hi, $patientName',
                                style: GoogleFonts.outfit(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  color: AppColors.textPrimary,
                                  letterSpacing: -0.6,
                                ),
                              ),
                              const SizedBox(width: 6),
                              const Text('👋', style: TextStyle(fontSize: 22)),
                            ],
                          ),
                          const SizedBox(height: 5),
                          // Premium Wellness Meter
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFD1FAE5), // Soft emerald green
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                    color: AppColors.success,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'TODAY\'S HEALTH SCORE: OPTIMAL',
                                  style: GoogleFonts.inter(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    color: const Color(0xFF065F46), // Dark green text
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          // Styled Notification Icon
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              border: Border.all(color: AppColors.border, width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF0F172A).withOpacity(0.03),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                )
                              ],
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.notifications_none_rounded, size: 22, color: AppColors.textPrimary),
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(builder: (context) => const NotificationsScreen()),
                                    );
                                  },
                                ),
                                Consumer(
                                  builder: (context, ref, child) {
                                    final unreadCount = ref.watch(unreadNotificationsCountProvider);
                                    if (unreadCount == 0) return const SizedBox();
                                    return Positioned(
                                      top: 8,
                                      right: 8,
                                      child: Container(
                                        padding: const EdgeInsets.all(4.0),
                                        decoration: const BoxDecoration(color: AppColors.emergency, shape: BoxShape.circle),
                                        constraints: const BoxConstraints(minWidth: 12, minHeight: 12),
                                        child: Text(
                                          unreadCount.toString(),
                                          style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Avatar Menu
                          PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'profile') {
                                Navigator.of(context).push(
                                  MaterialPageRoute(builder: (context) => const ProfileScreen()),
                                );
                              } else if (value == 'logout') {
                                _showLogoutDialog(context);
                              }
                            },
                            offset: const Offset(0, 52),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            itemBuilder: (context) => [
                              PopupMenuItem(
                                value: 'profile',
                                child: Row(
                                  children: [
                                    const Icon(Icons.person_outline_rounded, color: AppColors.textPrimary, size: 18),
                                    const SizedBox(width: 12),
                                    Text('Profile', style: AppTheme.bodyMedium),
                                  ],
                                ),
                              ),
                              const PopupMenuDivider(),
                              PopupMenuItem(
                                value: 'logout',
                                child: Row(
                                  children: [
                                    const Icon(Icons.logout_rounded, color: AppColors.emergency, size: 18),
                                    const SizedBox(width: 12),
                                    Text(
                                      'Logout', 
                                      style: AppTheme.bodyMedium.copyWith(
                                        color: AppColors.emergency, 
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColors.primary.withOpacity(0.15), width: 2),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF0F172A).withOpacity(0.04),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  )
                                ],
                              ),
                              child: CircleAvatar(
                                radius: 20,
                                backgroundColor: AppColors.primaryLight,
                                child: Text(
                                  patientName.isNotEmpty ? patientName[0].toUpperCase() : 'P',
                                  style: GoogleFonts.outfit(
                                    color: AppColors.primary,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.05),
                  
                  const SizedBox(height: 24),

                  // 2. Airbnb-style Floating Pill Search Bar
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.white, width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF0F172A).withOpacity(0.05),
                          blurRadius: 18,
                          offset: const Offset(0, 6),
                        )
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 6.0, vertical: 4.0),
                    child: Row(
                      children: [
                        const SizedBox(width: 16),
                        const Icon(Icons.search_rounded, color: AppColors.primary, size: 22),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            textInputAction: TextInputAction.search,
                            style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                            onSubmitted: (query) {
                              ref.read(searchQueryProvider.notifier).state = query;
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                              );
                            },
                            decoration: InputDecoration(
                              hintText: 'Search doctors, specialties, clinics...',
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(vertical: 12.0),
                              hintStyle: AppTheme.bodyMedium.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        // Filter decorative pill (Airbnb touch)
                        InkWell(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                            );
                          },
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.tune_rounded,
                              size: 16,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 80.ms, duration: 400.ms).slideY(begin: 0.04),
                  
                  const SizedBox(height: 24),

                  // 3. Sleek Authoritative Emergency Panel
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppColors.emergency.withOpacity(0.12), width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.emergency.withOpacity(0.03),
                          blurRadius: 14,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.emergencyLight,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.emergency_rounded, color: AppColors.emergency, size: 20),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Emergency Hotline',
                                style: GoogleFonts.outfit(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.emergency,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Immediate trauma support & paramedic dispatch.',
                                style: AppTheme.bodySmall.copyWith(
                                  color: AppColors.textSecondary,
                                  fontSize: 11.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const EmergencyScreen()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.emergency,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            elevation: 0,
                          ),
                          child: Text(
                            'Get Help',
                            style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 140.ms, duration: 400.ms).slideY(begin: 0.04),

                  const SizedBox(height: 24),

                  // 4. Netflix-style AI Triage Card (Dark gradient background with glow effects)
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F172A), Color(0xFF0F766E)], // Dark Slate to Calm Teal
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.25),
                          blurRadius: 24,
                          offset: const Offset(0, 12),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Stack(
                        children: [
                          Positioned(
                            bottom: -50,
                            right: -50,
                            child: Container(
                              width: 180,
                              height: 180,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.04),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(24.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(Icons.auto_awesome_rounded, color: Colors.amber, size: 12),
                                          const SizedBox(width: 6),
                                          Text(
                                            'CLINICAL AI CHAT',
                                            style: GoogleFonts.inter(
                                              fontSize: 9,
                                              fontWeight: FontWeight.w900,
                                              color: Colors.white,
                                              letterSpacing: 1.0,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    // Animated voice waveform simulation
                                    Row(
                                      children: List.generate(4, (index) {
                                        return Container(
                                          width: 3,
                                          height: (index % 2 == 0) ? 14.0 : 8.0,
                                          margin: const EdgeInsets.symmetric(horizontal: 1.5),
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.6),
                                            borderRadius: BorderRadius.circular(2),
                                          ),
                                        );
                                      }),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 20),
                                Text(
                                  'AI Symptom Triage',
                                  style: GoogleFonts.outfit(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: -0.3,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Receive intelligent triage assessments, symptom severity scores, and clinical safety guidance instantly.',
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    color: const Color(0xFF94A3B8), // slate 400
                                    height: 1.45,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 24),
                                Row(
                                  children: [
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        onPressed: () {
                                          Navigator.of(context).push(
                                            MaterialPageRoute(builder: (context) => const AIChatScreen()),
                                          );
                                        },
                                        icon: const Icon(Icons.chat_bubble_outline_rounded, size: 16),
                                        label: const Text('Start Urgent Assessment'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.white,
                                          foregroundColor: const Color(0xFF0F172A),
                                          padding: const EdgeInsets.symmetric(vertical: 14),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 14),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.12),
                                        shape: BoxShape.circle,
                                      ),
                                      child: IconButton(
                                        icon: const Icon(Icons.mic_none_rounded, color: Colors.white, size: 22),
                                        onPressed: () {
                                          Navigator.of(context).push(
                                            MaterialPageRoute(builder: (context) => const AIChatScreen()),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ).animate().fadeIn(delay: 200.ms, duration: 400.ms).slideY(begin: 0.04),

                  const SizedBox(height: 32),

                  // 5. Spotify-style Horizontal Categories scroller
                  Text(
                    'Clinical Portals',
                    style: GoogleFonts.outfit(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _DesktopHorizontalScroller(
                    height: 98,
                    controller: _portalsScrollController,
                    child: ListView(
                      controller: _portalsScrollController,
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      children: [
                        _buildCategoryCard(
                          context,
                          title: 'Doctors',
                          icon: Icons.people_outline_rounded,
                          color: AppColors.secondary,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Bookings',
                          icon: Icons.calendar_today_rounded,
                          color: AppColors.primary,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Medicines',
                          icon: Icons.local_pharmacy_outlined,
                          color: Colors.orange.shade700,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const MedicinesHubScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Records',
                          icon: Icons.folder_shared_outlined,
                          color: Colors.teal.shade700,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const HealthRecordsScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Vitals',
                          icon: Icons.favorite_border_rounded,
                          color: Colors.redAccent,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const VitalsScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Reminders',
                          icon: Icons.alarm_rounded,
                          color: Colors.indigo.shade600,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const RemindersScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Family',
                          icon: Icons.family_restroom_rounded,
                          color: Colors.pink.shade600,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const FamilyProfilesScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Care Finder',
                          icon: Icons.near_me_rounded,
                          color: Colors.deepOrange,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const CareFinderScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Chronic Care',
                          icon: Icons.healing_rounded,
                          color: Colors.green.shade700,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const ChronicCareScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'ICE Card',
                          icon: Icons.contact_emergency_rounded,
                          color: AppColors.emergency,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const OfflineEmergencyCardScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Library',
                          icon: Icons.menu_book_rounded,
                          color: Colors.amber.shade900,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const ConditionLibraryScreen()),
                            );
                          },
                        ),
                        _buildCategoryCard(
                          context,
                          title: 'Intake',
                          icon: Icons.assignment_turned_in_rounded,
                          color: Colors.blueGrey,
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => const ClinicalIntakeScreen()),
                            );
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  // 6. Airbnb-style Recommended Specialists
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Recommended Specialists',
                            style: GoogleFonts.outfit(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: AppColors.textPrimary,
                              letterSpacing: -0.4,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Highly rated practitioners matching your profile',
                            style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontSize: 11.5),
                          ),
                        ],
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => const DoctorsScreen()),
                          );
                        },
                        child: Text(
                          'View all',
                          style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.primary),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  
                  // Horizontal Doctors List
                  _DesktopHorizontalScroller(
                    height: 180,
                    controller: _specialistsScrollController,
                    child: ListView(
                      controller: _specialistsScrollController,
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      children: [
                        _buildDoctorCard(
                          context,
                          name: 'Dr. Sarah Jenkins',
                          specialty: 'Cardiologist',
                          rating: '4.9',
                          reviews: '124',
                          avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&auto=format&fit=crop&q=80',
                        ),
                        _buildDoctorCard(
                          context,
                          name: 'Dr. Michael Chen',
                          specialty: 'Dermatologist',
                          rating: '4.8',
                          reviews: '98',
                          avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&auto=format&fit=crop&q=80',
                        ),
                        _buildDoctorCard(
                          context,
                          name: 'Dr. Emily Taylor',
                          specialty: 'Pediatrician',
                          rating: '5.0',
                          reviews: '187',
                          avatarUrl: 'https://images.unsplash.com/photo-1594824813573-246434de83fb?w=200&auto=format&fit=crop&q=80',
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  // 7. Upcoming Appointment (Boarding Pass Ticket Style)
                  Text(
                    'Upcoming Appointment',
                    style: GoogleFonts.outfit(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _buildUpcomingAppointmentCard(context),
                  const SizedBox(height: 100), // Pinned padding so bottom nav doesn't overlap text
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF1F5F9), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(0.02),
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: 18, color: color),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.outfit(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    Text(
                      _getServiceSubtitle(title),
                      style: AppTheme.bodySmall.copyWith(fontSize: 10, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDoctorCard(
    BuildContext context, {
    required String name,
    required String specialty,
    required String rating,
    required String reviews,
    required String avatarUrl,
  }) {
    return Container(
      width: 260,
      margin: const EdgeInsets.only(right: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => const DoctorsScreen()),
            );
          },
          borderRadius: BorderRadius.circular(22),
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.network(
                    avatarUrl,
                    width: 72,
                    height: 90,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 72,
                        height: 90,
                        color: AppColors.primaryLight,
                        child: const Icon(Icons.person, color: AppColors.primary),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.primaryLight,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          specialty.toUpperCase(),
                          style: GoogleFonts.inter(
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.outfit(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, color: Colors.amber, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            rating,
                            style: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '($reviews)',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              color: AppColors.textMuted,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Next: Today 2:30 PM',
                        style: GoogleFonts.inter(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.success,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUpcomingAppointmentCard(BuildContext context) {
    final appointmentsAsync = ref.watch(patientAppointmentsProvider);

    return appointmentsAsync.when(
      data: (appointments) {
        final upcoming = appointments.where((apt) =>
          apt['status'] == 'CONFIRMED' || apt['status'] == 'PENDING'
        ).toList();

        if (upcoming.isEmpty) {
          return _buildEmptyAppointmentsCard(context);
        }

        final apt = upcoming.first;
        final id = apt['id'] as int;
        final doctorName = apt['doctor_name'] ?? 'Doctor';
        final specialization = apt['doctor_specialization'] ?? 'Specialist';
        
        final rawDate = apt['date'] ?? '';
        String formattedDate = rawDate;
        try {
          final dateObj = DateFormat('yyyy-MM-dd').parse(rawDate);
          formattedDate = DateFormat('EEE, MMM d').format(dateObj);
        } catch (_) {}

        final timeSlot = apt['time'] ?? '10:30 AM';
        final status = apt['status'] ?? 'CONFIRMED';
        final consultationType = apt['consultation_type'] ?? 'ONLINE';
        final totalFee = double.tryParse(apt['total_fee']?.toString() ?? '0.0') ?? 0.0;

        return _buildUpcomingAppointmentCardDetails(
          context,
          id: id,
          doctorName: doctorName,
          specialization: specialization,
          date: formattedDate,
          time: '$timeSlot (Est. 30 min)',
          status: status,
          consultationType: consultationType,
          totalFee: totalFee,
          isMock: false,
        );
      },
      loading: () => const Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      ),
      error: (err, stack) {
        return _buildEmptyAppointmentsCard(context);
      },
    );
  }

  Widget _buildUpcomingAppointmentCardDetails(
    BuildContext context, {
    required int? id,
    required String doctorName,
    required String specialization,
    required String date,
    required String time,
    required String status,
    required String consultationType,
    required double totalFee,
    required bool isMock,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(0.04),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFFF1F5F9), width: 2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Image.network(
                        'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&auto=format&fit=crop&q=80',
                        width: 44,
                        height: 44,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          doctorName,
                          style: GoogleFonts.outfit(
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '$specialization • ${consultationType == 'ONLINE' ? 'Online Consult' : 'In-Person Visit'}',
                          style: AppTheme.bodySmall.copyWith(
                            color: AppColors.textSecondary,
                            fontSize: 11.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      status.toUpperCase(),
                      style: GoogleFonts.inter(
                        color: AppColors.primary,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Digital Ticket Boarding Pass Dotted Divider line
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: List.generate(30, (index) {
                  return Expanded(
                    child: Container(
                      height: 1,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      color: const Color(0xFFCBD5E1), // slate 300
                    ),
                  );
                }),
              ),
            ),
            // Ticket timing details
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.calendar_month_outlined, size: 16, color: AppColors.primary),
                      const SizedBox(width: 8),
                      Text(
                        date,
                        style: GoogleFonts.inter(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(Icons.access_time_rounded, size: 16, color: AppColors.primary),
                      const SizedBox(width: 8),
                      Text(
                        time,
                        style: GoogleFonts.inter(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.border),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    isMock ? 'Demo Sandbox Ticket' : 'Secure Online Booking',
                    style: AppTheme.bodySmall.copyWith(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _showCancelConfirmationDialog(
                      context,
                      appointmentId: id,
                      doctorName: doctorName,
                      date: date,
                      time: time,
                      totalFee: totalFee,
                      isMock: isMock,
                    ),
                    icon: const Icon(Icons.cancel_outlined, size: 16, color: AppColors.emergency),
                    label: Text(
                      'Cancel Appointment',
                      style: GoogleFonts.outfit(
                        color: AppColors.emergency,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyAppointmentsCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(0.04),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.calendar_today_outlined,
              color: AppColors.primary,
              size: 32,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'No Upcoming Appointments',
            style: GoogleFonts.outfit(
              fontWeight: FontWeight.w800,
              fontSize: 16,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Keep track of your scheduled consultations and check-ups here.',
            textAlign: TextAlign.center,
            style: AppTheme.bodySmall.copyWith(
              color: AppColors.textSecondary,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const DoctorsScreen()),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            icon: const Icon(Icons.search_rounded, size: 18),
            label: Text(
              'Discover Specialists',
              style: GoogleFonts.outfit(
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showCancelConfirmationDialog(
    BuildContext context, {
    required int? appointmentId,
    required String doctorName,
    required String date,
    required String time,
    required double totalFee,
    required bool isMock,
  }) async {
    final deduction = totalFee * 0.2;
    final refund = totalFee * 0.8;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 28),
            const SizedBox(width: 12),
            Text(
              'Cancel Appointment',
              style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Are you sure you want to cancel your consultation with Dr. $doctorName?',
              style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.emergency.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.emergency.withOpacity(0.2)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Amount Paid:', style: AppTheme.bodySmall),
                      Text('\$${totalFee.toStringAsFixed(2)}', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Cancellation Fee (20%):', style: AppTheme.bodySmall.copyWith(color: AppColors.emergency)),
                      Text(
                        '-\$${deduction.toStringAsFixed(2)}',
                        style: AppTheme.bodySmall.copyWith(color: AppColors.emergency, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const Divider(height: 16, color: AppColors.border),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Refund Amount (80%):', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                      Text(
                        '\$${refund.toStringAsFixed(2)}',
                        style: AppTheme.bodySmall.copyWith(color: AppColors.success, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              '⚠️ Note: 20% of the money paid will be deducted upon cancellation as per hospital policy.',
              style: AppTheme.bodySmall.copyWith(
                color: AppColors.textSecondary,
                fontSize: 10.5,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(
              'No, Keep It',
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.emergency,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(
              'Yes, Cancel',
              style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );

    if (confirm == true && context.mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );

      try {
        if (isMock || appointmentId == null) {
          await Future.delayed(const Duration(seconds: 1));
          if (context.mounted) {
            Navigator.of(context).pop(); // close loader
            setState(() {
              _isMockCancelled = true;
            });
            ref.read(notificationsProvider.notifier).addLocalNotification(
              title: 'Consultation Cancelled',
              body: 'Your appointment with Dr. $doctorName on $date at $time has been cancelled.',
            );
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Demo Booking with Dr. $doctorName on $date at $time cancelled. Refund of \$${refund.toStringAsFixed(2)} processed.'),
                backgroundColor: AppColors.success,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        } else {
          await ref.read(appointmentsRepositoryProvider).cancelAppointment(appointmentId);
          ref.invalidate(patientAppointmentsProvider);
          setState(() {
            _isMockCancelled = true;
          });
          ref.read(notificationsProvider.notifier).addLocalNotification(
            title: 'Consultation Cancelled',
            body: 'Your appointment with Dr. $doctorName on $date at $time has been cancelled.',
          );
          ref.read(notificationsProvider.notifier).fetchNotifications();
          if (context.mounted) {
            Navigator.of(context).pop(); // close loader
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Appointment with Dr. $doctorName on $date at $time cancelled successfully.'),
                backgroundColor: AppColors.success,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        }
      } catch (e) {
        if (context.mounted) {
          Navigator.of(context).pop(); // close loader
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to cancel appointment: ${e.toString().replaceAll('Exception: ', '')}'),
              backgroundColor: AppColors.emergency,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    }
  }


  void _showLogoutDialog(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Logout', style: AppTheme.h3),
        content: Text('Are you sure you want to logout of MediKal?', style: AppTheme.bodyMedium),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: AppColors.emergency),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await ref.read(authProvider.notifier).logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LandingScreen()),
          (route) => false,
        );
      }
    }
  }
}

class _DesktopHorizontalScroller extends StatefulWidget {
  final Widget child;
  final ScrollController controller;
  final double height;

  const _DesktopHorizontalScroller({
    required this.child,
    required this.controller,
    required this.height,
  });

  @override
  State<_DesktopHorizontalScroller> createState() => _DesktopHorizontalScrollerState();
}

class _DesktopHorizontalScrollerState extends State<_DesktopHorizontalScroller> {
  bool _showLeftArrow = false;
  bool _showRightArrow = false;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateArrowVisibility();
      widget.controller.addListener(_scrollListener);
    });
  }

  @override
  void dispose() {
    widget.controller.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    _updateArrowVisibility();
  }

  void _updateArrowVisibility() {
    if (!mounted) return;
    if (widget.controller.hasClients) {
      final maxScroll = widget.controller.position.maxScrollExtent;
      final currentScroll = widget.controller.position.pixels;

      final showLeft = currentScroll > 10;
      final showRight = currentScroll < maxScroll - 10;

      if (showLeft != _showLeftArrow || showRight != _showRightArrow) {
        setState(() {
          _showLeftArrow = showLeft;
          _showRightArrow = showRight;
        });
      }
    }
  }

  void _scroll(double offset) {
    if (widget.controller.hasClients) {
      final double target = (widget.controller.offset + offset)
          .clamp(0.0, widget.controller.position.maxScrollExtent);
      widget.controller.animateTo(
        target,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) => _updateArrowVisibility());

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          SizedBox(
            height: widget.height,
            child: widget.child,
          ),
          // Left Arrow
          if (_showLeftArrow && _isHovered)
            Positioned(
              left: -16,
              top: 0,
              bottom: 0,
              child: Center(
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.95),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      )
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => _scroll(-260),
                      child: const Icon(
                        Icons.chevron_left_rounded,
                        color: AppColors.textPrimary,
                        size: 24,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          // Right Arrow
          if (_showRightArrow && _isHovered)
            Positioned(
              right: -16,
              top: 0,
              bottom: 0,
              child: Center(
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.95),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      )
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => _scroll(260),
                      child: const Icon(
                        Icons.chevron_right_rounded,
                        color: AppColors.textPrimary,
                        size: 24,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
