import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../auth/auth_provider.dart';
import '../landing/landing_screen.dart';
import 'patient_dashboard_screen.dart';
import '../ai_assistant/ai_chat_screen.dart';
import '../profile/profile_screen.dart';
import '../doctors/doctors_screen.dart';
import '../emergency/emergency_screen.dart';

class PatientMainLayout extends ConsumerStatefulWidget {
  const PatientMainLayout({super.key});

  @override
  ConsumerState<PatientMainLayout> createState() => _PatientMainLayoutState();
}

class _PatientMainLayoutState extends ConsumerState<PatientMainLayout> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const PatientDashboardScreen(),
    const DoctorsScreen(),
    const EmergencyScreen(),
    const AIChatScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    // Listen to changes in authentication state to redirect on session termination
    ref.listen<AuthState>(authProvider, (previous, next) {
      if (next is Unauthenticated) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LandingScreen()),
          (route) => false,
        );
      }
    });

    final authState = ref.watch(authProvider);
    if (authState is Unauthenticated) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LandingScreen()),
          (route) => false,
        );
      });
    }

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: IndexedStack(
              index: _currentIndex,
              children: _screens,
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 16,
            child: Container(
              height: 72,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0F172A).withOpacity(0.08),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                  BoxShadow(
                    color: const Color(0xFF0F172A).withOpacity(0.02),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: Row(
                  children: [
                    _buildNavItem(0, Icons.home_rounded, Icons.home_outlined, 'Home'),
                    _buildNavItem(1, Icons.people_rounded, Icons.people_outline_rounded, 'Doctors'),
                    _buildNavItem(2, Icons.emergency_rounded, Icons.emergency_outlined, 'Emergency', isEmergency: true),
                    _buildNavItem(3, Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded, 'AI Helper'),
                    _buildNavItem(4, Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(int index, IconData activeIcon, IconData inactiveIcon, String label, {bool isEmergency = false}) {
    final isSelected = _currentIndex == index;
    
    // Dynamic color selection
    Color itemColor;
    if (isEmergency) {
      itemColor = AppColors.emergency;
    } else if (isSelected) {
      itemColor = AppColors.primary;
    } else {
      itemColor = AppColors.textSecondary;
    }

    return Expanded(
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            setState(() {
              _currentIndex = index;
            });
          },
          child: Center(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: isSelected && !isEmergency
                  ? BoxDecoration(
                      color: AppColors.primary.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                    )
                  : null,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    isSelected ? activeIcon : inactiveIcon,
                    color: itemColor,
                    size: 20,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 9.5,
                      fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                      color: itemColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
