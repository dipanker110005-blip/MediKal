import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import 'doctor_portal_provider.dart';

class DoctorAppointmentsScreen extends ConsumerWidget {
  const DoctorAppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appointmentsState = ref.watch(doctorAppointmentsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(
          'Manage Consultations',
          style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.primary),
            onPressed: () => ref.read(doctorAppointmentsProvider.notifier).fetchAppointments(),
          ),
        ],
      ),
      body: SafeArea(
        child: appointmentsState.isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : appointmentsState.error != null
                ? _buildErrorWidget(ref, appointmentsState.error!)
                : appointmentsState.appointments.isEmpty
                    ? _buildEmptyWidget()
                    : RefreshIndicator(
                        onRefresh: () => ref.read(doctorAppointmentsProvider.notifier).fetchAppointments(),
                        child: ListView.builder(
                          padding: const EdgeInsets.all(24.0),
                          itemCount: appointmentsState.appointments.length,
                          itemBuilder: (context, index) {
                            final appointment = appointmentsState.appointments[index];
                            return _buildAppointmentCard(context, ref, appointment)
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 100).ms)
                                .slideY(begin: 0.05);
                          },
                        ),
                      ),
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.05),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.calendar_month_outlined,
                size: 80,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'No Consultations Found',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            const Text(
              'You have no pending or past appointments scheduled on the system.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorWidget(WidgetRef ref, String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 60, color: AppColors.emergency),
            const SizedBox(height: 16),
            const Text(
              'Failed to load schedule',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.emergency),
            ),
            const SizedBox(height: 8),
            Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => ref.read(doctorAppointmentsProvider.notifier).fetchAppointments(),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppointmentCard(BuildContext context, WidgetRef ref, Map<String, dynamic> appointment) {
    final appointmentId = appointment['id'];
    final patientName = appointment['patient_name'] ?? 'Patient';
    final date = appointment['date'] ?? '';
    final time = appointment['time'] ?? '';
    final type = appointment['consultation_type'] ?? 'ONLINE';
    final status = appointment['status'] ?? 'PENDING';
    final fee = appointment['total_fee']?.toString() ?? '0.00';

    DateTime? dateObj;
    try {
      dateObj = DateTime.tryParse(date);
    } catch (_) {}
    final formattedDate = dateObj != null ? DateFormat('EEEE, MMM dd').format(dateObj) : date;

    DateTime? timeObj;
    try {
      timeObj = DateFormat('HH:mm:ss').parse(time);
    } catch (_) {
      try {
        timeObj = DateFormat('HH:mm').parse(time);
      } catch (_) {}
    }
    final formattedTime = timeObj != null ? DateFormat('hh:mm a').format(timeObj) : time;

    final isActive = status == 'PENDING' || status == 'CONFIRMED';

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 20.0),
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      patientName,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Consultation #$appointmentId',
                      style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 4.0),
                      decoration: BoxDecoration(
                        color: type == 'ONLINE' ? Colors.indigo.withOpacity(0.08) : Colors.teal.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6.0),
                      ),
                      child: Text(
                        type,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: type == 'ONLINE' ? Colors.indigo : Colors.teal,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.emergency, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () => _deleteAppointment(context, ref, appointmentId),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(color: AppColors.border),
            const SizedBox(height: 12),

            Row(
              children: [
                const Icon(Icons.calendar_month_outlined, size: 16, color: AppColors.primary),
                const SizedBox(width: 8),
                Text(
                  '$formattedDate at $formattedTime',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.payments_outlined, size: 16, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Text(
                  'Consultation Fee: \$$fee',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.info_outline, size: 16, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Text(
                  'Status: ',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                Text(
                  status,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: status == 'COMPLETED'
                        ? Colors.green
                        : status == 'PENDING'
                            ? Colors.orange
                            : status == 'CONFIRMED'
                                ? AppColors.primary
                                : AppColors.emergency,
                  ),
                ),
              ],
            ),

            if (isActive) ...[
              const SizedBox(height: 20),
              const Divider(color: AppColors.border),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _updateStatus(context, ref, appointmentId, 'CANCELLED'),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.emergency, width: 1.5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                        padding: const EdgeInsets.symmetric(vertical: 12.0),
                      ),
                      child: const Text('Cancel Consult', style: TextStyle(color: AppColors.emergency, fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _updateStatus(context, ref, appointmentId, 'COMPLETED'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                        padding: const EdgeInsets.symmetric(vertical: 12.0),
                        elevation: 0,
                      ),
                      child: const Text('Complete Consult', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _updateStatus(BuildContext context, WidgetRef ref, int id, String status) async {
    final actionText = status == 'COMPLETED' ? 'complete' : 'cancel';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${actionText.toUpperCase()} CONSULTATION'),
        content: Text('Are you sure you want to mark this consultation as $actionText?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Go Back'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: status == 'COMPLETED' ? Colors.green : AppColors.emergency),
            child: Text('Yes, $status'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final errorMsg = await ref.read(doctorAppointmentsProvider.notifier).updateStatus(id, status);
      if (context.mounted) {
        if (errorMsg == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Consultation status updated to $status!'),
              backgroundColor: status == 'COMPLETED' ? Colors.green : AppColors.emergency,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to update status: $errorMsg'),
              backgroundColor: AppColors.emergency,
            ),
          );
        }
      }
    }
  }

  void _deleteAppointment(BuildContext context, WidgetRef ref, int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('DELETE CONSULTATION'),
        content: const Text('Are you sure you want to permanently delete this consultation from your records?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Go Back'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: AppColors.emergency),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final errorMsg = await ref.read(doctorAppointmentsProvider.notifier).deleteAppointment(id);
      if (context.mounted) {
        if (errorMsg == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Consultation deleted successfully!'),
              backgroundColor: AppColors.emergency,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to delete: $errorMsg'),
              backgroundColor: AppColors.emergency,
            ),
          );
        }
      }
    }
  }
}
