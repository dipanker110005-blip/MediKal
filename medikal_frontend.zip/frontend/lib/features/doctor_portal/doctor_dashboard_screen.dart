import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import 'doctor_portal_provider.dart';

class DoctorDashboardScreen extends ConsumerWidget {
  const DoctorDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileState = ref.watch(doctorProfileProvider);
    final appointmentsState = ref.watch(doctorAppointmentsProvider);

    final doctorName = profileState.user?['full_name'] ?? 'Doctor';
    final rating = profileState.doctorInfo?['rating']?.toString() ?? '5.0';
    final onlineStatus = profileState.doctorInfo?['online_status'] ?? false;

    final completedCount = appointmentsState.appointments
        .where((app) => app['status'] == 'COMPLETED')
        .length;
    final pendingCount = appointmentsState.appointments
        .where((app) => app['status'] == 'PENDING')
        .length;

    final todayStr = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final todayAppointments = appointmentsState.appointments
        .where((app) => app['date'] == todayStr)
        .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: profileState.isLoading || appointmentsState.isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : RefreshIndicator(
                onRefresh: () async {
                  ref.read(doctorProfileProvider.notifier).fetchDoctorProfile();
                  ref.read(doctorAppointmentsProvider.notifier).fetchAppointments();
                  ref.read(doctorAnalyticsProvider.notifier).fetchAnalytics();
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Welcome back,',
                                style: TextStyle(fontSize: 14, color: AppColors.textSecondary),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Dr. $doctorName 👋',
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          _buildOnlineStatusSwitch(ref, onlineStatus),
                        ],
                      )
                          .animate()
                          .fadeIn(duration: 400.ms)
                          .slideY(begin: -0.1),
                      const SizedBox(height: 28),

                      _buildStatsGrid(completedCount, rating, pendingCount),
                      const SizedBox(height: 36),

                      const Text(
                        'Today\'s Schedule',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 16),

                      todayAppointments.isEmpty
                          ? _buildEmptyTodayWidget()
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: todayAppointments.length,
                              itemBuilder: (context, index) {
                                final appointment = todayAppointments[index];
                                return _buildTodayAppointmentCard(appointment)
                                    .animate()
                                    .fadeIn(duration: 300.ms, delay: (index * 100).ms)
                                    .slideY(begin: 0.05);
                              },
                            ),
                      const SizedBox(height: 36),

                      const Text(
                        'Performance Analytics',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 16),

                      _buildAnalyticsDashboard(ref),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildOnlineStatusSwitch(WidgetRef ref, bool isOnline) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 6.0),
      decoration: BoxDecoration(
        color: isOnline ? Colors.green.withOpacity(0.1) : AppColors.card,
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: isOnline ? Colors.green.withOpacity(0.3) : AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: isOnline ? Colors.green : Colors.grey,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            isOnline ? 'Online' : 'Offline',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: isOnline ? Colors.green : AppColors.textSecondary,
            ),
          ),
          const SizedBox(width: 4),
          Switch(
            value: isOnline,
            onChanged: (val) {
              ref.read(doctorProfileProvider.notifier).toggleOnlineStatus(val);
            },
            activeColor: Colors.green,
            activeTrackColor: Colors.green.withOpacity(0.2),
            inactiveThumbColor: Colors.grey,
            inactiveTrackColor: Colors.grey.withOpacity(0.2),
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsGrid(int completed, String rating, int pending) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard('Completed', completed.toString(), Icons.check_circle_outline_rounded, Colors.green),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard('Rating', rating, Icons.star_border_rounded, Colors.orange),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard('Pending', pending.toString(), Icons.hourglass_empty_rounded, Colors.blue),
        ),
      ],
    )
        .animate()
        .fadeIn(delay: 100.ms, duration: 400.ms)
        .scale(begin: const Offset(0.95, 0.95));
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      elevation: 0,
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 12.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(height: 14),
            Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyTodayWidget() {
    return Card(
      elevation: 0,
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: const Padding(
        padding: EdgeInsets.symmetric(vertical: 40.0, horizontal: 24.0),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.calendar_today_rounded, size: 50, color: AppColors.border),
              SizedBox(height: 16),
              Text(
                'No consultations scheduled today',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
              ),
              SizedBox(height: 4),
              Text(
                'Enjoy your day off!',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTodayAppointmentCard(Map<String, dynamic> appointment) {
    final patientName = appointment['patient_name'] ?? 'Patient';
    final time = appointment['time'] ?? '';
    final type = appointment['consultation_type'] ?? 'ONLINE';
    final status = appointment['status'] ?? 'PENDING';

    DateTime? timeObj;
    try {
      timeObj = DateFormat('HH:mm:ss').parse(time);
    } catch (_) {
      try {
        timeObj = DateFormat('HH:mm').parse(time);
      } catch (_) {}
    }
    final formattedTime = timeObj != null ? DateFormat('hh:mm a').format(timeObj) : time;

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12.0),
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Column(
                children: [
                  const Icon(Icons.access_time_rounded, size: 16, color: AppColors.primary),
                  const SizedBox(height: 4),
                  Text(
                    formattedTime,
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    patientName,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
                        decoration: BoxDecoration(
                          color: type == 'ONLINE' ? Colors.indigo.withOpacity(0.05) : Colors.teal.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: Text(
                          type,
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.bold,
                            color: type == 'ONLINE' ? Colors.indigo : Colors.teal,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        status,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: status == 'COMPLETED'
                              ? Colors.green
                              : status == 'PENDING'
                                  ? Colors.orange
                                  : AppColors.emergency,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.border),
          ],
        ),
      ),
    );
  }

  // Doctor Performance Analytics dashboard builders
  Widget _buildAnalyticsDashboard(WidgetRef ref) {
    final analyticsState = ref.watch(doctorAnalyticsProvider);

    if (analyticsState.isLoading) {
      return Card(
        elevation: 0,
        color: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: BorderSide(color: AppColors.border),
        ),
        child: const Padding(
          padding: EdgeInsets.all(40.0),
          child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
        ),
      );
    }

    if (analyticsState.error != null) {
      return Card(
        elevation: 0,
        color: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: BorderSide(color: AppColors.border),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const Icon(Icons.error_outline_rounded, color: AppColors.emergency, size: 36),
              const SizedBox(height: 12),
              const Text('Could not load analytics details', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              const SizedBox(height: 6),
              Text(analyticsState.error!, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary), textAlign: TextAlign.center),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => ref.read(doctorAnalyticsProvider.notifier).fetchAnalytics(),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    final data = analyticsState.data;
    final timeline = data['earnings_timeline'] as List<dynamic>? ?? [];
    final typeBreakdown = data['type_breakdown'] as Map<String, dynamic>? ?? {};

    return Column(
      children: [
        _buildEarningsTimelineCard(timeline),
        const SizedBox(height: 16),
        _buildConsultationTypeSplitCard(typeBreakdown),
      ],
    )
        .animate()
        .fadeIn(delay: 200.ms, duration: 400.ms)
        .slideY(begin: 0.04);
  }

  Widget _buildEarningsTimelineCard(List<dynamic> timeline) {
    if (timeline.isEmpty) {
      return Card(
        elevation: 0,
        color: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: BorderSide(color: AppColors.border),
        ),
        child: const Padding(
          padding: EdgeInsets.all(24.0),
          child: Center(
            child: Text(
              'No earnings timeline available.',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ),
        ),
      );
    }

    final List<FlSpot> spots = [];
    double maxEarnings = 100.0;
    for (int i = 0; i < timeline.length; i++) {
      final earn = double.parse((timeline[i]['earnings'] ?? 0).toString());
      if (earn > maxEarnings) maxEarnings = earn;
      spots.add(FlSpot(i.toDouble(), earn));
    }

    return Card(
      elevation: 0,
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 20, 20, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(left: 8.0, bottom: 16.0),
              child: Text(
                'Earning Timeline (30 Days)',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
              ),
            ),
            SizedBox(
              height: 150,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: FlTitlesData(
                    show: true,
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (value, meta) {
                          return Text(
                            '\$${value.toStringAsFixed(0)}',
                            style: const TextStyle(fontSize: 8, color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                          );
                        },
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          int idx = value.toInt();
                          if (idx >= 0 && idx < timeline.length) {
                            if (idx == 0 || idx == timeline.length ~/ 2 || idx == timeline.length - 1) {
                              String date = timeline[idx]['date'] ?? '';
                              if (date.length >= 10) date = date.substring(5); // Show MM-DD
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                space: 6.0,
                                child: Text(
                                  date,
                                  style: const TextStyle(fontSize: 8.5, color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                                ),
                              );
                            }
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  minX: 0,
                  maxX: (spots.length - 1).toDouble(),
                  minY: 0,
                  maxY: maxEarnings * 1.15,
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: Colors.green,
                      barWidth: 2.5,
                      isStrokeCapRound: true,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: Colors.green.withOpacity(0.08),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConsultationTypeSplitCard(Map<String, dynamic> breakdown) {
    final online = double.parse((breakdown['ONLINE'] ?? 0).toString());
    final offline = double.parse((breakdown['OFFLINE'] ?? 0).toString());
    final total = online + offline;

    if (total == 0) {
      return Card(
        elevation: 0,
        color: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: BorderSide(color: AppColors.border),
        ),
        child: const Padding(
          padding: EdgeInsets.all(24.0),
          child: Center(
            child: Text(
              'No consultation mode stats available.',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ),
        ),
      );
    }

    return Card(
      elevation: 0,
      color: AppColors.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
        side: BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            SizedBox(
              width: 80,
              height: 80,
              child: PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 20,
                  sections: [
                    if (online > 0)
                      PieChartSectionData(color: Colors.indigo, value: online, title: '${((online/total)*100).toStringAsFixed(0)}%', radius: 16, showTitle: true, titleStyle: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white)),
                    if (offline > 0)
                      PieChartSectionData(color: Colors.teal, value: offline, title: '${((offline/total)*100).toStringAsFixed(0)}%', radius: 16, showTitle: true, titleStyle: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white)),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Consultation Mode',
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.indigo, shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      const Text('Online Video', style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                      const Spacer(),
                      Text(online.toInt().toString(), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.teal, shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      const Text('In-Person Visit', style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                      const Spacer(),
                      Text(offline.toInt().toString(), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
