import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'doctor_portal_repository.dart';

class DoctorAppointmentsState {
  final List<dynamic> appointments;
  final bool isLoading;
  final String? error;

  DoctorAppointmentsState({
    required this.appointments,
    required this.isLoading,
    this.error,
  });

  factory DoctorAppointmentsState.initial() => DoctorAppointmentsState(
        appointments: [],
        isLoading: false,
        error: null,
      );

  DoctorAppointmentsState copyWith({
    List<dynamic>? appointments,
    bool? isLoading,
    String? error,
  }) {
    return DoctorAppointmentsState(
      appointments: appointments ?? this.appointments,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class DoctorAppointmentsNotifier extends StateNotifier<DoctorAppointmentsState> {
  final DoctorPortalRepository _repository;

  DoctorAppointmentsNotifier(this._repository) : super(DoctorAppointmentsState.initial()) {
    fetchAppointments();
  }

  Future<void> fetchAppointments() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final appointments = await _repository.fetchAppointments();
      state = state.copyWith(appointments: appointments, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<String?> updateStatus(int appointmentId, String newStatus) async {
    try {
      await _repository.updateAppointmentStatus(appointmentId, newStatus);
      fetchAppointments();
      return null;
    } catch (e) {
      String errorMsg = e.toString();
      if (errorMsg.startsWith('Exception: ')) {
        errorMsg = errorMsg.substring(11);
      }
      return errorMsg;
    }
  }

  Future<String?> deleteAppointment(int appointmentId) async {
    try {
      await _repository.deleteAppointment(appointmentId);
      final updatedList = state.appointments.where((a) => a['id'] != appointmentId).toList();
      state = state.copyWith(appointments: updatedList);
      fetchAppointments();
      return null;
    } catch (e) {
      String errorMsg = e.toString();
      if (errorMsg.startsWith('Exception: ')) {
        errorMsg = errorMsg.substring(11);
      }
      return errorMsg;
    }
  }
}

final doctorAppointmentsProvider =
    StateNotifierProvider<DoctorAppointmentsNotifier, DoctorAppointmentsState>((ref) {
  final repository = ref.read(doctorPortalRepositoryProvider);
  return DoctorAppointmentsNotifier(repository);
});

class DoctorProfileState {
  final Map<String, dynamic>? user;
  final Map<String, dynamic>? doctorInfo;
  final bool isLoading;
  final bool isSaving;
  final String? error;

  DoctorProfileState({
    this.user,
    this.doctorInfo,
    required this.isLoading,
    required this.isSaving,
    this.error,
  });

  factory DoctorProfileState.initial() => DoctorProfileState(
        user: null,
        doctorInfo: null,
        isLoading: false,
        isSaving: false,
        error: null,
      );

  DoctorProfileState copyWith({
    Map<String, dynamic>? user,
    Map<String, dynamic>? doctorInfo,
    bool? isLoading,
    bool? isSaving,
    String? error,
  }) {
    return DoctorProfileState(
      user: user ?? this.user,
      doctorInfo: doctorInfo ?? this.doctorInfo,
      isLoading: isLoading ?? this.isLoading,
      isSaving: isSaving ?? this.isSaving,
      error: error ?? this.error,
    );
  }
}

class DoctorProfileNotifier extends StateNotifier<DoctorProfileState> {
  final DoctorPortalRepository _repository;

  DoctorProfileNotifier(this._repository) : super(DoctorProfileState.initial()) {
    fetchDoctorProfile();
  }

  Future<void> fetchDoctorProfile() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _repository.fetchDoctorProfile();
      state = state.copyWith(
        user: response['user'],
        doctorInfo: response['profile'],
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> toggleOnlineStatus(bool online) async {
    state = state.copyWith(isSaving: true, error: null);
    try {
      final response = await _repository.updateOnlineStatus(online);
      state = state.copyWith(
        user: response['user'],
        doctorInfo: response['profile'],
        isSaving: false,
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isSaving: false);
    }
  }
}

final doctorProfileProvider =
    StateNotifierProvider<DoctorProfileNotifier, DoctorProfileState>((ref) {
  final repository = ref.read(doctorPortalRepositoryProvider);
  return DoctorProfileNotifier(repository);
});

class DoctorAnalyticsState {
  final Map<String, dynamic> data;
  final bool isLoading;
  final String? error;

  DoctorAnalyticsState({
    required this.data,
    required this.isLoading,
    this.error,
  });

  factory DoctorAnalyticsState.initial() => DoctorAnalyticsState(
        data: {},
        isLoading: false,
        error: null,
      );

  DoctorAnalyticsState copyWith({
    Map<String, dynamic>? data,
    bool? isLoading,
    String? error,
  }) {
    return DoctorAnalyticsState(
      data: data ?? this.data,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class DoctorAnalyticsNotifier extends StateNotifier<DoctorAnalyticsState> {
  final DoctorPortalRepository _repository;

  DoctorAnalyticsNotifier(this._repository) : super(DoctorAnalyticsState.initial()) {
    fetchAnalytics();
  }

  Future<void> fetchAnalytics() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final data = await _repository.fetchDoctorAnalytics();
      state = state.copyWith(data: data, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
}

final doctorAnalyticsProvider =
    StateNotifierProvider<DoctorAnalyticsNotifier, DoctorAnalyticsState>((ref) {
  final repository = ref.read(doctorPortalRepositoryProvider);
  return DoctorAnalyticsNotifier(repository);
});
