import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final doctorPortalRepositoryProvider = Provider<DoctorPortalRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return DoctorPortalRepositoryImpl(apiService);
});

abstract class DoctorPortalRepository {
  Future<Map<String, dynamic>> fetchDoctorProfile();
  Future<Map<String, dynamic>> updateOnlineStatus(bool online);
  Future<List<dynamic>> fetchAppointments();
  Future<Map<String, dynamic>> updateAppointmentStatus(int appointmentId, String status);
  Future<void> deleteAppointment(int appointmentId);
  Future<Map<String, dynamic>> fetchDoctorAnalytics();
}

class DoctorPortalRepositoryImpl implements DoctorPortalRepository {
  final ApiService _apiService;

  DoctorPortalRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> fetchDoctorProfile() async {
    try {
      final response = await _apiService.get('/api/auth/profile/');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load doctor profile.');
    }
  }

  @override
  Future<Map<String, dynamic>> updateOnlineStatus(bool online) async {
    try {
      final response = await _apiService.put(
        '/api/auth/profile/',
        data: {'online_status': online},
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to toggle status.');
    }
  }

  @override
  Future<List<dynamic>> fetchAppointments() async {
    try {
      final response = await _apiService.get('/api/appointments/');
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to fetch doctor appointments.');
    }
  }

  @override
  Future<Map<String, dynamic>> updateAppointmentStatus(int appointmentId, String status) async {
    try {
      final response = await _apiService.patch(
        '/api/appointments/$appointmentId/',
        data: {'status': status},
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      final errorData = e.response?.data;
      if (errorData is Map) {
        final firstError = errorData.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        } else if (firstError is String) {
          throw Exception(firstError);
        }
      }
      throw Exception(e.response?.data?['detail'] ?? 'Failed to update appointment status.');
    }
  }

  @override
  Future<void> deleteAppointment(int appointmentId) async {
    try {
      await _apiService.delete('/api/appointments/$appointmentId/');
    } on DioException catch (e) {
      final errorData = e.response?.data;
      if (errorData is Map) {
        final firstError = errorData.values.first;
        if (firstError is List) {
          throw Exception(firstError.first);
        } else if (firstError is String) {
          throw Exception(firstError);
        }
      }
      throw Exception(e.response?.data?['detail'] ?? 'Failed to delete appointment.');
    }
  }

  @override
  Future<Map<String, dynamic>> fetchDoctorAnalytics() async {
    try {
      final response = await _apiService.get('/api/analytics/doctor/');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load doctor analytics.');
    }
  }
}
