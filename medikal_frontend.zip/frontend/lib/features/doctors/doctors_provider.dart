import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'doctors_repository.dart';

// Provider to manage the selected specialization filter
final selectedSpecialtyProvider = StateProvider<String>((ref) => 'All');

// Provider to manage the search query text
final searchQueryProvider = StateProvider<String>((ref) => '');

// Provider to fetch lists based on the selected filter and search query
final doctorsListProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final repository = ref.read(doctorsRepositoryProvider);
  final filter = ref.watch(selectedSpecialtyProvider);
  final search = ref.watch(searchQueryProvider).trim().toLowerCase();
  
  final doctors = await repository.fetchDoctors(specialization: filter);
  if (search.isEmpty) {
    return doctors;
  }
  
  return doctors.where((doc) {
    final name = (doc['full_name'] ?? '').toString().toLowerCase();
    final spec = (doc['specialization'] ?? '').toString().toLowerCase();
    return name.contains(search) || spec.contains(search);
  }).toList();
});
