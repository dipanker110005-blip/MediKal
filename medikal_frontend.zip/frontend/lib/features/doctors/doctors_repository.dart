import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final doctorsRepositoryProvider = Provider<DoctorsRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return DoctorsRepositoryImpl(apiService);
});

abstract class DoctorsRepository {
  Future<List<Map<String, dynamic>>> fetchDoctors({String? specialization});
  Future<Map<String, dynamic>> fetchDoctorDetails({required int doctorId});
}

class DoctorsRepositoryImpl implements DoctorsRepository {
  final ApiService _apiService;

  DoctorsRepositoryImpl(this._apiService);

  @override
  Future<List<Map<String, dynamic>>> fetchDoctors({String? specialization}) async {
    try {
      final queryParams = <String, dynamic>{};
      if (specialization != null && specialization != 'All') {
        queryParams['specialization'] = specialization;
      }

      final response = await _apiService.get(
        '/api/doctors/',
        queryParameters: queryParams,
      );

      final list = response.data as List<dynamic>;
      return list.map((item) => item as Map<String, dynamic>).toList();
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load doctors list.');
    }
  }

  @override
  Future<Map<String, dynamic>> fetchDoctorDetails({required int doctorId}) async {
    try {
      final response = await _apiService.get('/api/doctors/$doctorId/');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load doctor profile details.');
    }
  }
}
