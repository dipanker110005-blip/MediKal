import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'emergency_repository.dart';

// Async status for emergency alerts dispatches
abstract class DispatchState {
  const DispatchState();
}

class DispatchIdle extends DispatchState {
  const DispatchIdle();
}

class DispatchLoading extends DispatchState {
  const DispatchLoading();
}

class DispatchSuccess extends DispatchState {
  const DispatchSuccess();
}

class DispatchError extends DispatchState {
  final String message;
  const DispatchError(this.message);
}

class DispatchNotifier extends StateNotifier<DispatchState> {
  final EmergencyRepository _repository;

  DispatchNotifier(this._repository) : super(const DispatchIdle());

  Future<bool> sendRequest(double lat, double lng) async {
    state = const DispatchLoading();
    try {
      await _repository.sendEmergencyRequest(lat, lng);
      state = const DispatchSuccess();
      return true;
    } catch (e) {
      state = DispatchError(e.toString().replaceAll('Exception: ', ''));
      return false;
    }
  }

  void reset() {
    state = const DispatchIdle();
  }
}

// Provider to fetch user GPS coordinates, handling permissions reactively
final userLocationProvider = FutureProvider<Position>((ref) async {
  bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    throw Exception('Location services are disabled on this device.');
  }

  LocationPermission permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      throw Exception('Location permissions are denied.');
    }
  }
  
  if (permission == LocationPermission.deniedForever) {
    throw Exception('Location permissions are permanently denied.');
  }

  return await Geolocator.getCurrentPosition(
    desiredAccuracy: LocationAccuracy.high
  );
});

// Provider to fetch nearby facilities (re-runs if location changes)
final nearbyFacilitiesProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  final repository = ref.read(emergencyRepositoryProvider);
  final locationAsync = ref.watch(userLocationProvider);
  
  return locationAsync.when(
    data: (position) => repository.fetchNearbyFacilities(position.latitude, position.longitude),
    loading: () => <String, dynamic>{},
    error: (err, stack) => throw err,
  );
});

// Expose the dispatch notifier state
final emergencyDispatchStateProvider = StateNotifierProvider<DispatchNotifier, DispatchState>((ref) {
  final repository = ref.read(emergencyRepositoryProvider);
  return DispatchNotifier(repository);
});
