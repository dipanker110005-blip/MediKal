import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final emergencyRepositoryProvider = Provider<EmergencyRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return EmergencyRepositoryImpl(apiService);
});

abstract class EmergencyRepository {
  Future<Map<String, dynamic>> fetchNearbyFacilities(double latitude, double longitude);
  Future<Map<String, dynamic>> sendEmergencyRequest(double latitude, double longitude);
}

class EmergencyRepositoryImpl implements EmergencyRepository {
  final ApiService _apiService;

  EmergencyRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> fetchNearbyFacilities(double latitude, double longitude) async {
    try {
      final response = await _apiService.get(
        '/api/emergency/nearby/',
        queryParameters: {
          'latitude': latitude,
          'longitude': longitude,
        },
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load nearby facilities.');
    }
  }

  @override
  Future<Map<String, dynamic>> sendEmergencyRequest(double latitude, double longitude) async {
    try {
      final response = await _apiService.post(
        '/api/emergency/',
        data: {
          'latitude': latitude,
          'longitude': longitude,
        },
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to register emergency request.');
    }
  }
}
