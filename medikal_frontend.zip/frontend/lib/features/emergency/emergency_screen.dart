import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'emergency_provider.dart';

class EmergencyScreen extends ConsumerStatefulWidget {
  const EmergencyScreen({super.key});

  @override
  ConsumerState<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends ConsumerState<EmergencyScreen> {
  final MapController _mapController = MapController();
  Map<String, dynamic>? _selectedFacility;

  void _handleCallAmbulance() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: AppTheme.borderXL),
        title: Row(
          children: [
            const Icon(Icons.phone_in_talk_rounded, color: AppColors.emergency, size: 24),
            const SizedBox(width: 12),
            Text('Calling Dispatcher', style: AppTheme.h3.copyWith(color: AppColors.emergency)),
          ],
        ),
        content: Text(
          'Connecting you to the nearest MediKal Emergency Ambulance dispatcher line (+1 911-0111)...',
          style: AppTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.emergency,
              foregroundColor: Colors.white,
            ),
            child: const Text('Dial Now'),
          ),
        ],
      ),
    );
  }

  void _handleRequestHomeVisit(double lat, double lng) async {
    final success = await ref.read(emergencyDispatchStateProvider.notifier).sendRequest(lat, lng);
    if (success && mounted) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: AppTheme.borderXL),
          title: Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 24),
              const SizedBox(width: 12),
              Text('Dispatch Confirmed', style: AppTheme.h3.copyWith(color: AppColors.success)),
            ],
          ),
          content: Text(
            'Ambulance has been dispatched to your exact GPS coordinates! An EMT will contact you shortly.',
            style: AppTheme.bodyMedium,
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                ref.read(emergencyDispatchStateProvider.notifier).reset();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.success,
                foregroundColor: Colors.white,
              ),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final locationAsync = ref.watch(userLocationProvider);
    final facilitiesAsync = ref.watch(nearbyFacilitiesProvider);
    final dispatchState = ref.watch(emergencyDispatchStateProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: locationAsync.when(
        data: (position) {
          final userLatLng = LatLng(position.latitude, position.longitude);

          return Stack(
            children: [
              // Map Layer
              FlutterMap(
                mapController: _mapController,
                options: MapOptions(
                  initialCenter: userLatLng,
                  initialZoom: 14.5,
                  maxZoom: 18.0,
                  minZoom: 10.0,
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.example.medikal',
                  ),
                  
                  // Render Markers Layer
                  facilitiesAsync.maybeWhen(
                    data: (facilities) {
                      final markers = <Marker>[];
                      
                      // 1. User Position Marker
                      markers.add(
                        Marker(
                          point: userLatLng,
                          width: 50,
                          height: 50,
                          child: const Icon(
                            Icons.my_location_rounded,
                            color: Colors.blue,
                            size: 38,
                          ),
                        ),
                      );

                      // 2. Hospitals
                      if (facilities.containsKey('hospitals')) {
                        for (var item in facilities['hospitals']) {
                          markers.add(
                            Marker(
                              point: LatLng(item['latitude'], item['longitude']),
                              width: 45,
                              height: 45,
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedFacility = item),
                                child: const Icon(Icons.local_hospital_rounded, color: AppColors.emergency, size: 36),
                              ),
                            ),
                          );
                        }
                      }

                      // 3. Clinics
                      if (facilities.containsKey('clinics')) {
                        for (var item in facilities['clinics']) {
                          markers.add(
                            Marker(
                              point: LatLng(item['latitude'], item['longitude']),
                              width: 45,
                              height: 45,
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedFacility = item),
                                child: const Icon(Icons.medical_services_rounded, color: Colors.blue, size: 32),
                              ),
                            ),
                          );
                        }
                      }

                      // 4. Online Doctors
                      if (facilities.containsKey('doctors')) {
                        for (var item in facilities['doctors']) {
                          markers.add(
                            Marker(
                              point: LatLng(item['latitude'], item['longitude']),
                              width: 45,
                              height: 45,
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedFacility = item),
                                child: const Icon(Icons.person_pin_circle_rounded, color: AppColors.secondary, size: 36),
                              ),
                            ),
                          );
                        }
                      }

                      return MarkerLayer(markers: markers);
                    },
                    orElse: () => MarkerLayer(
                      markers: [
                        Marker(
                          point: userLatLng,
                          width: 50,
                          height: 50,
                          child: const Icon(Icons.my_location_rounded, color: Colors.blue, size: 38),
                        )
                      ],
                    ),
                  ),
                ],
              ),

              // Tooltip Details Sheet (Floating premium card)
              if (_selectedFacility != null)
                Positioned(
                  bottom: 140,
                  left: 20,
                  right: 20,
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 500),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: AppTheme.borderL,
                          border: Border.all(color: AppColors.border),
                          boxShadow: AppTheme.shadowCard,
                        ),
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: (_selectedFacility!['type'] == 'HOSPITAL'
                                        ? AppColors.emergency
                                        : _selectedFacility!['type'] == 'CLINIC'
                                            ? Colors.blue
                                            : AppColors.secondary)
                                    .withOpacity(0.08),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                _selectedFacility!['type'] == 'HOSPITAL'
                                    ? Icons.local_hospital_rounded
                                    : _selectedFacility!['type'] == 'CLINIC'
                                        ? Icons.medical_services_rounded
                                        : Icons.person_pin_circle_rounded,
                                color: _selectedFacility!['type'] == 'HOSPITAL'
                                    ? AppColors.emergency
                                    : _selectedFacility!['type'] == 'CLINIC'
                                        ? Colors.blue
                                        : AppColors.secondary,
                                size: 24,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    _selectedFacility!['name'],
                                    style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    _selectedFacility!['type'] == 'DOCTOR'
                                        ? _selectedFacility!['specialization']
                                        : 'Emergency Care Facility',
                                    style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close_rounded, size: 20, color: AppColors.textSecondary),
                              onPressed: () => setState(() => _selectedFacility = null),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

              // Sticky Bottom Action Panel
              Positioned(
                bottom: 24,
                left: 20,
                right: 20,
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 600),
                    child: Row(
                      children: [
                        // Call Ambulance
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _handleCallAmbulance,
                            icon: const Icon(Icons.phone_in_talk_rounded, color: Colors.white, size: 20),
                            label: const Text('Call Ambulance'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.emergency,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16.0),
                              shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
                              elevation: 0,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        // Request Dispatch
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: dispatchState is DispatchLoading
                                ? null
                                : () => _handleRequestHomeVisit(position.latitude, position.longitude),
                            icon: dispatchState is DispatchLoading
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                  )
                                : const Icon(Icons.location_searching_rounded, color: Colors.white, size: 20),
                            label: const Text('Request Dispatch'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16.0),
                              shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
                              elevation: 0,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
        loading: () => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(color: AppColors.primary),
              const SizedBox(height: 20),
              Text(
                'Acquiring secure GPS satellite coordinates...',
                style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
        error: (err, stack) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.emergency.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.gps_off_rounded, size: 54, color: AppColors.emergency),
                ),
                const SizedBox(height: 20),
                Text(
                  'GPS Location Error',
                  style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  err.toString().replaceAll('Exception: ', ''),
                  textAlign: TextAlign.center,
                  style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () => ref.invalidate(userLocationProvider),
                  child: const Text('Grant Access & Retry'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
