import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class OfflineEmergencyCardScreen extends StatelessWidget {
  const OfflineEmergencyCardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Premium Dark Slate
      appBar: AppBar(
        title: Text(
          'Offline Emergency Card',
          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Offline Availability Indicator Banner
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.wifi_off_rounded, color: Color(0xFF10B981), size: 18),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'OFFLINE ACCESS ACTIVE • SAVED LOCALLY',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFFA7F3D0),
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms),

                  const SizedBox(height: 24),

                  // Emergency Card Container
                  Container(
                    padding: const EdgeInsets.all(24.0),
                    decoration: BoxDecoration(
                      color: AppColors.emergency, // Red primary medical card
                      borderRadius: AppTheme.borderXL,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.emergency.withOpacity(0.3),
                          blurRadius: 24,
                          offset: const Offset(0, 12),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'IN CASE OF EMERGENCY (ICE)',
                                  style: GoogleFonts.inter(
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white70,
                                    letterSpacing: 1.0,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'John Doe',
                                  style: GoogleFonts.outfit(
                                    fontSize: 26,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), shape: BoxShape.circle),
                              child: const Icon(Icons.contact_emergency_rounded, color: Colors.white, size: 28),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        const Divider(color: Colors.white30),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(child: _buildEmergencyStat('BLOOD GROUP', 'O+ (Positive)')),
                            Expanded(child: _buildEmergencyStat('DATE OF BIRTH', '14 Oct 1992')),
                          ],
                        ),
                        const SizedBox(height: 20),
                        _buildEmergencyStat('SEVERE ALLERGIES', 'Penicillin, Peanuts (Anaphylaxis Risk)'),
                        const SizedBox(height: 20),
                        _buildEmergencyStat('CHRONIC CONDITIONS', 'Hypertension, Type-2 Diabetes'),
                        const SizedBox(height: 20),
                        _buildEmergencyStat('ACTIVE MEDICATIONS', 'Metformin (500mg), Lisinopril (10mg)'),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms, delay: 100.ms).slideY(begin: 0.05),

                  const SizedBox(height: 28),

                  // QR Scan Section
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E293B), // Slate Card
                      borderRadius: AppTheme.borderXL,
                      border: Border.all(color: const Color(0xFF334155)),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'First Responder Scanning QR',
                          style: GoogleFonts.outfit(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Scan this QR code to download secure medical logs locally without internet.',
                          textAlign: TextAlign.center,
                          style: AppTheme.bodySmall.copyWith(color: const Color(0xFF94A3B8), height: 1.4),
                        ),
                        const SizedBox(height: 24),

                        // Simulated QR Code
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Icon(
                            Icons.qr_code_2_rounded,
                            size: 160,
                            color: const Color(0xFF0F172A),
                          ),
                        ),

                        const SizedBox(height: 24),
                        const Divider(color: Colors.white10),
                        const SizedBox(height: 16),

                        // Emergency Contacts
                        Row(
                          children: [
                            const Icon(Icons.phone_in_talk_rounded, color: AppColors.emergency, size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'ICE Primary Contact: Jane Doe (Spouse)',
                                    style: AppTheme.bodyMedium.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    '+1 (555) 123-4567',
                                    style: AppTheme.bodySmall.copyWith(color: const Color(0xFF94A3B8)),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms, delay: 200.ms).slideY(begin: 0.05),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmergencyStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 9,
            fontWeight: FontWeight.bold,
            color: Colors.white70,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: AppTheme.bodyMedium.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}
