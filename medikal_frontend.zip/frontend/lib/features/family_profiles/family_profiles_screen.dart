import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class FamilyMember {
  final String id;
  final String fullName;
  final String relation; // 'Self', 'Spouse', 'Child', 'Parent'
  final String age;
  final String bloodGroup;
  final String activeMedsCount;
  final String appointmentsCount;
  final String avatarInitials;

  const FamilyMember({
    required this.id,
    required this.fullName,
    required this.relation,
    required this.age,
    required this.bloodGroup,
    required this.activeMedsCount,
    required this.appointmentsCount,
    required this.avatarInitials,
  });
}

class FamilyProfilesScreen extends StatefulWidget {
  const FamilyProfilesScreen({super.key});

  @override
  State<FamilyProfilesScreen> createState() => _FamilyProfilesScreenState();
}

class _FamilyProfilesScreenState extends State<FamilyProfilesScreen> {
  String _activeMemberId = 'MEM001';

  final List<FamilyMember> _family = [
    const FamilyMember(
      id: 'MEM001',
      fullName: 'John Doe',
      relation: 'Self',
      age: '34 yrs',
      bloodGroup: 'O+ (Positive)',
      activeMedsCount: '2 meds',
      appointmentsCount: '1 booking',
      avatarInitials: 'JD',
    ),
    const FamilyMember(
      id: 'MEM002',
      fullName: 'Emma Doe',
      relation: 'Spouse',
      age: '32 yrs',
      bloodGroup: 'A+ (Positive)',
      activeMedsCount: '0 meds',
      appointmentsCount: '0 bookings',
      avatarInitials: 'ED',
    ),
    const FamilyMember(
      id: 'MEM003',
      fullName: 'Leo Doe',
      relation: 'Child',
      age: '6 yrs',
      bloodGroup: 'O+ (Positive)',
      activeMedsCount: '1 med',
      appointmentsCount: '1 booking',
      avatarInitials: 'LD',
    ),
    const FamilyMember(
      id: 'MEM004',
      fullName: 'Robert Doe',
      relation: 'Parent',
      age: '68 yrs',
      bloodGroup: 'B- (Negative)',
      activeMedsCount: '4 meds',
      appointmentsCount: '2 bookings',
      avatarInitials: 'RD',
    ),
  ];

  void _addMemberDialog() {
    final nameController = TextEditingController();
    final ageController = TextEditingController();
    final bloodController = TextEditingController(text: 'O+');
    String selectedRelation = 'Spouse';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('Add Family Profile', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Full Name', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: nameController,
                style: AppTheme.bodyMedium,
                decoration: InputDecoration(
                  hintText: 'e.g. Mary Doe',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
              const SizedBox(height: 16),
              Text('Relationship', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: selectedRelation,
                items: ['Spouse', 'Child', 'Parent']
                    .map((r) => DropdownMenuItem(value: r, child: Text(r, style: AppTheme.bodyMedium)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) {
                    setDialogState(() {
                      selectedRelation = val;
                    });
                  }
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Age / Year', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: ageController,
                          style: AppTheme.bodyMedium,
                          decoration: InputDecoration(
                            hintText: 'e.g. 12 yrs',
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Blood Group', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: bloodController,
                          style: AppTheme.bodyMedium,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty) {
                  final initials = nameController.text.split(' ').map((e) => e.isNotEmpty ? e[0] : '').join().toUpperCase();
                  setState(() {
                    _family.add(
                      FamilyMember(
                        id: 'MEM${DateTime.now().millisecond}',
                        fullName: nameController.text,
                        relation: selectedRelation,
                        age: ageController.text.isNotEmpty ? ageController.text : 'Unknown',
                        bloodGroup: bloodController.text,
                        activeMedsCount: '0 meds',
                        appointmentsCount: '0 bookings',
                        avatarInitials: initials.isNotEmpty ? initials : 'F',
                      ),
                    );
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Added family profile for ${nameController.text}'),
                      backgroundColor: AppColors.success,
                    ),
                  );
                }
              },
              child: const Text('Add Profile'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final activeMember = _family.firstWhere((m) => m.id == _activeMemberId, orElse: () => _family.first);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Family Profiles', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_alt_1_rounded, color: AppColors.primary),
            onPressed: _addMemberDialog,
            tooltip: 'Add Profile',
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Top Profiles Horizontal Deck
                Padding(
                  padding: const EdgeInsets.fromLTRB(24.0, 16.0, 24.0, 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Select Active Member Profile',
                        style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 90,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _family.length,
                          itemBuilder: (context, index) {
                            final member = _family[index];
                            final isActive = member.id == _activeMemberId;
                            return Padding(
                              padding: const EdgeInsets.only(right: 16.0),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _activeMemberId = member.id;
                                  });
                                },
                                borderRadius: BorderRadius.circular(16),
                                child: Column(
                                  children: [
                                    Container(
                                      width: 52,
                                      height: 52,
                                      decoration: BoxDecoration(
                                        color: isActive ? AppColors.primary : AppColors.card,
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: isActive ? AppColors.primary : AppColors.border,
                                          width: isActive ? 2 : 1.5,
                                        ),
                                        boxShadow: isActive ? [
                                          BoxShadow(
                                            color: AppColors.primary.withOpacity(0.25),
                                            blurRadius: 8,
                                            offset: const Offset(0, 4),
                                          )
                                        ] : null,
                                      ),
                                      child: Center(
                                        child: Text(
                                          member.avatarInitials,
                                          style: GoogleFonts.outfit(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: isActive ? Colors.white : AppColors.primary,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      member.fullName.split(' ')[0],
                                      style: AppTheme.bodySmall.copyWith(
                                        fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                                        color: isActive ? AppColors.primary : AppColors.textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const Divider(color: AppColors.border),

                // Member Dashboard Details
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Medical Card Summary
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: AppTheme.borderXL,
                            border: Border.all(color: AppColors.border),
                            boxShadow: AppTheme.shadowCard,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    activeMember.fullName,
                                    style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryLight,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      activeMember.relation.toUpperCase(),
                                      style: GoogleFonts.inter(fontSize: 9, fontWeight: FontWeight.bold, color: AppColors.primary),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  _buildProfileStat('Age', activeMember.age),
                                  const SizedBox(width: 24),
                                  _buildProfileStat('Blood Group', activeMember.bloodGroup),
                                ],
                              ),
                              const SizedBox(height: 16),
                              const Divider(color: AppColors.border),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(Icons.medication_rounded, color: AppColors.primary, size: 18),
                                      const SizedBox(width: 8),
                                      Text(activeMember.activeMedsCount, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      const Icon(Icons.calendar_month_rounded, color: AppColors.secondary, size: 18),
                                      const SizedBox(width: 8),
                                      Text(activeMember.appointmentsCount, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ).animate().fadeIn(duration: 400.ms),

                        const SizedBox(height: 24),

                        // Action Tiles (Profile-specific entries)
                        Text('Profile Shortcuts', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),

                        _buildShortcutTile(
                          icon: Icons.assignment_outlined,
                          color: Colors.blue.shade700,
                          title: 'Medical History',
                          subtitle: 'View past diagnoses, vaccinations, and surgeries for ${activeMember.fullName.split(' ')[0]}',
                        ),
                        _buildShortcutTile(
                          icon: Icons.science_outlined,
                          color: Colors.teal.shade700,
                          title: 'Lab & Diagnostic Reports',
                          subtitle: 'Exams, lipid profiles, and diagnostic blood panels',
                        ),
                        _buildShortcutTile(
                          icon: Icons.shield_outlined,
                          color: Colors.orange.shade700,
                          title: 'Chronic Care Plans',
                          subtitle: 'Assigned physician targets and lifestyle programs',
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileStat(String label, String val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted)),
        const SizedBox(height: 2),
        Text(val, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
      ],
    );
  }

  Widget _buildShortcutTile({required IconData icon, required Color color, required String title, required String subtitle}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.08), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(title, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
        subtitle: Text(subtitle, style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, height: 1.3)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Opening $title details...')),
          );
        },
      ),
    );
  }
}
