import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'lab_report_explanation_screen.dart';

class HealthRecord {
  final String id;
  final String title;
  final String category; // 'Prescription', 'Lab Report', 'Scan', 'Discharge Summary', 'Visit Note'
  final DateTime date;
  final String doctorName;
  final String hospitalName;
  final String summary;
  final String fileSize;
  final bool isFlagged; // Indicates abnormal lab values to prompt explanation

  const HealthRecord({
    required this.id,
    required this.title,
    required this.category,
    required this.date,
    required this.doctorName,
    required this.hospitalName,
    required this.summary,
    required this.fileSize,
    this.isFlagged = false,
  });
}

class HealthRecordsScreen extends StatefulWidget {
  const HealthRecordsScreen({super.key});

  @override
  State<HealthRecordsScreen> createState() => _HealthRecordsScreenState();
}

class _HealthRecordsScreenState extends State<HealthRecordsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedCategory = 'All';

  final List<String> _categories = const [
    'All',
    'Prescription',
    'Lab Report',
    'Scan',
    'Discharge Summary',
    'Visit Note'
  ];

  final List<HealthRecord> _records = [
    HealthRecord(
      id: 'REC001',
      title: 'Complete Blood Count (CBC) Panel',
      category: 'Lab Report',
      date: DateTime.now().subtract(const Duration(days: 4)),
      doctorName: 'Dr. Michael Chen',
      hospitalName: 'MediKal Central Lab',
      summary: 'Standard hematology screening. Showed slightly elevated white blood cell (WBC) count.',
      fileSize: '1.4 MB',
      isFlagged: true,
    ),
    HealthRecord(
      id: 'REC002',
      title: 'Post-Op Coronary Angiogram Scan',
      category: 'Scan',
      date: DateTime.now().subtract(const Duration(days: 12)),
      doctorName: 'Dr. Sarah Jenkins',
      hospitalName: 'Cardiovascular Specialty Center',
      summary: 'High-resolution CT scan of coronary arteries showing patent stent implementation.',
      fileSize: '8.2 MB',
    ),
    HealthRecord(
      id: 'REC003',
      title: 'Lipid Profile & Glucose Panel',
      category: 'Lab Report',
      date: DateTime.now().subtract(const Duration(days: 30)),
      doctorName: 'Dr. Michael Chen',
      hospitalName: 'MediKal Central Lab',
      summary: 'Routine metabolic and cardiovascular panel. LDL cholesterol levels flagged as elevated.',
      fileSize: '950 KB',
      isFlagged: true,
    ),
    HealthRecord(
      id: 'REC004',
      title: 'Discharge Summary - Acute Bronchitis',
      category: 'Discharge Summary',
      date: DateTime.now().subtract(const Duration(days: 45)),
      doctorName: 'Dr. Emily Taylor',
      hospitalName: 'Metro Health Hospital',
      summary: 'Admitted for acute asthmatic exacerbation and bronchitis. Resolved with Albuterol and IV fluids.',
      fileSize: '2.1 MB',
    ),
    HealthRecord(
      id: 'REC005',
      title: 'Chronic Hypertension Follow-up Note',
      category: 'Visit Note',
      date: DateTime.now().subtract(const Duration(days: 60)),
      doctorName: 'Dr. Sarah Jenkins',
      hospitalName: 'Cardiology Clinic',
      summary: 'Patient reported good adherence to Lisinopril. Target blood pressure maintained at 122/78 mmHg.',
      fileSize: '320 KB',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _addNewMockRecord() {
    setState(() {
      _records.insert(
        0,
        HealthRecord(
          id: 'REC${DateTime.now().millisecond}',
          title: 'Uploaded Prescription Sheet',
          category: 'Prescription',
          date: DateTime.now(),
          doctorName: 'Self Uploaded',
          hospitalName: 'MediKal Vault',
          summary: 'Scanned prescription slip for chronic care refills.',
          fileSize: '450 KB',
        ),
      );
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Record saved securely in your Health Vault.'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredRecords = _records.where((rec) {
      final matchesSearch = rec.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          rec.doctorName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          rec.summary.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'All' || rec.category == _selectedCategory;
      return matchesSearch && matchesCategory;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Health Records Vault', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_photo_alternate_rounded, color: AppColors.primary),
            onPressed: _addNewMockRecord,
            tooltip: 'Upload Document',
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              children: [
                // Top Search & Category Filter
                Padding(
                  padding: const EdgeInsets.fromLTRB(24.0, 16.0, 24.0, 8.0),
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: AppTheme.borderM,
                          border: Border.all(color: AppColors.border),
                          boxShadow: AppTheme.shadowSubtle,
                        ),
                        child: TextField(
                          controller: _searchController,
                          onChanged: (val) => setState(() => _searchQuery = val),
                          style: AppTheme.bodyMedium,
                          decoration: InputDecoration(
                            hintText: 'Search records, diagnoses, clinicians...',
                            prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textMuted),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                            hintStyle: AppTheme.bodyMedium.copyWith(color: AppColors.textMuted),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 38,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _categories.length,
                          itemBuilder: (context, idx) {
                            final cat = _categories[idx];
                            final isSelected = _selectedCategory == cat;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text(cat),
                                selected: isSelected,
                                selectedColor: AppColors.primary,
                                backgroundColor: AppColors.card,
                                labelStyle: AppTheme.bodySmall.copyWith(
                                  color: isSelected ? Colors.white : AppColors.textPrimary,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                                ),
                                onSelected: (val) {
                                  setState(() => _selectedCategory = cat);
                                },
                                showCheckmark: false,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                                side: BorderSide(color: isSelected ? AppColors.primary : AppColors.border),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                // Records List
                Expanded(
                  child: filteredRecords.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                          itemCount: filteredRecords.length,
                          itemBuilder: (context, index) {
                            final record = filteredRecords[index];
                            return _buildRecordCard(record)
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                                .slideY(begin: 0.03);
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
              child: const Icon(Icons.folder_off_rounded, size: 48, color: AppColors.primary),
            ),
            const SizedBox(height: 20),
            Text('No Records Found', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              'No items match your filter criteria. Click the upload button to save medical documents to your secure portal.',
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecordCard(HealthRecord record) {
    IconData categoryIcon = Icons.insert_drive_file_outlined;
    Color categoryColor = AppColors.primary;
    Color lightBgColor = AppColors.primaryLight;

    switch (record.category) {
      case 'Prescription':
        categoryIcon = Icons.medication_outlined;
        categoryColor = Colors.orange.shade700;
        lightBgColor = Colors.orange.shade50;
        break;
      case 'Lab Report':
        categoryIcon = Icons.biotech_outlined;
        categoryColor = Colors.teal.shade700;
        lightBgColor = Colors.teal.shade50;
        break;
      case 'Scan':
        categoryIcon = Icons.settings_accessibility_rounded;
        categoryColor = Colors.purple.shade700;
        lightBgColor = Colors.purple.shade50;
        break;
      case 'Discharge Summary':
        categoryIcon = Icons.assignment_outlined;
        categoryColor = Colors.blue.shade700;
        lightBgColor = Colors.blue.shade50;
        break;
      case 'Visit Note':
        categoryIcon = Icons.description_outlined;
        categoryColor = const Color(0xFF334155);
        lightBgColor = const Color(0xFFF1F5F9);
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: InkWell(
        onTap: () => _showRecordDetails(record),
        borderRadius: AppTheme.borderL,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: lightBgColor, shape: BoxShape.circle),
                    child: Icon(categoryIcon, color: categoryColor, size: 22),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          record.title,
                          style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              record.category,
                              style: AppTheme.bodySmall.copyWith(color: categoryColor, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '•  ${record.date.day}/${record.date.month}/${record.date.year}',
                              style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (record.isFlagged)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.emergencyLight,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 12),
                          const SizedBox(width: 4),
                          Text(
                            'ABNORMAL',
                            style: GoogleFonts.inter(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: AppColors.emergency,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                record.summary,
                style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.35),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Size: ${record.fileSize}  •  ${record.hospitalName}',
                    style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted),
                  ),
                  Row(
                    children: [
                      if (record.category == 'Lab Report')
                        TextButton.icon(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => LabReportExplanationScreen(record: record),
                              ),
                            );
                          },
                          icon: const Icon(Icons.auto_awesome_rounded, size: 14, color: AppColors.primary),
                          label: Text('Explain Report', style: AppTheme.bodySmall.copyWith(color: AppColors.primary, fontWeight: FontWeight.bold)),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                      const SizedBox(width: 8),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRecordDetails(HealthRecord record) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.65,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          padding: const EdgeInsets.all(24.0),
          child: ListView(
            controller: scrollController,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                    child: const Icon(Icons.folder_shared_outlined, color: AppColors.primary, size: 30),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(record.title, style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(
                          '${record.category} • Signed by ${record.doctorName}',
                          style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Divider(color: AppColors.border),
              const SizedBox(height: 16),
              _buildDetailItem('Facility / Organization', record.hospitalName),
              _buildDetailItem('Date Documented', '${record.date.day} / ${record.date.month} / ${record.date.year}'),
              _buildDetailItem('Secure File ID', record.id),
              _buildDetailItem('File Size', record.fileSize),
              const SizedBox(height: 16),
              Text('Clinical Brief / Summary', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.background,
                  borderRadius: AppTheme.borderM,
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  record.summary,
                  style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary),
                ),
              ),
              const SizedBox(height: 28),

              // Sharing Options Row
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Secure access token generated. Ready to share with family.')),
                        );
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.share_outlined, size: 18),
                      label: const Text('Share with Family'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Encrypted link sent directly to your provider list.')),
                        );
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.verified_user_outlined, size: 18),
                      label: const Text('Share with Doctor'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
          Text(value, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}
