import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'health_records_screen.dart';

class BioMarker {
  final String name;
  final String value;
  final String referenceRange;
  final String unit;
  final String status; // 'Normal', 'High', 'Low'
  final String description;

  const BioMarker({
    required this.name,
    required this.value,
    required this.referenceRange,
    required this.unit,
    required this.status,
    required this.description,
  });
}

class LabReportExplanationScreen extends StatelessWidget {
  final HealthRecord record;

  const LabReportExplanationScreen({super.key, required this.record});

  // Curated Medical Reference Biomarkers
  List<BioMarker> _getBiomarkers() {
    if (record.title.contains('CBC') || record.title.contains('Blood')) {
      return const [
        BioMarker(
          name: 'White Blood Cell (WBC) Count',
          value: '11.8',
          referenceRange: '4.5 - 11.0',
          unit: 'x10^3/uL',
          status: 'High',
          description: 'A higher than normal WBC count usually indicates that the body is fighting off an infection or experiencing mild inflammation.',
        ),
        BioMarker(
          name: 'Red Blood Cell (RBC) Count',
          value: '4.8',
          referenceRange: '4.3 - 5.9',
          unit: 'x10^6/uL',
          status: 'Normal',
          description: 'Your red blood cell counts are well within the optimal range, indicating normal oxygen-carrying capacity.',
        ),
        BioMarker(
          name: 'Hemoglobin (Hgb)',
          value: '14.2',
          referenceRange: '13.5 - 17.5',
          unit: 'g/dL',
          status: 'Normal',
          description: 'Hemoglobin levels are stable, supporting healthy tissue oxygenation throughout the body.',
        ),
        BioMarker(
          name: 'Platelet Count',
          value: '280',
          referenceRange: '150 - 450',
          unit: 'x10^3/uL',
          status: 'Normal',
          description: 'Platelet levels are normal, indicating standard clotting functions are active and balanced.',
        ),
      ];
    } else {
      // Lipid Profile markers
      return const [
        BioMarker(
          name: 'Total Cholesterol',
          value: '228',
          referenceRange: '< 200',
          unit: 'mg/dL',
          status: 'High',
          description: 'Elevated total cholesterol levels may indicate a risk factor for cardiovascular disease. Restructuring of dietary saturated fats is generally advised.',
        ),
        BioMarker(
          name: 'LDL Cholesterol (Low-Density)',
          value: '142',
          referenceRange: '< 100',
          unit: 'mg/dL',
          status: 'High',
          description: 'Commonly known as "bad" cholesterol. Elevated levels are often addressed via cardiovascular care programs and exercise regimens.',
        ),
        BioMarker(
          name: 'HDL Cholesterol (High-Density)',
          value: '48',
          referenceRange: '> 40',
          unit: 'mg/dL',
          status: 'Normal',
          description: 'Your protective "good" cholesterol is stable, aiding in clearance of arterial cholesterol deposits.',
        ),
        BioMarker(
          name: 'Triglycerides',
          value: '130',
          referenceRange: '< 150',
          unit: 'mg/dL',
          status: 'Normal',
          description: 'Fast triglycerides levels are healthy and indicate normal metabolic processing of dietary fats.',
        ),
      ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final biomarkers = _getBiomarkers();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Lab Report Explanation', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Title Intro Banner
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F172A), Color(0xFF0D9488)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: AppTheme.borderXL,
                      boxShadow: AppTheme.shadowCard,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle),
                              child: const Icon(Icons.auto_awesome_rounded, color: Colors.amber, size: 18),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'MEDIKAL CLINICAL AI EXPLANATION',
                              style: GoogleFonts.inter(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: Colors.white.withOpacity(0.9),
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          record.title,
                          style: AppTheme.h3.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Facility: ${record.hospitalName}  •  Date: ${record.date.day}/${record.date.month}/${record.date.year}',
                          style: AppTheme.bodySmall.copyWith(color: Colors.white.withOpacity(0.75)),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms),

                  const SizedBox(height: 24),

                  Text(
                    'Key Biomarkers & Values',
                    style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),

                  // Biomarkers Cards
                  ...biomarkers.map((marker) => _buildBiomarkerCard(marker)).toList(),

                  const SizedBox(height: 24),

                  // Trend Section
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: AppTheme.borderL,
                      border: Border.all(color: AppColors.border),
                      boxShadow: AppTheme.shadowSubtle,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.show_chart_rounded, color: AppColors.primary, size: 20),
                            const SizedBox(width: 10),
                            Text(
                              'Timeline Trend Analysis',
                              style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          record.title.contains('CBC')
                              ? 'Your White Blood Cell (WBC) counts have shown a slight upward trend over the past 3 months (from 9.2 to 11.8). Red Blood Cells and Platelets have remained highly stable.'
                              : 'Your LDL Cholesterol has decreased by 8% compared to the reading on Jan 12, reflecting positive adherence to lipid management targets.',
                          style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.45),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms, delay: 200.ms),

                  const SizedBox(height: 28),

                  // Clinical Caution Box
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: AppColors.emergencyLight.withOpacity(0.4),
                      borderRadius: AppTheme.borderM,
                      border: Border.all(color: AppColors.emergency.withOpacity(0.25), width: 1.2),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 18),
                            const SizedBox(width: 10),
                            Text(
                              'Clinical Disclaimer & Caution',
                              style: AppTheme.bodyLarge.copyWith(
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.bold,
                                fontSize: 13.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'These explanations are translated from laboratory values for educational reference. A single biomarker reading does not constitute a full diagnosis. Please review these trends with your primary physician to determine if care plan alterations are necessary.',
                          style: AppTheme.bodyMedium.copyWith(
                            color: AppColors.textPrimary,
                            fontSize: 12.5,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms, delay: 300.ms),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBiomarkerCard(BioMarker marker) {
    Color statusColor = AppColors.success;
    Color statusBgColor = const Color(0xFFD1FAE5);

    if (marker.status == 'High') {
      statusColor = AppColors.emergency;
      statusBgColor = AppColors.emergencyLight;
    } else if (marker.status == 'Low') {
      statusColor = AppColors.urgent;
      statusBgColor = AppColors.urgentLight;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    marker.name,
                    style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: statusBgColor, borderRadius: BorderRadius.circular(12)),
                  child: Text(
                    marker.status.toUpperCase(),
                    style: GoogleFonts.inter(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: statusColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Your Value', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted)),
                    const SizedBox(height: 2),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text(
                          marker.value,
                          style: GoogleFonts.outfit(fontSize: 22, fontWeight: FontWeight.bold, color: statusColor),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          marker.unit,
                          style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(width: 48),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Reference Range', style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted)),
                    const SizedBox(height: 4),
                    Text(
                      '${marker.referenceRange} ${marker.unit}',
                      style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(color: AppColors.border, height: 1),
            const SizedBox(height: 10),
            Text(
              marker.description,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}
