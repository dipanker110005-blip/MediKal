import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class Medicine {
  final String name;
  final String genericName;
  final String activeIngredients;
  final String commonUse;
  final List<String> sideEffects;
  final String precautions;
  final String whoShouldAvoid;
  final String interactionWarnings;
  final String clinicianConsultation;

  const Medicine({
    required this.name,
    required this.genericName,
    required this.activeIngredients,
    required this.commonUse,
    required this.sideEffects,
    required this.precautions,
    required this.whoShouldAvoid,
    required this.interactionWarnings,
    required this.clinicianConsultation,
  });
}

class MedicineDetailsScreen extends StatefulWidget {
  const MedicineDetailsScreen({super.key});

  @override
  State<MedicineDetailsScreen> createState() => _MedicineDetailsScreenState();
}

class _MedicineDetailsScreenState extends State<MedicineDetailsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Curated Medical Reference Dataset
  final List<Medicine> _medicines = const [
    Medicine(
      name: 'Paracetamol',
      genericName: 'Acetaminophen',
      activeIngredients: 'Acetaminophen (500mg)',
      commonUse: 'Relieving mild-to-moderate pain (headaches, muscle aches, arthritis) and reducing fever.',
      sideEffects: [
        'Nausea or stomach discomfort',
        'Loss of appetite',
        'Mild itching or skin rash',
        'Dark urine or clay-colored stools (signs of overuse)',
      ],
      precautions: 'Do not exceed 4,000 mg (8 tablets of 500mg) in a 24-hour period. Avoid using with other products containing acetaminophen to prevent accidental overdose. Restrict alcohol consumption while using.',
      whoShouldAvoid: 'Individuals with severe liver disease, chronic alcohol dependency, or known hypersensitivity to acetaminophen.',
      interactionWarnings: 'Increases risk of hepatotoxicity when combined with other liver-taxing substances. May slowly increase the blood-thinning effect of Warfarin (blood thinners) if used daily for extended periods.',
      clinicianConsultation: 'Seek immediate clinical attention if your fever persists for more than 3 days, pain lasts more than 5 days, or if you develop a skin rash, swelling, or difficulty breathing.',
    ),
    Medicine(
      name: 'Ibuprofen',
      genericName: 'Ibuprofen',
      activeIngredients: 'Ibuprofen (200mg or 400mg)',
      commonUse: 'Reducing inflammation, treating acute pain (headache, dental pain, backache), and fever reduction.',
      sideEffects: [
        'Stomach irritation or heartburn',
        'Mild dizziness or ringing in the ears (tinnitus)',
        'Abdominal bloating or gas',
        'Constipation or mild diarrhea',
      ],
      precautions: 'Take with food or a glass of milk to minimize gastrointestinal irritation. Long-term use requires monitoring of kidney health and blood pressure.',
      whoShouldAvoid: 'Patients with active stomach ulcers, gastrointestinal bleeding, severe heart failure, advanced kidney disease, or history of aspirin-sensitive asthma.',
      interactionWarnings: 'Do not combine with other NSAIDs (e.g. Naproxen, Aspirin). Interacts with blood thinners (increases bleeding risk), diuretics, and antihypertensive (blood pressure) medications.',
      clinicianConsultation: 'Consult a physician immediately if you experience severe abdominal pain, black/tarry stools, chest pain, shortness of breath, sudden visual changes, or unexplained swelling.',
    ),
    Medicine(
      name: 'Amoxicillin',
      genericName: 'Amoxicillin Trihydrate',
      activeIngredients: 'Amoxicillin (500mg)',
      commonUse: 'Treating acute bacterial infections, including ear, nose, throat, respiratory tract, and urinary tract infections.',
      sideEffects: [
        'Mild diarrhea or loose stools',
        'Nausea and vomiting',
        'Mild skin rash or itching',
        'Oral thrush or vaginal yeast infection (due to floral disruption)',
      ],
      precautions: 'Complete the entire course prescribed by your clinician, even if symptoms clear early, to prevent antibiotic resistance. This medication does not treat viral infections (e.g. cold or flu).',
      whoShouldAvoid: 'Anyone with a documented history of severe allergic reactions (anaphylaxis) to penicillin or cephalosporin class antibiotics.',
      interactionWarnings: 'May decrease the effectiveness of oral contraceptives (birth control). May interact with Methotrexate or increase the blood-thinning effects of Warfarin.',
      clinicianConsultation: 'Contact a healthcare provider immediately if you develop severe watery or bloody diarrhea (even weeks after completing treatment), difficulty breathing, severe skin peeling, or swelling of the face and throat.',
    ),
    Medicine(
      name: 'Metformin',
      genericName: 'Metformin Hydrochloride',
      activeIngredients: 'Metformin HCl (500mg or 850mg)',
      commonUse: 'Glycemic control management for patients diagnosed with Type 2 Diabetes Mellitus.',
      sideEffects: [
        'Diarrhea, abdominal cramps, or bloating',
        'Nausea, vomiting, or metallic taste in mouth',
        'Vitamin B12 deficiency (during long-term therapy)',
        'Loss of appetite',
      ],
      precautions: 'Monitor renal (kidney) function test parameters regularly. Discontinue use temporarily before any medical imaging procedure that uses iodinated contrast media.',
      whoShouldAvoid: 'Individuals with severe kidney dysfunction (eGFR < 30 mL/min), acute or chronic metabolic acidosis (including diabetic ketoacidosis), or acute heart failure.',
      interactionWarnings: 'Excessive alcohol intake while taking Metformin significantly increases the risk of lactic acidosis. Cimetidine and certain other medications can elevate Metformin blood levels.',
      clinicianConsultation: 'Seek emergency clinical care if you develop symptoms of lactic acidosis: deep/rapid breathing, extreme tiredness, severe muscle pains, slow/irregular heartbeat, or severe drowsiness.',
    ),
    Medicine(
      name: 'Atorvastatin',
      genericName: 'Atorvastatin Calcium',
      activeIngredients: 'Atorvastatin Calcium (10mg or 20mg)',
      commonUse: 'Lowering elevated total cholesterol, LDL-cholesterol, and triglycerides, and reducing cardiovascular risks.',
      sideEffects: [
        'Mild muscle pain (myalgia) or joint aches',
        'Headache',
        'Constipation, diarrhea, or indigestion',
        'Mild, transient elevations in liver enzymes',
      ],
      precautions: 'Avoid consuming large quantities of grapefruit juice (can increase drug concentrations). Limit alcohol consumption to protect liver health.',
      whoShouldAvoid: 'Patients with active liver disease, unexplained persistent elevations of liver transaminases, or pregnant and breastfeeding mothers.',
      interactionWarnings: 'Increased risk of skeletal muscle damage (myopathy/rhabdomyolysis) when combined with certain antibiotics, antifungals (e.g., Ketoconazole), or fibrates.',
      clinicianConsultation: 'Report any unexplained muscle pain, tenderness, or weakness immediately, especially if accompanied by fever, dark-colored urine, or extreme fatigue.',
    ),
    Medicine(
      name: 'Albuterol',
      genericName: 'Albuterol (Salbutamol)',
      activeIngredients: 'Albuterol sulfate (90mcg per puff)',
      commonUse: 'Relief and prevention of acute airway constriction (bronchospasm) in patients with asthma or COPD.',
      sideEffects: [
        'Muscle tremors (especially in hands)',
        'Nervousness or restlessness',
        'Increased heart rate (tachycardia) or palpitations',
        'Throat irritation or mild cough',
      ],
      precautions: 'If your typical dose fails to relieve symptoms, do not exceed the recommended frequency—contact a doctor immediately. Ensure correct inhaler technique.',
      whoShouldAvoid: 'Patients with a history of severe hypersensitivity to albuterol or milk proteins (present in dry powder formulations).',
      interactionWarnings: 'Beta-blockers (e.g., Propranolol) can completely block the therapeutic effects of Albuterol and cause severe airway spasms. Use with caution alongside diuretics.',
      clinicianConsultation: 'Seek immediate emergency clinical care if you experience a sudden, severe worsening of breathing (paradoxical bronchospasm), chest tightness, or blue-tinted lips after use.',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filteredMedicines = _medicines.where((med) {
      final query = _searchQuery.toLowerCase();
      return med.name.toLowerCase().contains(query) ||
          med.genericName.toLowerCase().contains(query) ||
          med.commonUse.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Medicine Guide',
          style: AppTheme.h3,
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Input Area
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: AppTheme.borderM,
                  border: Border.all(color: AppColors.border),
                  boxShadow: AppTheme.shadowSubtle,
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  style: AppTheme.bodyMedium,
                  decoration: InputDecoration(
                    hintText: 'Search brand or generic name...',
                    prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textMuted),
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
                    hintStyle: AppTheme.bodyMedium.copyWith(color: AppColors.textMuted),
                  ),
                ),
              ),
            ),

            // Content List
            Expanded(
              child: filteredMedicines.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
                      itemCount: filteredMedicines.length,
                      itemBuilder: (context, index) {
                        final medicine = filteredMedicines[index];
                        return _buildMedicineCard(medicine)
                            .animate()
                            .fadeIn(duration: 350.ms, delay: (index * 50).ms)
                            .slideY(begin: 0.04, curve: Curves.easeOutQuad);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceM),
              decoration: const BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.search_off_rounded, size: 48, color: AppColors.primary),
            ),
            const SizedBox(height: AppTheme.spaceL),
            Text(
              'No Medicines Found',
              style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              'We couldn\'t find any clinical medications matching "$_searchQuery". Check spelling or contact support.',
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMedicineCard(Medicine medicine) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _navigateToDetails(medicine),
          borderRadius: AppTheme.borderL,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: const Icon(Icons.medication_rounded, color: AppColors.primary, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        medicine.name,
                        style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        medicine.genericName,
                        style: AppTheme.bodySmall.copyWith(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        medicine.commonUse,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, fontSize: 12.5, height: 1.35),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _navigateToDetails(Medicine medicine) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => MedicineDetailPage(medicine: medicine),
      ),
    );
  }
}

class MedicineDetailPage extends StatelessWidget {
  final Medicine medicine;

  const MedicineDetailPage({super.key, required this.medicine});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Clinical Details',
          style: AppTheme.h3,
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero Info Header Card
              Container(
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: AppTheme.borderL,
                  border: Border.all(color: AppColors.border),
                  boxShadow: AppTheme.shadowSubtle,
                ),
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: const BoxDecoration(
                        color: AppColors.primaryLight,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.medication_rounded, color: AppColors.primary, size: 36),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      medicine.name,
                      style: AppTheme.h2.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      medicine.genericName,
                      style: AppTheme.bodyLarge.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.background,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Text(
                        'Active Ingredient: ${medicine.activeIngredients}',
                        style: AppTheme.bodySmall.copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 400.ms),

              const SizedBox(height: 20),

              // Structured Sections
              _buildSectionCard(
                title: 'Primary Indications',
                icon: Icons.check_circle_outline_rounded,
                iconColor: AppColors.primary,
                bgColor: AppColors.primaryLight,
                content: Text(
                  medicine.commonUse,
                  style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 100.ms),

              const SizedBox(height: 16),

              _buildSectionCard(
                title: 'Common Side Effects',
                icon: Icons.bubble_chart_outlined,
                iconColor: AppColors.secondary,
                bgColor: AppColors.secondaryLight,
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: medicine.sideEffects.map((effect) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 6.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(top: 6.0, right: 10.0),
                            child: Icon(Icons.circle, size: 5, color: AppColors.secondary),
                          ),
                          Expanded(
                            child: Text(
                              effect,
                              style: AppTheme.bodyMedium.copyWith(height: 1.4, color: AppColors.textPrimary),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 150.ms),

              const SizedBox(height: 16),

              _buildSectionCard(
                title: 'Precautions & Cautions',
                icon: Icons.shield_outlined,
                iconColor: AppColors.warning,
                bgColor: AppColors.warningLight,
                content: Text(
                  medicine.precautions,
                  style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 200.ms),

              const SizedBox(height: 16),

              _buildSectionCard(
                title: 'Who Should Avoid This',
                icon: Icons.remove_circle_outline_rounded,
                iconColor: AppColors.emergency,
                bgColor: AppColors.emergencyLight,
                content: Text(
                  medicine.whoShouldAvoid,
                  style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 250.ms),

              const SizedBox(height: 16),

              _buildSectionCard(
                title: 'Drug Interaction Warnings',
                icon: Icons.swap_calls_rounded,
                iconColor: AppColors.urgent,
                bgColor: AppColors.urgentLight,
                content: Text(
                  medicine.interactionWarnings,
                  style: AppTheme.bodyMedium.copyWith(height: 1.45, color: AppColors.textPrimary),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 300.ms),

              const SizedBox(height: 24),

              // 🚨 Clinician Consultation Red Flag Warning Box
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: AppColors.emergencyLight.withOpacity(0.4),
                  borderRadius: AppTheme.borderM,
                  border: Border.all(color: AppColors.emergency.withOpacity(0.25), width: 1.2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: AppColors.emergency, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          'When to Seek Clinical Advice',
                          style: AppTheme.h4.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      medicine.clinicianConsultation,
                      style: AppTheme.bodyMedium.copyWith(
                        color: AppColors.textPrimary,
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 450.ms, delay: 350.ms),

              const SizedBox(height: 24),

              // Safe Disclaimer Footer
              Text(
                'Disclaimer: This reference guide is strictly for informational purposes. It is not a substitute for professional clinical diagnosis, advice, or treatment courses. Always verify medication plans with a certified physician or pharmacist before taking action.',
                style: AppTheme.bodySmall.copyWith(
                  color: AppColors.textMuted,
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ).animate().fadeIn(duration: 500.ms, delay: 400.ms),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required Widget content,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  color: bgColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: iconColor, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: AppTheme.h4.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          content,
        ],
      ),
    );
  }
}
