import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'prescription_upload_screen.dart';
import 'order_history_screen.dart';
import 'medicine_details_screen.dart';

class MedicinesHubScreen extends StatelessWidget {
  const MedicinesHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Medicine Delivery',
          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Header Intro Banner (Premium clinical teal gradient)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24.0),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F766E), Color(0xFF115E59)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: AppTheme.borderXL,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.18),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.local_pharmacy_rounded, color: Colors.white, size: 28),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Doorstep Pharmacy',
                          style: AppTheme.h3.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Upload your doctor's prescription. Our certified pharmacist will verify your items, pack securely, and ship them directly to your home.",
                          style: AppTheme.bodyMedium.copyWith(
                            color: Colors.white.withOpacity(0.85),
                            height: 1.45,
                          ),
                        ),
                      ],
                    ),
                  )
                      .animate()
                      .fadeIn(duration: 400.ms)
                      .slideY(begin: -0.05),
                  
                  const SizedBox(height: 36),

                  Text(
                    'Select Action',
                    style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 16),

                  // Action Cards List
                  _buildOptionCard(
                    context,
                    title: 'Upload Prescription',
                    subtitle: 'Order medications securely by uploading prescription photos or documents',
                    icon: Icons.cloud_upload_outlined,
                    color: Colors.orange.shade700,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const PrescriptionUploadScreen()),
                      );
                    },
                  )
                      .animate()
                      .fadeIn(delay: 100.ms, duration: 400.ms)
                      .slideY(begin: 0.05),
                  
                  const SizedBox(height: 16),

                  _buildOptionCard(
                    context,
                    title: 'Track Orders',
                    subtitle: 'Check dispatch status, timelines, and payment receipts for your pending shipments',
                    icon: Icons.local_shipping_outlined,
                    color: AppColors.primary,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
                      );
                    },
                  )
                      .animate()
                      .fadeIn(delay: 200.ms, duration: 400.ms)
                      .slideY(begin: 0.05),

                  const SizedBox(height: 16),

                  _buildOptionCard(
                    context,
                    title: 'Medicine Guide',
                    subtitle: 'Verify active ingredients, precautions, common uses, side effects, and warning states',
                    icon: Icons.menu_book_rounded,
                    color: Colors.indigo.shade600,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const MedicineDetailsScreen()),
                      );
                    },
                  )
                      .animate()
                      .fadeIn(delay: 300.ms, duration: 400.ms)
                      .slideY(begin: 0.05),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOptionCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: AppTheme.borderL,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(14.0),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16.0),
                  ),
                  child: Icon(icon, size: 26, color: color),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: AppTheme.h4.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: AppTheme.bodySmall.copyWith(
                          color: AppColors.textSecondary,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
