import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'medicines_repository.dart';

class MedicinesOrdersState {
  final List<dynamic> orders;
  final bool isLoading;
  final String? error;

  MedicinesOrdersState({
    required this.orders,
    required this.isLoading,
    this.error,
  });

  factory MedicinesOrdersState.initial() => MedicinesOrdersState(
        orders: [],
        isLoading: false,
        error: null,
      );

  MedicinesOrdersState copyWith({
    List<dynamic>? orders,
    bool? isLoading,
    String? error,
  }) {
    return MedicinesOrdersState(
      orders: orders ?? this.orders,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class MedicinesOrdersNotifier extends StateNotifier<MedicinesOrdersState> {
  final MedicinesRepository _repository;

  MedicinesOrdersNotifier(this._repository) : super(MedicinesOrdersState.initial()) {
    fetchOrders();
  }

  Future<void> fetchOrders() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final orders = await _repository.fetchOrders();
      state = state.copyWith(orders: orders, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
}

final medicinesOrdersProvider =
    StateNotifierProvider<MedicinesOrdersNotifier, MedicinesOrdersState>((ref) {
  final repository = ref.read(medicinesRepositoryProvider);
  return MedicinesOrdersNotifier(repository);
});

class PrescriptionUploadState {
  final bool isUploading;
  final bool isSuccess;
  final String? error;
  final Map<String, dynamic>? prescription;
  final Map<String, dynamic>? order;

  PrescriptionUploadState({
    required this.isUploading,
    required this.isSuccess,
    this.error,
    this.prescription,
    this.order,
  });

  factory PrescriptionUploadState.initial() => PrescriptionUploadState(
        isUploading: false,
        isSuccess: false,
        error: null,
        prescription: null,
        order: null,
      );

  PrescriptionUploadState copyWith({
    bool? isUploading,
    bool? isSuccess,
    String? error,
    Map<String, dynamic>? prescription,
    Map<String, dynamic>? order,
  }) {
    return PrescriptionUploadState(
      isUploading: isUploading ?? this.isUploading,
      isSuccess: isSuccess ?? this.isSuccess,
      error: error ?? this.error,
      prescription: prescription ?? this.prescription,
      order: order ?? this.order,
    );
  }
}

class PrescriptionUploadNotifier extends StateNotifier<PrescriptionUploadState> {
  final MedicinesRepository _repository;
  final Ref _ref;

  PrescriptionUploadNotifier(this._repository, this._ref)
      : super(PrescriptionUploadState.initial());

  void reset() {
    state = PrescriptionUploadState.initial();
  }

  Future<void> uploadAndOrder({
    required File file,
    String? notes,
    required String deliveryAddress,
    required String contactNumber,
    int? patientId,
  }) async {
    state = state.copyWith(isUploading: true, isSuccess: false, error: null);
    try {
      final prescription = await _repository.uploadPrescription(
        file: file,
        notes: notes,
        patientId: patientId,
      );

      final prescriptionId = prescription['id'] as int;

      final order = await _repository.createOrder(
        prescriptionId: prescriptionId,
        deliveryAddress: deliveryAddress,
        contactNumber: contactNumber,
        patientId: patientId,
      );

      state = state.copyWith(
        isUploading: false,
        isSuccess: true,
        prescription: prescription,
        order: order,
      );

      _ref.read(medicinesOrdersProvider.notifier).fetchOrders();
    } catch (e) {
      state = state.copyWith(
        isUploading: false,
        isSuccess: false,
        error: e.toString(),
      );
    }
  }
}

final prescriptionUploadProvider =
    StateNotifierProvider<PrescriptionUploadNotifier, PrescriptionUploadState>((ref) {
  final repository = ref.read(medicinesRepositoryProvider);
  return PrescriptionUploadNotifier(repository, ref);
});
