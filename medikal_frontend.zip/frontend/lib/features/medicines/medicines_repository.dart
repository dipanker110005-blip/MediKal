import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final medicinesRepositoryProvider = Provider<MedicinesRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return MedicinesRepositoryImpl(apiService);
});

abstract class MedicinesRepository {
  Future<Map<String, dynamic>> uploadPrescription({
    required File file,
    String? notes,
    int? patientId,
  });

  Future<Map<String, dynamic>> createOrder({
    required int prescriptionId,
    required String deliveryAddress,
    required String contactNumber,
    int? patientId,
  });

  Future<List<dynamic>> fetchOrders();
}

class MedicinesRepositoryImpl implements MedicinesRepository {
  final ApiService _apiService;

  MedicinesRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> uploadPrescription({
    required File file,
    String? notes,
    int? patientId,
  }) async {
    try {
      final fileName = file.path.split('/').last;
      final formData = FormData.fromMap({
        'image': await MultipartFile.fromFile(
          file.path,
          filename: fileName,
        ),
        if (notes != null && notes.isNotEmpty) 'notes': notes,
        if (patientId != null) 'patient': patientId,
      });

      final response = await _apiService.post(
        '/api/medicines/prescriptions/',
        data: formData,
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to upload prescription.');
    }
  }

  @override
  Future<Map<String, dynamic>> createOrder({
    required int prescriptionId,
    required String deliveryAddress,
    required String contactNumber,
    int? patientId,
  }) async {
    try {
      final data = {
        'prescription': prescriptionId,
        'delivery_address': deliveryAddress,
        'contact_number': contactNumber,
        if (patientId != null) 'patient': patientId,
      };

      final response = await _apiService.post(
        '/api/medicines/orders/',
        data: data,
      );
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to create medicine order.');
    }
  }

  @override
  Future<List<dynamic>> fetchOrders() async {
    try {
      final response = await _apiService.get('/api/medicines/orders/');
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to fetch medicine orders.');
    }
  }
}
