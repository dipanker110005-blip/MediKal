import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'medicines_provider.dart';

class OrderHistoryScreen extends ConsumerStatefulWidget {
  const OrderHistoryScreen({super.key});

  @override
  ConsumerState<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends ConsumerState<OrderHistoryScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(medicinesOrdersProvider.notifier).fetchOrders();
    });
  }

  @override
  Widget build(BuildContext context) {
    final ordersState = ref.watch(medicinesOrdersProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Track Deliveries',
          style: AppTheme.h3,
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.primary, size: 24),
            onPressed: () => ref.read(medicinesOrdersProvider.notifier).fetchOrders(),
          ),
        ],
      ),
      body: SafeArea(
        child: ordersState.isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : ordersState.error != null
                ? _buildErrorWidget(ordersState.error!)
                : ordersState.orders.isEmpty
                    ? _buildEmptyWidget()
                    : RefreshIndicator(
                        onRefresh: () => ref.read(medicinesOrdersProvider.notifier).fetchOrders(),
                        color: AppColors.primary,
                        backgroundColor: Colors.white,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                          itemCount: ordersState.orders.length,
                          itemBuilder: (context, index) {
                            final order = ordersState.orders[index];
                            return _buildOrderCard(order)
                                .animate()
                                .fadeIn(duration: 400.ms, delay: (index * 80).ms)
                                .slideY(begin: 0.04, curve: Curves.easeOutQuad);
                          },
                        ),
                      ),
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceXL),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
                boxShadow: AppTheme.shadowSubtle,
              ),
              child: const Icon(
                Icons.local_shipping_outlined,
                size: 64,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: AppTheme.spaceXL),
            Text(
              'No Deliveries Scheduled',
              style: AppTheme.h3,
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              "You haven't requested any medicine deliveries yet. Upload your first prescription in the pharmacy hub to start tracking your order status.",
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
            ),
          ],
        ),
      ).animate().fadeIn(duration: 400.ms).scale(begin: const Offset(0.96, 0.96)),
    );
  }

  Widget _buildErrorWidget(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceM),
              decoration: const BoxDecoration(
                color: AppColors.emergencyLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.emergency),
            ),
            const SizedBox(height: AppTheme.spaceL),
            Text(
              'Failed to load orders',
              style: AppTheme.h4.copyWith(color: AppColors.emergency),
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              error,
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppTheme.spaceXL),
            ElevatedButton(
              onPressed: () => ref.read(medicinesOrdersProvider.notifier).fetchOrders(),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderCard(Map<String, dynamic> order) {
    final orderId = order['id'];
    final status = order['status'] ?? 'RECEIVED';
    final totalPrice = double.tryParse(order['total_price']?.toString() ?? '0') ?? 0.0;
    
    DateTime? createdAt;
    if (order['created_at'] != null) {
      createdAt = DateTime.tryParse(order['created_at']);
    }
    final dateStr = createdAt != null ? DateFormat('MMMM dd, yyyy • hh:mm a').format(createdAt.toLocal()) : 'Unknown Date';

    return Container(
      margin: const EdgeInsets.only(bottom: 20.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header: ID and Price Status
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order #$orderId',
                      style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      dateStr,
                      style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                  decoration: BoxDecoration(
                    color: totalPrice > 0 ? AppColors.successLight : AppColors.warningLight,
                    borderRadius: AppTheme.borderS,
                  ),
                  child: Text(
                    totalPrice > 0 ? '\$${totalPrice.toStringAsFixed(2)}' : 'Awaiting Quote',
                    style: AppTheme.bodySmall.copyWith(
                      fontWeight: FontWeight.bold,
                      color: totalPrice > 0 ? AppColors.success : AppColors.warning,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(color: AppColors.border, height: 1),
            const SizedBox(height: 20),

            // Tracker Widget
            _buildStatusTracker(status),
            const SizedBox(height: 20),
            const Divider(color: AppColors.border, height: 1),
            const SizedBox(height: 16),

            // Delivery Details Section
            Container(
              padding: const EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: AppTheme.borderM,
              ),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on_outlined, size: 16, color: AppColors.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Delivery Address',
                              style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              order['delivery_address'] ?? 'No Address Provided',
                              style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.phone_outlined, size: 16, color: AppColors.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Contact Number',
                              style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              order['contact_number'] ?? 'No Phone Provided',
                              style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusTracker(String status) {
    final statusList = ['RECEIVED', 'VERIFIED', 'PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED'];
    final currentIndex = statusList.indexOf(status);

    final labels = ['Received', 'Verified', 'Packed', 'Dispatched', 'Delivered'];
    final icons = [
      Icons.receipt_long_outlined,
      Icons.fact_check_outlined,
      Icons.inventory_2_outlined,
      Icons.local_shipping_outlined,
      Icons.assignment_turned_in_outlined,
    ];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(5, (index) {
            final isActive = index <= currentIndex;
            final isCompleted = index < currentIndex;
            final isCurrent = index == currentIndex;

            return Expanded(
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: isActive ? AppColors.primary : AppColors.card,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isActive ? AppColors.primary : AppColors.border,
                        width: 1.5,
                      ),
                      boxShadow: isCurrent
                          ? [
                              BoxShadow(
                                color: AppColors.primary.withOpacity(0.25),
                                blurRadius: 6,
                                spreadRadius: 2,
                              )
                            ]
                          : null,
                    ),
                    child: Icon(
                      icons[index],
                      size: 15,
                      color: isActive ? Colors.white : AppColors.textMuted,
                    ),
                  ),
                  if (index < 4)
                    Expanded(
                      child: Container(
                        height: 2.5,
                        color: isCompleted ? AppColors.primary : AppColors.border,
                      ),
                    ),
                ],
              ),
            );
          }),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(5, (index) {
            final isCurrent = index == currentIndex;
            final isActive = index <= currentIndex;
            return Expanded(
              child: Text(
                labels[index],
                textAlign: TextAlign.center,
                style: AppTheme.bodySmall.copyWith(
                  fontSize: 9.0,
                  fontWeight: isCurrent ? FontWeight.bold : FontWeight.w500,
                  color: isCurrent 
                      ? AppColors.primary 
                      : (isActive ? AppColors.textPrimary : AppColors.textMuted),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}
