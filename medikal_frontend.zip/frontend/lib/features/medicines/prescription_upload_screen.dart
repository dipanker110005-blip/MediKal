import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'medicines_provider.dart';
import 'order_history_screen.dart';

class PrescriptionUploadScreen extends ConsumerStatefulWidget {
  const PrescriptionUploadScreen({super.key});

  @override
  ConsumerState<PrescriptionUploadScreen> createState() => _PrescriptionUploadScreenState();
}

class _PrescriptionUploadScreenState extends ConsumerState<PrescriptionUploadScreen> {
  final _formKey = GlobalKey<FormState>();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();
  
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();
  String? _imageError;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(prescriptionUploadProvider.notifier).reset();
    });
  }

  @override
  void dispose() {
    _addressController.dispose();
    _phoneController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        setState(() {
          _selectedImage = File(pickedFile.path);
          _imageError = null;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
    }
  }

  void _submitOrder() {
    setState(() {
      _imageError = _selectedImage == null ? 'Please select or capture a prescription image' : null;
    });

    if (!_formKey.currentState!.validate() || _selectedImage == null) {
      return;
    }

    ref.read(prescriptionUploadProvider.notifier).uploadAndOrder(
      file: _selectedImage!,
      notes: _notesController.text,
      deliveryAddress: _addressController.text,
      contactNumber: _phoneController.text,
    );
  }

  @override
  Widget build(BuildContext context) {
    final uploadState = ref.watch(prescriptionUploadProvider);

    ref.listen(prescriptionUploadProvider, (previous, next) {
      if (next.isSuccess) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Prescription uploaded & order placed successfully!'),
            backgroundColor: AppColors.success,
          ),
        );
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
        );
      } else if (next.error != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.error!),
            backgroundColor: AppColors.emergency,
          ),
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Upload Prescription',
          style: AppTheme.h3,
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: uploadState.isUploading
            ? _buildUploadingIndicator()
            : SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 4.0),
                        child: Text(
                          'Prescription Image',
                          style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
                        ),
                      ),
                      const SizedBox(height: 12),
                      
                      _buildImagePickerCard()
                          .animate()
                          .fadeIn(duration: 400.ms)
                          .scale(begin: const Offset(0.98, 0.98)),
                      if (_imageError != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0, left: 8.0),
                          child: Text(
                            _imageError!,
                            style: AppTheme.bodySmall.copyWith(color: AppColors.emergency, fontWeight: FontWeight.w500),
                          ),
                        ),
                      const SizedBox(height: 28),

                      Padding(
                        padding: const EdgeInsets.only(left: 4.0),
                        child: Text(
                          'Delivery Information',
                          style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
                        ),
                      ),
                      const SizedBox(height: 12),

                      Container(
                        padding: const EdgeInsets.all(AppTheme.spaceL),
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: AppTheme.borderL,
                          border: Border.all(color: AppColors.border),
                          boxShadow: AppTheme.shadowSubtle,
                        ),
                        child: Column(
                          children: [
                            TextFormField(
                              controller: _addressController,
                              maxLines: 3,
                              decoration: const InputDecoration(
                                labelText: 'Delivery Address',
                                hintText: 'Enter your full shipping address',
                                alignLabelWithHint: true,
                                prefixIcon: Padding(
                                  padding: EdgeInsets.only(bottom: 30.0),
                                  child: Icon(Icons.location_on_outlined, color: AppColors.primary),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter your delivery address';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20),
                            TextFormField(
                              controller: _phoneController,
                              keyboardType: TextInputType.phone,
                              decoration: const InputDecoration(
                                labelText: 'Contact Number',
                                hintText: 'Enter contact phone number',
                                prefixIcon: Icon(Icons.phone_outlined, color: AppColors.primary),
                              ),
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter a contact number';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20),
                            TextFormField(
                              controller: _notesController,
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Special Instructions (Optional)',
                                hintText: 'e.g. Call before delivery, deliver in afternoon',
                                prefixIcon: Icon(Icons.note_alt_outlined, color: AppColors.primary),
                              ),
                            ),
                          ],
                        ),
                      ).animate().fadeIn(duration: 400.ms, delay: 100.ms),
                      const SizedBox(height: 36),

                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _submitOrder,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            shape: RoundedRectangleBorder(
                              borderRadius: AppTheme.borderM,
                            ),
                            elevation: 0,
                          ),
                          child: Text(
                            'Submit Order',
                            style: AppTheme.buttonText.copyWith(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      ).animate().fadeIn(duration: 400.ms, delay: 200.ms),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildImagePickerCard() {
    return Container(
      width: double.infinity,
      height: 220,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border, width: 1.5),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: _selectedImage != null
          ? ClipRRect(
              borderRadius: AppTheme.borderL,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.file(_selectedImage!, fit: BoxFit.cover),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.black.withOpacity(0.1), Colors.black.withOpacity(0.5)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 12,
                    right: 12,
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 18,
                      child: IconButton(
                        icon: const Icon(Icons.delete_outline_rounded, color: AppColors.emergency, size: 18),
                        onPressed: () => setState(() => _selectedImage = null),
                      ),
                    ),
                  ),
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: () => _showPickerOptions(),
                      icon: const Icon(Icons.sync_rounded, size: 16),
                      label: const Text('Change Photo'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: AppColors.textPrimary,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: AppTheme.borderS),
                      ),
                    ),
                  ),
                ],
              ),
            )
          : InkWell(
              onTap: () => _showPickerOptions(),
              borderRadius: AppTheme.borderL,
              child: Container(
                padding: const EdgeInsets.all(AppTheme.spaceXL),
                decoration: BoxDecoration(
                  borderRadius: AppTheme.borderL,
                  color: AppColors.primary.withOpacity(0.02),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppTheme.spaceM),
                      decoration: const BoxDecoration(
                        color: AppColors.primaryLight,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.add_photo_alternate_outlined, size: 36, color: AppColors.primary),
                    ),
                    const SizedBox(height: AppTheme.spaceM),
                    Text(
                      'Capture or Choose Prescription File',
                      style: AppTheme.bodyLarge.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: AppTheme.spaceXS),
                    Text(
                      'Supports JPG, PNG or PDF formats',
                      style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  void _showPickerOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.0)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
            child: Wrap(
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 5,
                    decoration: BoxDecoration(
                      color: AppColors.border,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
                  child: Text(
                    'Select Prescription Source',
                    style: AppTheme.h4.copyWith(color: AppColors.textPrimary),
                  ),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8.0),
                    decoration: const BoxDecoration(
                      color: AppColors.primaryLight,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.camera_alt_rounded, color: AppColors.primary),
                  ),
                  title: Text('Take Photo with Camera', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600)),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickImage(ImageSource.camera);
                  },
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Divider(color: AppColors.border, height: 1),
                ),
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8.0),
                    decoration: const BoxDecoration(
                      color: AppColors.secondaryLight,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.photo_library_rounded, color: AppColors.secondary),
                  ),
                  title: Text('Select from Gallery', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600)),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickImage(ImageSource.gallery);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildUploadingIndicator() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(
              color: AppColors.primary,
              strokeWidth: 3,
            ).animate().scale(duration: 500.ms, curve: Curves.elasticOut),
            const SizedBox(height: AppTheme.spaceXL),
            Text(
              'Uploading Prescription...',
              style: AppTheme.h3,
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              'Please wait while we transfer your file and open the order pipeline.',
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}
