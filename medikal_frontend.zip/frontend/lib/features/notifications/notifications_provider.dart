import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'notifications_repository.dart';

class NotificationsState {
  final List<dynamic> notifications;
  final bool isLoading;
  final String? error;

  NotificationsState({
    required this.notifications,
    required this.isLoading,
    this.error,
  });

  factory NotificationsState.initial() => NotificationsState(
        notifications: [],
        isLoading: false,
        error: null,
      );

  NotificationsState copyWith({
    List<dynamic>? notifications,
    bool? isLoading,
    String? error,
  }) {
    return NotificationsState(
      notifications: notifications ?? this.notifications,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class NotificationsNotifier extends StateNotifier<NotificationsState> {
  final NotificationsRepository _repository;

  NotificationsNotifier(this._repository) : super(NotificationsState.initial()) {
    fetchNotifications();
  }

  Future<void> fetchNotifications() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final list = await _repository.fetchNotifications();
      state = state.copyWith(notifications: list, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> markAllRead() async {
    try {
      await _repository.markAllAsRead();
      final updatedList = state.notifications.map((n) {
        final map = Map<String, dynamic>.from(n);
        map['is_read'] = true;
        return map;
      }).toList();
      state = state.copyWith(notifications: updatedList);
    } catch (_) {}
  }

  Future<void> markAsRead(int notificationId) async {
    try {
      await _repository.markAsRead(notificationId);
      final updatedList = state.notifications.map((n) {
        if (n['id'] == notificationId) {
          final map = Map<String, dynamic>.from(n);
          map['is_read'] = true;
          return map;
        }
        return n;
      }).toList();
      state = state.copyWith(notifications: updatedList);
    } catch (_) {}
  }

  Future<void> deleteNotification(int notificationId) async {
    // Optimistically update the UI locally
    final updatedList = state.notifications.where((n) => n['id'] != notificationId).toList();
    state = state.copyWith(notifications: updatedList);

    try {
      // Skip API call for local notifications (which have giant timestamp IDs)
      if (notificationId > 1000000000000) return;
      await _repository.deleteNotification(notificationId);
    } catch (e) {
      print("Failed to delete notification on server: $e");
    }
  }

  Future<void> clearAllNotifications() async {
    // Optimistically clear the UI locally
    state = state.copyWith(notifications: []);

    try {
      await _repository.clearAllNotifications();
    } catch (e) {
      print("Failed to clear notifications on server: $e");
    }
  }

  void addLocalNotification({required String title, required String body}) {
    final newNotif = {
      'id': DateTime.now().millisecondsSinceEpoch,
      'title': title,
      'body': body,
      'is_read': false,
      'created_at': DateTime.now().toIso8601String(),
    };
    state = state.copyWith(
      notifications: [newNotif, ...state.notifications],
    );
  }
}

final notificationsProvider =
    StateNotifierProvider<NotificationsNotifier, NotificationsState>((ref) {
  final repository = ref.read(notificationsRepositoryProvider);
  return NotificationsNotifier(repository);
});

final unreadNotificationsCountProvider = Provider<int>((ref) {
  final state = ref.watch(notificationsProvider);
  return state.notifications.where((n) => n['is_read'] == false).length;
});
