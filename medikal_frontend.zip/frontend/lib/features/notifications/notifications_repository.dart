import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final notificationsRepositoryProvider = Provider<NotificationsRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return NotificationsRepositoryImpl(apiService);
});

abstract class NotificationsRepository {
  Future<List<dynamic>> fetchNotifications();
  Future<void> markAllAsRead();
  Future<void> markAsRead(int notificationId);
  Future<void> deleteNotification(int notificationId);
  Future<void> clearAllNotifications();
}

class NotificationsRepositoryImpl implements NotificationsRepository {
  final ApiService _apiService;

  NotificationsRepositoryImpl(this._apiService);

  @override
  Future<List<dynamic>> fetchNotifications() async {
    try {
      final response = await _apiService.get('/api/notifications/');
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load notifications.');
    }
  }

  @override
  Future<void> markAllAsRead() async {
    try {
      await _apiService.post('/api/notifications/mark-all-read/');
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to mark notifications read.');
    }
  }

  @override
  Future<void> markAsRead(int notificationId) async {
    try {
      await _apiService.put(
        '/api/notifications/$notificationId/',
        data: {'is_read': true},
      );
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to mark notification read.');
    }
  }

  @override
  Future<void> deleteNotification(int notificationId) async {
    try {
      await _apiService.delete('/api/notifications/$notificationId/');
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to delete notification.');
    }
  }

  @override
  Future<void> clearAllNotifications() async {
    try {
      await _apiService.delete('/api/notifications/clear-all/');
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to clear notifications.');
    }
  }
}
