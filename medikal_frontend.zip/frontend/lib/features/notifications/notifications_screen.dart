import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import 'notifications_provider.dart';

class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(notificationsProvider.notifier).fetchNotifications();
    });
  }

  void _showClearAllConfirmDialog(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Clear All Notifications', style: AppTheme.h3),
        content: Text('Are you sure you want to delete all notifications? This action cannot be undone.', style: AppTheme.bodyMedium),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: AppColors.emergency),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      ref.read(notificationsProvider.notifier).clearAllNotifications();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All notifications cleared.'),
            duration: Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(notificationsProvider);
    final unreadCount = ref.watch(unreadNotificationsCountProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'Notifications',
          style: AppTheme.h3,
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          if (unreadCount > 0)
            TextButton(
              onPressed: () => ref.read(notificationsProvider.notifier).markAllRead(),
              child: Text(
                'Mark All Read',
                style: AppTheme.buttonText.copyWith(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          if (state.notifications.isNotEmpty)
            TextButton(
              onPressed: () => _showClearAllConfirmDialog(context),
              child: Text(
                'Clear All',
                style: AppTheme.buttonText.copyWith(color: AppColors.emergency, fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: state.isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : state.error != null
                ? _buildErrorWidget(ref, state.error!)
                : state.notifications.isEmpty
                    ? _buildEmptyWidget()
                    : RefreshIndicator(
                        onRefresh: () => ref.read(notificationsProvider.notifier).fetchNotifications(),
                        color: AppColors.primary,
                        backgroundColor: Colors.white,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
                          itemCount: state.notifications.length,
                          itemBuilder: (context, index) {
                            final notification = state.notifications[index];
                            final id = notification['id'] as int;
                            return Dismissible(
                              key: Key('notification_$id'),
                              direction: DismissDirection.endToStart,
                              background: Container(
                                alignment: Alignment.centerRight,
                                padding: const EdgeInsets.only(right: 20.0),
                                margin: const EdgeInsets.only(bottom: AppTheme.spaceM),
                                decoration: BoxDecoration(
                                  color: AppColors.emergency,
                                  borderRadius: AppTheme.borderM,
                                ),
                                child: const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 24),
                              ),
                              onDismissed: (direction) {
                                ref.read(notificationsProvider.notifier).deleteNotification(id);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Notification deleted'),
                                    duration: Duration(seconds: 2),
                                    behavior: SnackBarBehavior.floating,
                                  ),
                                );
                              },
                              child: _buildNotificationCard(ref, notification),
                            )
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                                .slideY(begin: 0.04, curve: Curves.easeOutQuad);
                          },
                        ),
                      ),
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceXL),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
                boxShadow: AppTheme.shadowSubtle,
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                size: 64,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: AppTheme.spaceXL),
            Text(
              'All Caught Up!',
              style: AppTheme.h3,
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              'You have no new notifications. We will alert you here when updates occur.',
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.4),
            ),
          ],
        ),
      ).animate().fadeIn(duration: 400.ms).scale(begin: const Offset(0.96, 0.96)),
    );
  }

  Widget _buildErrorWidget(WidgetRef ref, String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spaceXXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spaceM),
              decoration: const BoxDecoration(
                color: AppColors.emergencyLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.emergency),
            ),
            const SizedBox(height: AppTheme.spaceL),
            Text(
              'Failed to load notifications',
              style: AppTheme.h4.copyWith(color: AppColors.emergency),
            ),
            const SizedBox(height: AppTheme.spaceS),
            Text(
              error,
              textAlign: TextAlign.center,
              style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppTheme.spaceXL),
            ElevatedButton(
              onPressed: () => ref.read(notificationsProvider.notifier).fetchNotifications(),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationCard(WidgetRef ref, Map<String, dynamic> notification) {
    final id = notification['id'] as int;
    final title = notification['title'] ?? '';
    final body = notification['body'] ?? '';
    final isRead = notification['is_read'] ?? false;
    
    DateTime? createdAt;
    if (notification['created_at'] != null) {
      createdAt = DateTime.tryParse(notification['created_at']);
    }
    final timeStr = createdAt != null ? DateFormat('MMM dd, hh:mm a').format(createdAt.toLocal()) : '';

    IconData iconData = Icons.notifications_rounded;
    Color iconColor = AppColors.textSecondary;
    Color lightBgColor = AppColors.border;
    
    final lowerTitle = title.toLowerCase();
    if (lowerTitle.contains('appointment') || lowerTitle.contains('booked') || lowerTitle.contains('consultation')) {
      iconData = Icons.calendar_month_rounded;
      iconColor = AppColors.primary;
      lightBgColor = AppColors.primaryLight;
    } else if (lowerTitle.contains('order') || lowerTitle.contains('packed') || lowerTitle.contains('delivery') || lowerTitle.contains('delivered') || lowerTitle.contains('prescription')) {
      iconData = Icons.local_shipping_rounded;
      iconColor = AppColors.secondary;
      lightBgColor = AppColors.secondaryLight;
    } else if (lowerTitle.contains('emergency') || lowerTitle.contains('alert') || lowerTitle.contains('urgent')) {
      iconData = Icons.emergency_rounded;
      iconColor = AppColors.emergency;
      lightBgColor = AppColors.emergencyLight;
    } else {
      iconData = Icons.notifications_rounded;
      iconColor = AppColors.primary;
      lightBgColor = AppColors.primaryLight;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: AppTheme.spaceM),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderM,
        boxShadow: AppTheme.shadowSubtle,
        border: Border.all(
          color: isRead ? AppColors.border : iconColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: AppTheme.borderM,
        child: InkWell(
          onTap: () {
            if (!isRead) {
              ref.read(notificationsProvider.notifier).markAsRead(id);
            }
          },
          child: Stack(
            children: [
              if (!isRead)
                Positioned(
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: 4,
                  child: Container(color: iconColor),
                ),
              Padding(
                padding: const EdgeInsets.all(AppTheme.spaceL),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(width: 4), // offset spacing for left accent strip
                    Container(
                      padding: const EdgeInsets.all(10.0),
                      decoration: BoxDecoration(
                        color: lightBgColor,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(iconData, color: iconColor, size: 20),
                    ),
                    const SizedBox(width: AppTheme.spaceL),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text(
                                  title,
                                  style: AppTheme.bodyLarge.copyWith(
                                    fontWeight: isRead ? FontWeight.w600 : FontWeight.w800,
                                    fontSize: 14.5,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                              ),
                              const SizedBox(width: AppTheme.spaceS),
                              if (!isRead)
                                Container(
                                  margin: const EdgeInsets.only(top: 6, right: 6),
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: iconColor,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: iconColor.withOpacity(0.4),
                                        blurRadius: 4,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline_rounded, size: 18, color: AppColors.textMuted),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                tooltip: 'Delete Notification',
                                onPressed: () {
                                  ref.read(notificationsProvider.notifier).deleteNotification(id);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Notification deleted'),
                                      duration: Duration(seconds: 2),
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: AppTheme.spaceXS),
                          Text(
                            body,
                            style: AppTheme.bodyMedium.copyWith(
                              color: isRead ? AppColors.textSecondary : AppColors.textPrimary,
                              height: 1.4,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: AppTheme.spaceS),
                          Text(
                            timeStr,
                            style: AppTheme.bodySmall.copyWith(
                              color: AppColors.textMuted,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
