import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class MedicalInvoice {
  final String date;
  final String description;
  final String amount;
  final String status; // 'Paid', 'Pending', 'Claimed'

  const MedicalInvoice({
    required this.date,
    required this.description,
    required this.amount,
    required this.status,
  });
}

class BillingInsuranceScreen extends StatelessWidget {
  const BillingInsuranceScreen({super.key});

  final List<MedicalInvoice> _invoices = const [
    MedicalInvoice(
      date: 'Jun 05, 2026',
      description: 'Cardiology Consultation - Dr. Sarah Jenkins',
      amount: '\$200.00',
      status: 'Paid',
    ),
    MedicalInvoice(
      date: 'May 30, 2026',
      description: 'Prescription Refill Order #ORD9845',
      amount: '\$45.20',
      status: 'Claimed',
    ),
    MedicalInvoice(
      date: 'May 20, 2026',
      description: 'Clinical Triage Diagnostic Lab CBC Panel',
      amount: '\$110.00',
      status: 'Paid',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Insurance & Billing', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Insurance Card
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F172A), Color(0xFF1E3A8A)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: AppTheme.borderXL,
                      boxShadow: AppTheme.shadowCard,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'PRIMARY CARE HEALTH PLAN',
                                  style: GoogleFonts.inter(
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.blue.shade200,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'BlueCross Shield Care',
                                  style: GoogleFonts.outfit(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                            const Icon(Icons.shield_rounded, color: Colors.blueAccent, size: 36),
                          ],
                        ),
                        const SizedBox(height: 24),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildInfoColumn('POLICY NUMBER', 'POL-98420-228'),
                            _buildInfoColumn('GROUP NUMBER', 'GRP-0045'),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildInfoColumn('PRIMARY HOLDER', 'John Doe'),
                            _buildInfoColumn('CO-PAY AMOUNT', '\$20.00'),
                          ],
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms),

                  const SizedBox(height: 28),

                  Text('Coverage Limit Progress', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: AppTheme.borderL,
                      border: Border.all(color: AppColors.border),
                      boxShadow: AppTheme.shadowSubtle,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Deductible Limit', style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
                            Text('\$640.00 / \$2,000.00', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: 0.32,
                          color: AppColors.primary,
                          backgroundColor: AppColors.border,
                          minHeight: 8,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms, delay: 100.ms),

                  const SizedBox(height: 28),

                  Text('Invoice Receipts & Claims', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),

                  ..._invoices.map((inv) => _buildInvoiceCard(inv)).toList(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoColumn(String label, String val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 8,
            fontWeight: FontWeight.bold,
            color: Colors.white70,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          val,
          style: AppTheme.bodyMedium.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildInvoiceCard(MedicalInvoice inv) {
    Color statusColor = AppColors.success;
    Color statusBgColor = const Color(0xFFD1FAE5);

    if (inv.status == 'Pending') {
      statusColor = AppColors.urgent;
      statusBgColor = AppColors.urgentLight;
    } else if (inv.status == 'Claimed') {
      statusColor = AppColors.primary;
      statusBgColor = AppColors.primaryLight;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        title: Text(inv.description, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
        subtitle: Text(inv.date, style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(inv.amount, style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(color: statusBgColor, borderRadius: BorderRadius.circular(8)),
              child: Text(
                inv.status.toUpperCase(),
                style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.bold, color: statusColor),
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 300.ms);
  }
}
