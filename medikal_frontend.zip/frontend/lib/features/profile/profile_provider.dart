import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'profile_repository.dart';

class ProfileState {
  final Map<String, dynamic>? user;
  final Map<String, dynamic>? profile;
  final bool isLoading;
  final bool isSaving;
  final String? error;
  final String? successMessage;

  ProfileState({
    this.user,
    this.profile,
    required this.isLoading,
    required this.isSaving,
    this.error,
    this.successMessage,
  });

  factory ProfileState.initial() => ProfileState(
        user: null,
        profile: null,
        isLoading: false,
        isSaving: false,
        error: null,
        successMessage: null,
      );

  ProfileState copyWith({
    Map<String, dynamic>? user,
    Map<String, dynamic>? profile,
    bool? isLoading,
    bool? isSaving,
    String? error,
    String? successMessage,
  }) {
    return ProfileState(
      user: user ?? this.user,
      profile: profile ?? this.profile,
      isLoading: isLoading ?? this.isLoading,
      isSaving: isSaving ?? this.isSaving,
      error: error ?? this.error,
      successMessage: successMessage ?? this.successMessage,
    );
  }
}

class ProfileNotifier extends StateNotifier<ProfileState> {
  final ProfileRepository _repository;

  ProfileNotifier(this._repository) : super(ProfileState.initial()) {
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    state = state.copyWith(isLoading: true, error: null, successMessage: null);
    try {
      final response = await _repository.fetchUserProfile();
      state = state.copyWith(
        user: response['user'],
        profile: response['profile'],
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<bool> updateProfile(Map<String, dynamic> data) async {
    state = state.copyWith(isSaving: true, error: null, successMessage: null);
    try {
      final response = await _repository.updateUserProfile(data);
      state = state.copyWith(
        user: response['user'],
        profile: response['profile'],
        isSaving: false,
        successMessage: 'Profile updated successfully!',
      );
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isSaving: false);
      return false;
    }
  }

  void clearMessage() {
    state = state.copyWith(successMessage: null, error: null);
  }
}

final profileProvider = StateNotifierProvider<ProfileNotifier, ProfileState>((ref) {
  final repository = ref.read(profileRepositoryProvider);
  return ProfileNotifier(repository);
});
