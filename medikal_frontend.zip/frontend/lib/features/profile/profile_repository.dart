import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/api_service.dart';

final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  final apiService = ref.read(apiServiceProvider);
  return ProfileRepositoryImpl(apiService);
});

abstract class ProfileRepository {
  Future<Map<String, dynamic>> fetchUserProfile();
  Future<Map<String, dynamic>> updateUserProfile(Map<String, dynamic> data);
}

class ProfileRepositoryImpl implements ProfileRepository {
  final ApiService _apiService;

  ProfileRepositoryImpl(this._apiService);

  @override
  Future<Map<String, dynamic>> fetchUserProfile() async {
    try {
      final response = await _apiService.get('/api/auth/profile/');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to load profile details.');
    }
  }

  @override
  Future<Map<String, dynamic>> updateUserProfile(Map<String, dynamic> data) async {
    try {
      final response = await _apiService.put('/api/auth/profile/', data: data);
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw Exception(e.response?.data?['detail'] ?? 'Failed to update profile details.');
    }
  }
}
