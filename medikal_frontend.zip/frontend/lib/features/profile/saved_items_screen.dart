import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class SavedItemsScreen extends StatefulWidget {
  const SavedItemsScreen({super.key});

  @override
  State<SavedItemsScreen> createState() => _SavedItemsScreenState();
}

class _SavedItemsScreenState extends State<SavedItemsScreen> {
  final List<Map<String, String>> _doctors = [
    {
      'name': 'Dr. Sarah Jenkins',
      'specialty': 'Cardiologist',
      'hospital': 'Heart Center',
      'rating': '4.9',
    },
    {
      'name': 'Dr. Michael Chen',
      'specialty': 'Dermatologist',
      'hospital': 'Central Clinic',
      'rating': '4.8',
    },
  ];

  final List<Map<String, String>> _medicines = [
    {
      'name': 'Metformin',
      'generic': 'Metformin HCl',
      'purpose': 'Type-2 Diabetes',
    },
    {
      'name': 'Albuterol Inhaler',
      'generic': 'Salbutamol',
      'purpose': 'Asthma Relief',
    },
  ];

  final List<Map<String, String>> _pharmacies = [
    {
      'name': '24/7 Wellness Pharmacy',
      'distance': '1.2 miles',
      'hours': 'Open 24 Hours',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text('Saved Items', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
          bottom: TabBar(
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.textSecondary,
            indicatorColor: AppColors.primary,
            labelStyle: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold),
            tabs: const [
              Tab(text: 'Doctors', icon: Icon(Icons.people_outline_rounded, size: 20)),
              Tab(text: 'Medicines', icon: Icon(Icons.medication_outlined, size: 20)),
              Tab(text: 'Pharmacies', icon: Icon(Icons.storefront_outlined, size: 20)),
            ],
          ),
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 800),
              child: TabBarView(
                children: [
                  _buildDoctorsList(),
                  _buildMedicinesList(),
                  _buildPharmaciesList(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDoctorsList() {
    if (_doctors.isEmpty) return _buildEmptyState('No Saved Doctors');
    return ListView.builder(
      padding: const EdgeInsets.all(24.0),
      itemCount: _doctors.length,
      itemBuilder: (context, index) {
        final doc = _doctors[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 16.0),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: AppTheme.borderL,
            border: Border.all(color: AppColors.border),
            boxShadow: AppTheme.shadowSubtle,
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
            leading: CircleAvatar(
              backgroundColor: AppColors.primaryLight,
              child: const Icon(Icons.person_rounded, color: AppColors.primary),
            ),
            title: Text(doc['name']!, style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold)),
            subtitle: Text('${doc['specialty']}  •  ${doc['hospital']}', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: IconButton(
              icon: const Icon(Icons.bookmark_remove_outlined, color: AppColors.emergency),
              onPressed: () {
                setState(() {
                  _doctors.removeAt(index);
                });
              },
            ),
          ),
        ).animate().fadeIn(duration: 300.ms);
      },
    );
  }

  Widget _buildMedicinesList() {
    if (_medicines.isEmpty) return _buildEmptyState('No Saved Medicines');
    return ListView.builder(
      padding: const EdgeInsets.all(24.0),
      itemCount: _medicines.length,
      itemBuilder: (context, index) {
        final med = _medicines[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 16.0),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: AppTheme.borderL,
            border: Border.all(color: AppColors.border),
            boxShadow: AppTheme.shadowSubtle,
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
            leading: CircleAvatar(
              backgroundColor: Colors.orange.shade50,
              child: Icon(Icons.medication_rounded, color: Colors.orange.shade700),
            ),
            title: Text(med['name']!, style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold)),
            subtitle: Text('${med['generic']}  •  ${med['purpose']}', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: IconButton(
              icon: const Icon(Icons.bookmark_remove_outlined, color: AppColors.emergency),
              onPressed: () {
                setState(() {
                  _medicines.removeAt(index);
                });
              },
            ),
          ),
        ).animate().fadeIn(duration: 300.ms);
      },
    );
  }

  Widget _buildPharmaciesList() {
    if (_pharmacies.isEmpty) return _buildEmptyState('No Saved Pharmacies');
    return ListView.builder(
      padding: const EdgeInsets.all(24.0),
      itemCount: _pharmacies.length,
      itemBuilder: (context, index) {
        final pharm = _pharmacies[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 16.0),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: AppTheme.borderL,
            border: Border.all(color: AppColors.border),
            boxShadow: AppTheme.shadowSubtle,
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
            leading: CircleAvatar(
              backgroundColor: Colors.teal.shade50,
              child: Icon(Icons.storefront_rounded, color: Colors.teal.shade700),
            ),
            title: Text(pharm['name']!, style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold)),
            subtitle: Text('${pharm['distance']}  •  ${pharm['hours']}', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: IconButton(
              icon: const Icon(Icons.bookmark_remove_outlined, color: AppColors.emergency),
              onPressed: () {
                setState(() {
                  _pharmacies.removeAt(index);
                });
              },
            ),
          ),
        ).animate().fadeIn(duration: 300.ms);
      },
    );
  }

  Widget _buildEmptyState(String title) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.bookmark_border_rounded, size: 48, color: AppColors.textMuted),
          const SizedBox(height: 16),
          Text(title, style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Items you bookmark will appear here for fast access.', style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}
