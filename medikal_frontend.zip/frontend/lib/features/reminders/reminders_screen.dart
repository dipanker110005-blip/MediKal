import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class CareReminder {
  final String id;
  final String title;
  final String type; // 'Medicine', 'Refill', 'Test', 'Appointment'
  final String scheduleTime;
  final String details;
  bool isCompleted;

  CareReminder({
    required this.id,
    required this.title,
    required this.type,
    required this.scheduleTime,
    required this.details,
    this.isCompleted = false,
  });
}

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  final List<CareReminder> _reminders = [
    CareReminder(
      id: 'REM001',
      title: 'Metformin (500mg)',
      type: 'Medicine',
      scheduleTime: '08:30 AM',
      details: 'Take 1 tablet with breakfast. Prevents glucose spikes.',
    ),
    CareReminder(
      id: 'REM002',
      title: 'Lisinopril Refill Alert',
      type: 'Refill',
      scheduleTime: '10:00 AM',
      details: '7 doses remaining. Refill prescription at MediKal Pharmacy.',
    ),
    CareReminder(
      id: 'REM003',
      title: 'Fasting Lipid Panel Test',
      type: 'Test',
      scheduleTime: '09:00 AM - Tomorrow',
      details: 'Do not eat or drink anything except water for 12 hours prior.',
    ),
    CareReminder(
      id: 'REM004',
      title: 'Dr. Sarah Jenkins - Cardiology Consultation',
      type: 'Appointment',
      scheduleTime: '02:30 PM - Jun 15',
      details: 'Follow-up for chronic hypertension. Bring vitals logs.',
    ),
    CareReminder(
      id: 'REM005',
      title: 'Atorvastatin (20mg)',
      type: 'Medicine',
      scheduleTime: '09:00 PM',
      details: 'Take 1 tablet before bedtime. Protects heart pathways.',
    ),
  ];

  void _addReminderDialog() {
    final titleController = TextEditingController();
    final timeController = TextEditingController(text: '08:00 AM');
    final detailsController = TextEditingController();
    String selectedType = 'Medicine';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('Add Care Reminder', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Reminder Title', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                TextField(
                  controller: titleController,
                  style: AppTheme.bodyMedium,
                  decoration: InputDecoration(
                    hintText: 'e.g. Paracetamol or Blood Test',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
                const SizedBox(height: 16),
                Text('Category', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  items: ['Medicine', 'Refill', 'Test', 'Appointment']
                      .map((t) => DropdownMenuItem(value: t, child: Text(t, style: AppTheme.bodyMedium)))
                      .toList(),
                  onChanged: (val) {
                    if (val != null) {
                      setDialogState(() {
                        selectedType = val;
                      });
                    }
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
                const SizedBox(height: 16),
                Text('Schedule Time', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                TextField(
                  controller: timeController,
                  style: AppTheme.bodyMedium,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
                const SizedBox(height: 16),
                Text('Instructions / Notes', style: AppTheme.bodySmall.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                TextField(
                  controller: detailsController,
                  style: AppTheme.bodyMedium,
                  maxLines: 2,
                  decoration: InputDecoration(
                    hintText: 'e.g. Take with food, fast for 12h...',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
            ),
            ElevatedButton(
              onPressed: () {
                if (titleController.text.isNotEmpty) {
                  setState(() {
                    _reminders.add(
                      CareReminder(
                        id: 'REM${DateTime.now().millisecond}',
                        title: titleController.text,
                        type: selectedType,
                        scheduleTime: timeController.text,
                        details: detailsController.text,
                      ),
                    );
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Scheduled reminder: ${titleController.text}'),
                      backgroundColor: AppColors.success,
                    ),
                  );
                }
              },
              child: const Text('Schedule'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Follow-up Reminders', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_alarm_rounded, color: AppColors.primary),
            onPressed: _addReminderDialog,
            tooltip: 'Add Care Task',
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              children: [
                // Checklist Status Header
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F766E), Color(0xFF0D9488)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: AppTheme.borderXL,
                      boxShadow: AppTheme.shadowCard,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Today's Care Plan",
                          style: AppTheme.h3.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Keep track of medication schedules, laboratory tests, and doctor appointments.',
                          style: AppTheme.bodySmall.copyWith(color: Colors.white70, height: 1.45),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          '${_reminders.where((r) => r.isCompleted).length} of ${_reminders.length} tasks completed',
                           style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.bold, color: const Color(0xFFD1FAE5)),
                        ),
                      ],
                    ),
                  ),
                ),

                Expanded(
                  child: _reminders.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0),
                          itemCount: _reminders.length,
                          itemBuilder: (context, index) {
                            final reminder = _reminders[index];
                            return _buildReminderCard(reminder)
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 40).ms)
                                .slideY(begin: 0.03);
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.alarm_off_rounded, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 16),
            Text('No Scheduled Reminders', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('You are all caught up! Click the alarm button to set medicine or lab reminders.', textAlign: TextAlign.center, style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }

  Widget _buildReminderCard(CareReminder reminder) {
    IconData itemIcon = Icons.notifications_active_outlined;
    Color itemColor = AppColors.primary;

    switch (reminder.type) {
      case 'Medicine':
        itemIcon = Icons.medication_rounded;
        itemColor = AppColors.primary;
        break;
      case 'Refill':
        itemIcon = Icons.shopping_basket_outlined;
        itemColor = Colors.orange.shade700;
        break;
      case 'Test':
        itemIcon = Icons.science_outlined;
        itemColor = Colors.teal.shade700;
        break;
      case 'Appointment':
        itemIcon = Icons.calendar_month_outlined;
        itemColor = Colors.purple.shade700;
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowSubtle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Checkbox(
              value: reminder.isCompleted,
              activeColor: AppColors.primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
              onChanged: (val) {
                if (val != null) {
                  setState(() {
                    reminder.isCompleted = val;
                  });
                }
              },
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          reminder.title,
                          style: AppTheme.bodyLarge.copyWith(
                            fontWeight: FontWeight.bold,
                            color: reminder.isCompleted ? AppColors.textMuted : AppColors.textPrimary,
                            decoration: reminder.isCompleted ? TextDecoration.lineThrough : null,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: itemColor.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(itemIcon, size: 10, color: itemColor),
                            const SizedBox(width: 4),
                            Text(
                              reminder.type,
                              style: GoogleFonts.inter(fontSize: 9, fontWeight: FontWeight.bold, color: itemColor),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.access_time_rounded, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 6),
                      Text(
                        reminder.scheduleTime,
                        style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    reminder.details,
                    style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, height: 1.35),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
