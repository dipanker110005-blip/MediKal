import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../landing/landing_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToNext();
  }

  void _navigateToNext() async {
    await Future.delayed(const Duration(milliseconds: 2500));
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => const LandingScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B2524), // Calming Deep Forest Teal
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Subtle circular gradients for organic depth
          Positioned(
            left: -100,
            top: -100,
            child: Container(
              width: 350,
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withOpacity(0.15),
              ),
            ),
          ).animate().fadeIn(duration: 1200.ms),
          Positioned(
            right: -50,
            bottom: -50,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.secondary.withOpacity(0.08),
              ),
            ),
          ).animate().fadeIn(duration: 1500.ms),
          
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Premium, modern Logo Container
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(28.0),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.12),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 30,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(28.0),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          top: -20,
                          left: -20,
                          child: CircleAvatar(
                            radius: 30,
                            backgroundColor: Colors.white.withOpacity(0.04),
                          ),
                        ),
                        const Icon(
                          Icons.healing_rounded,
                          size: 44,
                          color: Color(0xFF2DD4BF), // Light Mint Teal
                        ),
                      ],
                    ),
                  ),
                )
                    .animate()
                    .scale(
                      duration: 1000.ms,
                      curve: Curves.easeOutBack,
                      begin: const Offset(0.4, 0.4),
                    )
                    .fadeIn(duration: 600.ms),
                const SizedBox(height: 28),
                // App Title
                Text(
                  'MEDIKAL',
                  style: GoogleFonts.outfit(
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 4.0,
                  ),
                )
                    .animate()
                    .fadeIn(delay: 200.ms, duration: 600.ms)
                    .slideY(begin: 0.2, curve: Curves.easeOutQuad),
                const SizedBox(height: 8),
                // Slogan / Tagline
                Text(
                  'Your Trustworthy Health Assistant',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.6),
                    letterSpacing: 0.8,
                    fontWeight: FontWeight.w500,
                  ),
                )
                    .animate()
                    .fadeIn(delay: 450.ms, duration: 600.ms)
                    .slideY(begin: 0.2, curve: Curves.easeOutQuad),
              ],
            ),
          ),
          
          // Subtle loading indicator at bottom
          Positioned(
            bottom: 64,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  color: const Color(0xFF2DD4BF).withOpacity(0.7),
                  strokeWidth: 2,
                ),
              ),
            ),
          ).animate().fadeIn(delay: 900.ms, duration: 450.ms),
        ],
      ),
    );
  }
}
