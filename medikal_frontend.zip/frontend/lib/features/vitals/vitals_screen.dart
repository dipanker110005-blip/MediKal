import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

class VitalsLog {
  final String vitalName;
  final String value;
  final String unit;
  final String status; // 'Optimal', 'Elevated', 'Critical'
  final Color themeColor;
  final IconData icon;
  final String lastLogged;

  const VitalsLog({
    required this.vitalName,
    required this.value,
    required this.unit,
    required this.status,
    required this.themeColor,
    required this.icon,
    required this.lastLogged,
  });
}

class VitalsScreen extends StatefulWidget {
  const VitalsScreen({super.key});

  @override
  State<VitalsScreen> createState() => _VitalsScreenState();
}

class _VitalsScreenState extends State<VitalsScreen> {
  bool _isSyncing = false;
  bool _devicesConnected = false;
  int _waterCups = 3;
  int _steps = 4210;

  final List<VitalsLog> _vitals = [
    const VitalsLog(
      vitalName: 'Blood Pressure',
      value: '122/78',
      unit: 'mmHg',
      status: 'Optimal',
      themeColor: AppColors.primary,
      icon: Icons.favorite_rounded,
      lastLogged: '2 hours ago',
    ),
    const VitalsLog(
      vitalName: 'Blood Glucose',
      value: '104',
      unit: 'mg/dL',
      status: 'Optimal',
      themeColor: AppColors.secondary,
      icon: Icons.bloodtype_rounded,
      lastLogged: 'Fasting • 4 hours ago',
    ),
    const VitalsLog(
      vitalName: 'Heart Rate',
      value: '72',
      unit: 'BPM',
      status: 'Optimal',
      themeColor: Colors.redAccent,
      icon: Icons.show_chart_rounded,
      lastLogged: '10 mins ago via Sync',
    ),
    const VitalsLog(
      vitalName: 'Oxygen Saturation (SpO2)',
      value: '98',
      unit: '%',
      status: 'Optimal',
      themeColor: Colors.blueAccent,
      icon: Icons.air_rounded,
      lastLogged: '10 mins ago via Sync',
    ),
    const VitalsLog(
      vitalName: 'Body Temperature',
      value: '98.4',
      unit: '°F',
      status: 'Optimal',
      themeColor: Colors.orange,
      icon: Icons.thermostat_rounded,
      lastLogged: '1 day ago',
    ),
    const VitalsLog(
      vitalName: 'Body Weight',
      value: '76.5',
      unit: 'kg',
      status: 'Optimal',
      themeColor: Colors.blueGrey,
      icon: Icons.monitor_weight_rounded,
      lastLogged: '3 days ago',
    ),
  ];

  void _triggerDeviceSync() {
    setState(() {
      _isSyncing = true;
    });

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _isSyncing = false;
          _devicesConnected = true;
          _steps = 7840; // updated mock step count
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Wearables (Garmin & Apple Watch) synced successfully.'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });
  }

  void _logVitalDialog(VitalsLog vital) {
    final controller = TextEditingController(text: vital.value);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Log ${vital.vitalName}', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter current reading in ${vital.unit}:', style: AppTheme.bodyMedium),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              keyboardType: TextInputType.text,
              style: AppTheme.bodyMedium,
              decoration: InputDecoration(
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Updated ${vital.vitalName} log: ${controller.text} ${vital.unit}'),
                  backgroundColor: AppColors.success,
                ),
              );
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Vitals & Device Sync', style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // 1. Wearable Sync Command Center
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _devicesConnected
                            ? [const Color(0xFF0F766E), const Color(0xFF0F172A)]
                            : [const Color(0xFF1E293B), const Color(0xFF0F172A)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: AppTheme.borderXL,
                      boxShadow: AppTheme.shadowCard,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(_devicesConnected ? 0.15 : 0.08),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    _devicesConnected ? Icons.watch_rounded : Icons.watch_off_rounded,
                                    color: _devicesConnected ? const Color(0xFF10B981) : Colors.white60,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  _devicesConnected ? 'WEARABLES CONNECTED' : 'NO WEARABLE CONNECTED',
                                  style: GoogleFonts.inter(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: _devicesConnected ? const Color(0xFFA7F3D0) : Colors.white60,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ],
                            ),
                            if (_isSyncing)
                              const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _devicesConnected ? 'Garmin & Apple Watch Active' : 'Sync Wearable Devices',
                          style: AppTheme.h3.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _devicesConnected
                              ? 'Continuous synchronization active. Heart rate and SpO2 trends are automatically captured.'
                              : 'Connect glucose meters, blood pressure cuffs, and smartwatches to automatically log metrics.',
                          style: AppTheme.bodySmall.copyWith(color: Colors.white70, height: 1.4),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _isSyncing ? null : _triggerDeviceSync,
                            icon: const Icon(Icons.sync_rounded, size: 18),
                            label: Text(_isSyncing ? 'Syncing...' : 'Sync Now'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: const Color(0xFF0F172A),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 400.ms),

                  const SizedBox(height: 28),

                  // 2. Lifestyle Tracker Counters
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: AppTheme.borderL,
                            border: Border.all(color: AppColors.border),
                            boxShadow: AppTheme.shadowSubtle,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.water_drop_outlined, color: Colors.blueAccent, size: 18),
                                  const SizedBox(width: 8),
                                  Text('Water Intake', style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('$_waterCups cups', style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold)),
                                  IconButton(
                                    icon: const Icon(Icons.add_circle_outline_rounded, color: AppColors.primary),
                                    onPressed: () {
                                      setState(() {
                                        _waterCups++;
                                      });
                                    },
                                    constraints: const BoxConstraints(),
                                    padding: EdgeInsets.zero,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: AppTheme.borderL,
                            border: Border.all(color: AppColors.border),
                            boxShadow: AppTheme.shadowSubtle,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.directions_walk_rounded, color: Colors.orange, size: 18),
                                  const SizedBox(width: 8),
                                  Text('Daily Steps', style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary)),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Text('$_steps / 10K', style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ).animate().fadeIn(duration: 400.ms, delay: 100.ms),

                  const SizedBox(height: 28),

                  Text('Physiological Log', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),

                  // Vitals grid
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.35,
                    ),
                    itemCount: _vitals.length,
                    itemBuilder: (context, index) {
                      final vital = _vitals[index];
                      return Container(
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: AppTheme.borderL,
                          border: Border.all(color: AppColors.border),
                          boxShadow: AppTheme.shadowSubtle,
                        ),
                        child: InkWell(
                          onTap: () => _logVitalDialog(vital),
                          borderRadius: AppTheme.borderL,
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      vital.vitalName,
                                      style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                                    ),
                                    Icon(vital.icon, color: vital.themeColor, size: 18),
                                  ],
                                ),
                                const Spacer(),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.baseline,
                                  textBaseline: TextBaseline.alphabetic,
                                  children: [
                                    Text(
                                      vital.value,
                                      style: GoogleFonts.outfit(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      vital.unit,
                                      style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary),
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  vital.lastLogged,
                                  style: AppTheme.bodySmall.copyWith(color: AppColors.textMuted, fontSize: 10),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ).animate().fadeIn(duration: 400.ms, delay: 200.ms),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
