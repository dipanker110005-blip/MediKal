import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fl_chart/fl_chart.dart';
import 'admin_provider.dart';

/// A reusable widget that lifts/scales its child on mouse hover.
class _HoverPop extends StatefulWidget {
  final Widget child;
  final double scaleAmount;
  final double liftAmount; // in logical pixels (upward)
  final Duration duration;

  const _HoverPop({
    required this.child,
    this.scaleAmount = 1.04,
    this.liftAmount = 6.0,
    this.duration = const Duration(milliseconds: 170),
  });

  @override
  State<_HoverPop> createState() => _HoverPopState();
}

class _HoverPopState extends State<_HoverPop> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: AnimatedSlide(
        offset: _hovered ? Offset(0, -(widget.liftAmount / 100)) : Offset.zero,
        duration: widget.duration,
        curve: Curves.easeOutCubic,
        child: AnimatedScale(
          scale: _hovered ? widget.scaleAmount : 1.0,
          duration: widget.duration,
          curve: Curves.easeOutCubic,
          child: widget.child,
        ),
      ),
    );
  }
}

class AdminDashboardScreen extends ConsumerStatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  ConsumerState<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends ConsumerState<AdminDashboardScreen> {
  // Local Premium Dark Theme Configuration
  static const Color darkBg = Color(0xFF090D16);
  static const Color darkCard = Color(0xFF111827);
  static const Color darkBorder = Color(0xFF1F2937);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF9CA3AF);
  static const Color accentColor = Color(0xFF10B981); // Emerald

  @override
  Widget build(BuildContext context) {
    final analyticsState = ref.watch(adminAnalyticsProvider);

    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        title: const Text(
          'System Analytics',
          style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: accentColor),
            onPressed: () => ref.read(adminAnalyticsProvider.notifier).fetchAnalytics(),
          ),
        ],
      ),
      body: SafeArea(
        child: analyticsState.isLoading
            ? const Center(child: CircularProgressIndicator(color: accentColor))
            : analyticsState.error != null
                ? _buildErrorWidget(analyticsState.error!)
                : RefreshIndicator(
                    onRefresh: () => ref.read(adminAnalyticsProvider.notifier).fetchAnalytics(),
                    backgroundColor: darkCard,
                    color: accentColor,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(24.0, 24.0, 24.0, 110.0),
                      child: MediaQuery.of(context).size.width > 1000
                          ? _buildDesktopLayout(context, analyticsState.data)
                          : _buildMobileLayout(context, analyticsState.data),
                    ),
                  ),
      ),
    );
  }

  Widget _buildDesktopLayout(BuildContext context, Map<String, dynamic> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildHeaderSection(),
        const SizedBox(height: 24),
        _buildStatsGrid(context, data),
        const SizedBox(height: 28),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: _buildSectionCard(
                title: 'Revenue Trend (Last 30 Days)',
                icon: Icons.trending_up_rounded,
                child: _buildRevenueTimeline(data),
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              flex: 2,
              child: _buildSectionCard(
                title: 'Consultation Status & Types',
                icon: Icons.pie_chart_outline_rounded,
                child: _buildStatusBreakdown(data),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: _buildSectionCard(
                title: 'Specialty Distribution',
                icon: Icons.category_outlined,
                child: _buildSpecialtyBreakdown(data),
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: _buildSectionCard(
                title: 'Patient Age Demographics',
                icon: Icons.bar_chart_rounded,
                child: _buildAgeDemographics(data),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildSectionCard(
          title: 'Patient Blood Group Shares',
          icon: Icons.bloodtype_outlined,
          child: _buildBloodGroupShares(data),
        ),
      ],
    );
  }

  Widget _buildMobileLayout(BuildContext context, Map<String, dynamic> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildHeaderSection(),
        const SizedBox(height: 24),
        _buildStatsGrid(context, data),
        const SizedBox(height: 28),
        _buildSectionCard(
          title: 'Revenue Trend (Last 30 Days)',
          icon: Icons.trending_up_rounded,
          child: _buildRevenueTimeline(data),
        ),
        const SizedBox(height: 24),
        _buildSectionCard(
          title: 'Consultation Status & Types',
          icon: Icons.pie_chart_outline_rounded,
          child: _buildStatusBreakdown(data),
        ),
        const SizedBox(height: 24),
        _buildSectionCard(
          title: 'Specialty Distribution',
          icon: Icons.category_outlined,
          child: _buildSpecialtyBreakdown(data),
        ),
        const SizedBox(height: 24),
        _buildSectionCard(
          title: 'Patient Age Demographics',
          icon: Icons.bar_chart_rounded,
          child: _buildAgeDemographics(data),
        ),
        const SizedBox(height: 24),
        _buildSectionCard(
          title: 'Patient Blood Group Shares',
          icon: Icons.bloodtype_outlined,
          child: _buildBloodGroupShares(data),
        ),
      ],
    );
  }

  Widget _buildHeaderSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'ADMINISTRATIVE CONTROL CENTER',
          style: TextStyle(
            fontSize: 11,
            color: accentColor,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ).animate().fadeIn(duration: 300.ms),
        const SizedBox(height: 4),
        const Text(
          'MediKal Platform Overview',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: textPrimary,
          ),
        ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1),
      ],
    );
  }

  Widget _buildSectionCard({required String title, required IconData icon, required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(24.0),
        border: Border.all(color: darkBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: accentColor, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          child,
        ],
      ),
    ).animate().fadeIn(duration: 350.ms).slideY(begin: 0.05);
  }

  Widget _buildStatsGrid(BuildContext context, Map<String, dynamic> data) {
    final revenue = data['total_revenue']?.toString() ?? '0.00';
    final patients = data['patient_count']?.toString() ?? '0';
    final doctors = data['doctor_count']?.toString() ?? '0';
    final appointments = data['appointment_count']?.toString() ?? '0';

    final isDesktop = MediaQuery.of(context).size.width > 900;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: isDesktop ? 4 : 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: isDesktop ? 1.6 : 1.35,
      children: [
        _buildStatCard('Total Revenue', '\$$revenue', Icons.monetization_on_outlined, Colors.green, onTap: null),
        _buildStatCard('Active Patients', patients, Icons.people_outline_rounded, Colors.blue, onTap: () {
          ref.read(adminNavigationProvider.notifier).setTab(2);
        }),
        _buildStatCard('Certified Doctors', doctors, Icons.medical_services_outlined, Colors.orange, onTap: () {
          ref.read(adminNavigationProvider.notifier).setTab(1);
        }),
        _buildStatCard('Consultations', appointments, Icons.calendar_month_outlined, Colors.indigo, onTap: () {
          ref.read(adminNavigationProvider.notifier).setTab(2);
        }),
      ],
    ).animate().fadeIn(duration: 400.ms).scale(begin: const Offset(0.98, 0.98));
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color, {VoidCallback? onTap}) {
    final isClickable = onTap != null;
    return _HoverPop(
      scaleAmount: 1.04,
      liftAmount: 7.0,
      child: MouseRegion(
        cursor: isClickable ? SystemMouseCursors.click : SystemMouseCursors.basic,
        child: GestureDetector(
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            decoration: BoxDecoration(
              color: darkCard,
              borderRadius: BorderRadius.circular(24.0),
              border: Border.all(color: color.withOpacity(isClickable ? 0.25 : 0.15), width: 1.2),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF1E293B).withOpacity(0.4),
                  const Color(0xFF0F172A).withOpacity(0.8),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(isClickable ? 0.10 : 0.04),
                  blurRadius: isClickable ? 24 : 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              children: [
                Positioned(
                  bottom: -20,
                  right: -20,
                  child: Icon(
                    icon,
                    size: 110,
                    color: color.withOpacity(0.045),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10.0),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.12),
                              shape: BoxShape.circle,
                              border: Border.all(color: color.withOpacity(0.25), width: 1),
                            ),
                            child: Icon(icon, color: color, size: 20),
                          ),
                          Row(
                            children: [
                              if (isClickable)
                                Icon(Icons.arrow_forward_ios_rounded, color: color.withOpacity(0.6), size: 11),
                              const SizedBox(width: 4),
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: color,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: color,
                                      blurRadius: 8,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            value,
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: textPrimary, letterSpacing: -0.5),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Text(
                                title.toUpperCase(),
                                style: const TextStyle(fontSize: 10, color: textSecondary, fontWeight: FontWeight.bold, letterSpacing: 0.8),
                              ),
                              if (isClickable) ...
                                [
                                  const SizedBox(width: 4),
                                  Text(
                                    '• TAP TO VIEW',
                                    style: TextStyle(fontSize: 8, color: color.withOpacity(0.7), fontWeight: FontWeight.bold, letterSpacing: 0.8),
                                  ),
                                ],
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRevenueTimeline(Map<String, dynamic> data) {
    final timeline = data['revenue_timeline'] as List<dynamic>? ?? [];
    if (timeline.isEmpty) return _buildNoDataCard('No revenue data found.');

    final List<FlSpot> spots = [];
    double maxRevenue = 100.0;
    for (int i = 0; i < timeline.length; i++) {
      final rev = double.parse((timeline[i]['revenue'] ?? 0).toString());
      if (rev > maxRevenue) maxRevenue = rev;
      spots.add(FlSpot(i.toDouble(), rev));
    }

    return SizedBox(
      height: 180,
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: false),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 40,
                getTitlesWidget: (value, meta) => Text(
                  '\$${value.toStringAsFixed(0)}',
                  style: const TextStyle(fontSize: 9, color: textSecondary, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  int idx = value.toInt();
                  if (idx >= 0 && idx < timeline.length) {
                    if (idx == 0 || idx == timeline.length ~/ 2 || idx == timeline.length - 1) {
                      String date = timeline[idx]['date'] ?? '';
                      if (date.length >= 10) date = date.substring(5);
                      return SideTitleWidget(
                        axisSide: meta.axisSide,
                        space: 8.0,
                        child: Text(
                          date,
                          style: const TextStyle(fontSize: 9, color: textSecondary, fontWeight: FontWeight.w600),
                        ),
                      );
                    }
                  }
                  return const SizedBox.shrink();
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          minX: 0,
          maxX: (timeline.length - 1).toDouble(),
          minY: 0,
          maxY: maxRevenue * 1.15,
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              color: accentColor,
              barWidth: 3,
              isStrokeCapRound: true,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    accentColor.withOpacity(0.25),
                    accentColor.withOpacity(0.0),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBreakdown(Map<String, dynamic> data) {
    final breakdown = data['status_breakdown'] as Map<String, dynamic>? ?? {};
    final pending = double.parse((breakdown['PENDING'] ?? 0).toString());
    final confirmed = double.parse((breakdown['CONFIRMED'] ?? 0).toString());
    final completed = double.parse((breakdown['COMPLETED'] ?? 0).toString());
    final cancelled = double.parse((breakdown['CANCELLED'] ?? 0).toString());
    final total = pending + confirmed + completed + cancelled;

    if (total == 0) return _buildNoDataCard('No status breakdown available.');

    return Row(
      children: [
        SizedBox(
          width: 110,
          height: 110,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 28,
              sections: [
                if (pending > 0) PieChartSectionData(color: Colors.orange, value: pending, title: '${((pending/total)*100).toStringAsFixed(0)}%', radius: 20, showTitle: true, titleStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                if (confirmed > 0) PieChartSectionData(color: accentColor, value: confirmed, title: '${((confirmed/total)*100).toStringAsFixed(0)}%', radius: 20, showTitle: true, titleStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                if (completed > 0) PieChartSectionData(color: Colors.green, value: completed, title: '${((completed/total)*100).toStringAsFixed(0)}%', radius: 20, showTitle: true, titleStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                if (cancelled > 0) PieChartSectionData(color: Colors.redAccent, value: cancelled, title: '${((cancelled/total)*100).toStringAsFixed(0)}%', radius: 20, showTitle: true, titleStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: Column(
            children: [
              _buildLegendItem(Colors.green, 'Completed', completed.toInt()),
              const SizedBox(height: 6),
              _buildLegendItem(accentColor, 'Confirmed', confirmed.toInt()),
              const SizedBox(height: 6),
              _buildLegendItem(Colors.orange, 'Pending', pending.toInt()),
              const SizedBox(height: 6),
              _buildLegendItem(Colors.redAccent, 'Cancelled', cancelled.toInt()),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSpecialtyBreakdown(Map<String, dynamic> data) {
    final breakdown = data['specialty_breakdown'] as Map<String, dynamic>? ?? {};
    if (breakdown.isEmpty) return _buildNoDataCard('No specialties available.');

    final List<Color> colors = [Colors.teal, Colors.indigo, Colors.orange, Colors.purple, Colors.pink, Colors.blue];
    double total = 0;
    breakdown.forEach((key, val) => total += double.parse(val.toString()));

    int colorIdx = 0;
    final List<PieChartSectionData> sections = [];
    final List<Widget> legendItems = [];

    breakdown.forEach((spec, val) {
      final value = double.parse(val.toString());
      final color = colors[colorIdx % colors.length];
      colorIdx++;

      sections.add(
        PieChartSectionData(
          color: color,
          value: value,
          title: '${((value / total) * 100).toStringAsFixed(0)}%',
          radius: 20,
          showTitle: true,
          titleStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      );

      legendItems.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 6.0),
          child: Row(
            children: [
              Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  spec,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: textPrimary),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                value.toInt().toString(),
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textSecondary),
              ),
            ],
          ),
        ),
      );
    });

    return Row(
      children: [
        SizedBox(
          width: 110,
          height: 110,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 28,
              sections: sections,
            ),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: legendItems,
          ),
        ),
      ],
    );
  }

  Widget _buildAgeDemographics(Map<String, dynamic> data) {
    final ageDemo = data['age_demographics'] as Map<String, dynamic>? ?? {};
    if (ageDemo.isEmpty) return _buildNoDataCard('No age demographics data.');

    final ageKeys = ['Under 18', '18-35', '36-50', '50+'];
    List<BarChartGroupData> barGroups = [];
    double maxVal = 5.0;

    for (int i = 0; i < ageKeys.length; i++) {
      final val = double.parse((ageDemo[ageKeys[i]] ?? 0).toString());
      if (val > maxVal) maxVal = val;

      barGroups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(
              toY: val,
              color: accentColor,
              width: 16,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(4),
              ),
            ),
          ],
        ),
      );
    }

    return SizedBox(
      height: 160,
      child: BarChart(
        BarChartData(
          gridData: const FlGridData(show: false),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 24,
                getTitlesWidget: (value, meta) => Text(
                  value.toInt().toString(),
                  style: const TextStyle(fontSize: 9, color: textSecondary, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  int idx = value.toInt();
                  if (idx >= 0 && idx < ageKeys.length) {
                    return SideTitleWidget(
                      axisSide: meta.axisSide,
                      space: 6.0,
                      child: Text(
                        ageKeys[idx],
                        style: const TextStyle(fontSize: 9, color: textSecondary, fontWeight: FontWeight.bold),
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          barGroups: barGroups,
          maxY: maxVal * 1.2,
        ),
      ),
    );
  }

  Widget _buildBloodGroupShares(Map<String, dynamic> data) {
    final bloodData = data['blood_group_breakdown'] as Map<String, dynamic>? ?? {};
    if (bloodData.isEmpty) return _buildNoDataCard('No blood group breakdown.');

    final List<Widget> items = [];
    bloodData.forEach((group, val) {
      final count = val.toInt();
      items.add(
        _HoverPop(
          scaleAmount: 1.025,
          liftAmount: 5.0,
          child: MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GestureDetector(
            onTap: () {
              ref.read(adminNavigationProvider.notifier).searchPatientsWithQuery(group);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              margin: const EdgeInsets.symmetric(vertical: 4.0),
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 10.0),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.04),
                borderRadius: BorderRadius.circular(12.0),
                border: Border.all(color: Colors.redAccent.withOpacity(0.10), width: 1),
              ),
              child: Row(
                children: [
                  Container(
                    alignment: Alignment.center,
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(color: Colors.redAccent.withOpacity(0.25), width: 1),
                    ),
                    child: Text(
                      group,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.redAccent),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Blood Group $group',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textPrimary),
                        ),
                        Text(
                          'Tap to filter patients',
                          style: TextStyle(fontSize: 10, color: Colors.redAccent.withOpacity(0.7), fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.redAccent.withOpacity(0.2), width: 1),
                    ),
                    child: Text(
                      '$count Profiles',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.redAccent),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Icons.arrow_forward_ios_rounded, color: Colors.redAccent.withOpacity(0.5), size: 12),
                ],
              ),
            ),
          ),
        ),
      ), // closes _HoverPop
      );
    });

    return Column(children: items);
  }

  Widget _buildLegendItem(Color color, String label, int value) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: textPrimary),
        ),
        const Spacer(),
        Text(
          value.toString(),
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textSecondary),
        ),
      ],
    );
  }

  Widget _buildNoDataCard(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 24.0),
        child: Text(
          message,
          style: const TextStyle(color: textSecondary, fontSize: 13),
        ),
      ),
    );
  }

  Widget _buildErrorWidget(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 60, color: Colors.redAccent),
            const SizedBox(height: 16),
            const Text(
              'Error Loading Analytics',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.redAccent),
            ),
            const SizedBox(height: 8),
            Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: textSecondary),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => ref.read(adminAnalyticsProvider.notifier).fetchAnalytics(),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Try Again', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
