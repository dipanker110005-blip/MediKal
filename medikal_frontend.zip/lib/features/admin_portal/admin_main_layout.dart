import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'admin_provider.dart';
import 'admin_dashboard_screen.dart';
import 'admin_doctors_screen.dart';
import 'admin_patients_screen.dart';
import '../profile/profile_screen.dart';

class AdminMainLayout extends ConsumerStatefulWidget {
  const AdminMainLayout({super.key});

  @override
  ConsumerState<AdminMainLayout> createState() => _AdminMainLayoutState();
}

class _AdminMainLayoutState extends ConsumerState<AdminMainLayout> {
  // Track hover state per tab
  final List<bool> _hoveredTabs = [false, false, false, false];

  final List<Widget> _screens = const [
    AdminDashboardScreen(),
    AdminDoctorsScreen(),
    AdminPatientsScreen(),
    ProfileScreen(),
  ];

  // Local Premium Dark Theme Configurations
  static const Color darkBackground = Color(0xFF090D16);
  static const Color darkCard = Color(0xFF111827);
  static const Color accentColor = Color(0xFF10B981); // Emerald
  static const Color textSecondary = Color(0xFF9CA3AF);

  @override
  Widget build(BuildContext context) {
    final navState = ref.watch(adminNavigationProvider);
    final currentIndex = navState.currentIndex;

    return Scaffold(
      backgroundColor: darkBackground,
      body: Stack(
        children: [
          Positioned.fill(
            child: IndexedStack(
              index: currentIndex,
              children: _screens,
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 20,
            child: Container(
              height: 72,
              decoration: BoxDecoration(
                color: darkCard,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.24),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: Row(
                  children: [
                    _buildNavItem(0, Icons.analytics_rounded, Icons.analytics_outlined, 'Overview'),
                    _buildNavItem(1, Icons.medical_services_rounded, Icons.medical_services_outlined, 'Doctors'),
                    _buildNavItem(2, Icons.people_rounded, Icons.people_outline_rounded, 'Patients'),
                    _buildNavItem(3, Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(int index, IconData activeIcon, IconData inactiveIcon, String label) {
    final currentIndex = ref.watch(adminNavigationProvider).currentIndex;
    final isSelected = currentIndex == index;
    final isHovered = _hoveredTabs[index];
    final itemColor = isSelected
        ? accentColor
        : isHovered
            ? Colors.white
            : textSecondary;

    return Expanded(
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hoveredTabs[index] = true),
        onExit: (_) => setState(() => _hoveredTabs[index] = false),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            ref.read(adminNavigationProvider.notifier).setTab(index);
          },
          child: AnimatedSlide(
            offset: isHovered && !isSelected ? const Offset(0, -0.18) : Offset.zero,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            child: AnimatedScale(
              scale: isHovered && !isSelected ? 1.18 : 1.0,
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOutCubic,
              child: Center(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: isSelected
                      ? BoxDecoration(
                          color: accentColor.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: accentColor.withOpacity(0.20), width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: accentColor.withOpacity(0.15),
                              blurRadius: 12,
                              spreadRadius: 0,
                            ),
                          ],
                        )
                      : isHovered
                          ? BoxDecoration(
                              color: Colors.white.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.white.withOpacity(0.10), width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white.withOpacity(0.04),
                                  blurRadius: 10,
                                  spreadRadius: 0,
                                ),
                              ],
                            )
                          : null,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 150),
                        child: Icon(
                          isSelected || isHovered ? activeIcon : inactiveIcon,
                          key: ValueKey('${index}_${isSelected || isHovered}'),
                          color: itemColor,
                          size: isHovered && !isSelected ? 22 : 20,
                        ),
                      ),
                      const SizedBox(height: 4),
                      AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 180),
                        style: TextStyle(
                          fontSize: isHovered && !isSelected ? 11 : 10,
                          fontWeight: isSelected
                              ? FontWeight.w800
                              : isHovered
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                          color: itemColor,
                        ),
                        child: Text(
                          label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
