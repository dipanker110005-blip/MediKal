import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'admin_repository.dart';

class AdminAnalyticsState {
  final Map<String, dynamic> data;
  final bool isLoading;
  final String? error;

  AdminAnalyticsState({
    required this.data,
    required this.isLoading,
    this.error,
  });

  factory AdminAnalyticsState.initial() => AdminAnalyticsState(
        data: {},
        isLoading: false,
        error: null,
      );

  AdminAnalyticsState copyWith({
    Map<String, dynamic>? data,
    bool? isLoading,
    String? error,
  }) {
    return AdminAnalyticsState(
      data: data ?? this.data,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class AdminAnalyticsNotifier extends StateNotifier<AdminAnalyticsState> {
  final AdminRepository _repository;

  AdminAnalyticsNotifier(this._repository) : super(AdminAnalyticsState.initial()) {
    fetchAnalytics();
  }

  Future<void> fetchAnalytics() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final analytics = await _repository.fetchAnalytics();
      state = state.copyWith(data: analytics, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
}

final adminAnalyticsProvider =
    StateNotifierProvider<AdminAnalyticsNotifier, AdminAnalyticsState>((ref) {
  final repository = ref.read(adminRepositoryProvider);
  return AdminAnalyticsNotifier(repository);
});

class PendingDoctorsState {
  final List<dynamic> doctors;
  final bool isLoading;
  final String? error;

  PendingDoctorsState({
    required this.doctors,
    required this.isLoading,
    this.error,
  });

  factory PendingDoctorsState.initial() => PendingDoctorsState(
        doctors: [],
        isLoading: false,
        error: null,
      );

  PendingDoctorsState copyWith({
    List<dynamic>? doctors,
    bool? isLoading,
    String? error,
  }) {
    return PendingDoctorsState(
      doctors: doctors ?? this.doctors,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class PendingDoctorsNotifier extends StateNotifier<PendingDoctorsState> {
  final AdminRepository _repository;
  final Ref _ref;

  PendingDoctorsNotifier(this._repository, this._ref) : super(PendingDoctorsState.initial()) {
    fetchPendingDoctors();
  }

  Future<void> fetchPendingDoctors() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final doctors = await _repository.fetchPendingDoctors();
      state = state.copyWith(doctors: doctors, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<bool> verifyDoctor(int doctorId, String status) async {
    try {
      await _repository.verifyDoctor(doctorId, status);
      fetchPendingDoctors();
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      // If we have doctor lists provider active, reload it too
      _ref.read(adminDoctorsProvider.notifier).fetchDoctors();
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString());
      return false;
    }
  }
}

final pendingDoctorsProvider =
    StateNotifierProvider<PendingDoctorsNotifier, PendingDoctorsState>((ref) {
  final repository = ref.read(adminRepositoryProvider);
  return PendingDoctorsNotifier(repository, ref);
});

class AdminDoctorsState {
  final List<dynamic> doctors;
  final bool isLoading;
  final String? error;

  AdminDoctorsState({
    required this.doctors,
    required this.isLoading,
    this.error,
  });

  factory AdminDoctorsState.initial() => AdminDoctorsState(
        doctors: [],
        isLoading: false,
        error: null,
      );

  AdminDoctorsState copyWith({
    List<dynamic>? doctors,
    bool? isLoading,
    String? error,
  }) {
    return AdminDoctorsState(
      doctors: doctors ?? this.doctors,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class AdminDoctorsNotifier extends StateNotifier<AdminDoctorsState> {
  final AdminRepository _repository;
  final Ref _ref;

  AdminDoctorsNotifier(this._repository, this._ref) : super(AdminDoctorsState.initial()) {
    fetchDoctors();
  }

  Future<void> fetchDoctors() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final doctors = await _repository.fetchDoctors();
      state = state.copyWith(doctors: doctors, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<String?> addDoctor(Map<String, dynamic> data) async {
    try {
      await _repository.addDoctor(data);
      await fetchDoctors();
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      return null;
    } catch (e) {
      return e.toString().replaceAll('Exception: ', '');
    }
  }

  Future<String?> updateDoctor(int id, Map<String, dynamic> data) async {
    try {
      await _repository.updateDoctor(id, data);
      await fetchDoctors();
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      return null;
    } catch (e) {
      return e.toString().replaceAll('Exception: ', '');
    }
  }

  Future<String?> deleteDoctor(int id) async {
    final previousDoctors = state.doctors;
    state = state.copyWith(doctors: state.doctors.where((d) => d['id'] != id).toList());
    try {
      await _repository.deleteDoctor(id);
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      return null;
    } catch (e) {
      state = state.copyWith(doctors: previousDoctors);
      return e.toString().replaceAll('Exception: ', '');
    }
  }
}

final adminDoctorsProvider =
    StateNotifierProvider<AdminDoctorsNotifier, AdminDoctorsState>((ref) {
  final repository = ref.read(adminRepositoryProvider);
  return AdminDoctorsNotifier(repository, ref);
});

class AdminPatientsState {
  final List<dynamic> patients;
  final bool isLoading;
  final String? error;

  AdminPatientsState({
    required this.patients,
    required this.isLoading,
    this.error,
  });

  factory AdminPatientsState.initial() => AdminPatientsState(
        patients: [],
        isLoading: false,
        error: null,
      );

  AdminPatientsState copyWith({
    List<dynamic>? patients,
    bool? isLoading,
    String? error,
  }) {
    return AdminPatientsState(
      patients: patients ?? this.patients,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class AdminPatientsNotifier extends StateNotifier<AdminPatientsState> {
  final AdminRepository _repository;
  final Ref _ref;

  AdminPatientsNotifier(this._repository, this._ref) : super(AdminPatientsState.initial()) {
    fetchPatients();
  }

  Future<void> fetchPatients() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final patients = await _repository.fetchPatients();
      state = state.copyWith(patients: patients, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<String?> updatePatient(int id, Map<String, dynamic> data) async {
    try {
      await _repository.updatePatient(id, data);
      await fetchPatients();
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      return null;
    } catch (e) {
      return e.toString().replaceAll('Exception: ', '');
    }
  }

  Future<String?> deletePatient(int id) async {
    final previousPatients = state.patients;
    state = state.copyWith(patients: state.patients.where((p) => p['id'] != id).toList());
    try {
      await _repository.deletePatient(id);
      _ref.read(adminAnalyticsProvider.notifier).fetchAnalytics();
      return null;
    } catch (e) {
      state = state.copyWith(patients: previousPatients);
      return e.toString().replaceAll('Exception: ', '');
    }
  }
}

final adminPatientsProvider =
    StateNotifierProvider<AdminPatientsNotifier, AdminPatientsState>((ref) {
  final repository = ref.read(adminRepositoryProvider);
  return AdminPatientsNotifier(repository, ref);
});

class AdminNavigationState {
  final int currentIndex;
  final String patientSearchQuery;

  AdminNavigationState({
    required this.currentIndex,
    required this.patientSearchQuery,
  });

  AdminNavigationState copyWith({
    int? currentIndex,
    String? patientSearchQuery,
  }) {
    return AdminNavigationState(
      currentIndex: currentIndex ?? this.currentIndex,
      patientSearchQuery: patientSearchQuery ?? this.patientSearchQuery,
    );
  }
}

class AdminNavigationNotifier extends StateNotifier<AdminNavigationState> {
  AdminNavigationNotifier()
      : super(AdminNavigationState(currentIndex: 0, patientSearchQuery: ''));

  void setTab(int index) {
    state = state.copyWith(currentIndex: index);
  }

  void searchPatientsWithQuery(String query) {
    state = AdminNavigationState(currentIndex: 2, patientSearchQuery: query);
  }
}

final adminNavigationProvider =
    StateNotifierProvider<AdminNavigationNotifier, AdminNavigationState>((ref) {
  return AdminNavigationNotifier();
});
