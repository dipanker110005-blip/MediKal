import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'ai_repository.dart';

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class AIChatState {
  final List<ChatMessage> messages;
  final bool isLoading;

  AIChatState({
    required this.messages,
    this.isLoading = false,
  });

  AIChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
  }) {
    return AIChatState(
      messages: messages ?? this.messages,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

class AIChatNotifier extends StateNotifier<AIChatState> {
  final AIRepository _repository;

  AIChatNotifier(this._repository)
      : super(AIChatState(
          messages: [
            ChatMessage(
              text: "Hi! I'm MediKal AI. How can I help you today?",
              isUser: false,
              timestamp: DateTime.now(),
            ),
          ],
        ));
  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    // Map history before adding the user message
    final history = state.messages.map((msg) => {
      'is_user': msg.isUser,
      'text': msg.text,
    }).toList();

    // 1. Add user message
    final userMsg = ChatMessage(
      text: text,
      isUser: true,
      timestamp: DateTime.now(),
    );
    
    state = state.copyWith(
      messages: [...state.messages, userMsg],
      isLoading: true,
    );

    // 2. Fetch AI response
    try {
      final aiResponseText = await _repository.sendChatMessage(text, history);
      
      final aiMsg = ChatMessage(
        text: aiResponseText,
        isUser: false,
        timestamp: DateTime.now(),
      );

      state = state.copyWith(
        messages: [...state.messages, aiMsg],
        isLoading: false,
      );
    } catch (e) {
      final errMsg = ChatMessage(
        text: "Error: ${e.toString().replaceAll('Exception: ', '')}",
        isUser: false,
        timestamp: DateTime.now(),
      );

      state = state.copyWith(
        messages: [...state.messages, errMsg],
        isLoading: false,
      );
    }
  }

  void clearChat() {
    state = AIChatState(
      messages: [
        ChatMessage(
          text: "Hi! I'm MediKal AI. How can I help you today?",
          isUser: false,
          timestamp: DateTime.now(),
        ),
      ],
    );
  }
}

// Expose the state notifier
final aiChatProvider = StateNotifierProvider<AIChatNotifier, AIChatState>((ref) {
  final repository = ref.read(aiRepositoryProvider);
  return AIChatNotifier(repository);
});
