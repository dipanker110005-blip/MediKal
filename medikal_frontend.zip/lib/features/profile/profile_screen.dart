import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../auth/auth_provider.dart';
import '../landing/landing_screen.dart';
import 'profile_provider.dart';
import 'saved_items_screen.dart';
import 'billing_insurance_screen.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(profileProvider.notifier).fetchProfile();
    });
  }

  void _handleLogout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: AppTheme.borderXL),
        title: Text('Logout', style: AppTheme.h3),
        content: Text('Are you sure you want to logout of MediKal?', style: AppTheme.bodyMedium),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: AppColors.emergency),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await ref.read(authProvider.notifier).logout();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LandingScreen()),
          (route) => false,
        );
      }
    }
  }

  void _showEditSheet(Map<String, dynamic> user, Map<String, dynamic>? profile) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(text: user['full_name']);
    final phoneController = TextEditingController(text: user['phone']);
    final ageController = TextEditingController(text: profile?['age']?.toString() ?? '');
    final addressController = TextEditingController(text: profile?['address'] ?? '');
    final emergencyController = TextEditingController(text: profile?['emergency_contact'] ?? '');
    String? selectedBloodGroup = profile?['blood_group'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.0)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: StatefulBuilder(
            builder: (context, setModalState) {
              return Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Edit Profile Details',
                            style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      TextFormField(
                        controller: nameController,
                        style: AppTheme.bodyMedium,
                        decoration: const InputDecoration(
                          labelText: 'Full Name',
                          prefixIcon: Icon(Icons.person_outline_rounded, color: AppColors.primary, size: 20),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) return 'Please enter your name';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),

                      TextFormField(
                        controller: phoneController,
                        keyboardType: TextInputType.phone,
                        style: AppTheme.bodyMedium,
                        decoration: const InputDecoration(
                          labelText: 'Phone Number',
                          prefixIcon: Icon(Icons.phone_outlined, color: AppColors.primary, size: 20),
                        ),
                      ),
                      const SizedBox(height: 16),

                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: ageController,
                              keyboardType: TextInputType.number,
                              style: AppTheme.bodyMedium,
                              decoration: const InputDecoration(
                                labelText: 'Age',
                                prefixIcon: Icon(Icons.cake_outlined, color: AppColors.primary, size: 18),
                              ),
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) return 'Required';
                                final ageNum = int.tryParse(value);
                                if (ageNum == null || ageNum <= 0) return 'Invalid';
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),

                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: selectedBloodGroup,
                              style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary),
                              decoration: const InputDecoration(
                                labelText: 'Blood Group',
                                prefixIcon: Icon(Icons.water_drop_outlined, color: AppColors.emergency, size: 18),
                              ),
                              items: const ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
                                  .map((group) => DropdownMenuItem(value: group, child: Text(group)))
                                  .toList(),
                              onChanged: (val) {
                                setModalState(() {
                                  selectedBloodGroup = val;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      TextFormField(
                        controller: addressController,
                        maxLines: 2,
                        style: AppTheme.bodyMedium,
                        decoration: const InputDecoration(
                          labelText: 'Home Address',
                          prefixIcon: Padding(
                            padding: EdgeInsets.only(bottom: 24.0),
                            child: Icon(Icons.location_on_outlined, color: AppColors.primary, size: 20),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      TextFormField(
                        controller: emergencyController,
                        keyboardType: TextInputType.phone,
                        style: AppTheme.bodyMedium,
                        decoration: const InputDecoration(
                          labelText: 'Emergency Contact Phone',
                          prefixIcon: Icon(Icons.contact_phone_outlined, color: AppColors.primary, size: 20),
                        ),
                      ),
                      const SizedBox(height: 24),

                      ElevatedButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate()) {
                            final updateData = {
                              'full_name': nameController.text.trim(),
                              'phone': phoneController.text.trim(),
                              'age': int.parse(ageController.text.trim()),
                              'blood_group': selectedBloodGroup,
                              'address': addressController.text.trim(),
                              'emergency_contact': emergencyController.text.trim(),
                            };
                            final success = await ref.read(profileProvider.notifier).updateProfile(updateData);
                            if (success && context.mounted) {
                              Navigator.of(context).pop();
                            }
                          }
                        },
                        child: const Text('Save Profile Changes'),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(profileProvider);

    ref.listen(profileProvider, (previous, next) {
      if (next.successMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.successMessage!), 
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
        ref.read(profileProvider.notifier).clearMessage();
      } else if (next.error != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.error!), 
            backgroundColor: AppColors.emergency,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
        ref.read(profileProvider.notifier).clearMessage();
      }
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          'My Profile',
          style: AppTheme.h3.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: state.isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 800),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(24.0, 20.0, 24.0, 110.0),
                    child: Column(
                      children: [
                        _buildProfileHeader(state.user),
                        const SizedBox(height: 32),

                        _buildDetailsSection(state.user, state.profile),
                        const SizedBox(height: 24),
                        _buildPreferencesSection(),
                        const SizedBox(height: 32),

                        if (state.user != null)
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () => _showEditSheet(state.user!, state.profile),
                              icon: const Icon(Icons.edit_rounded, color: AppColors.primary, size: 20),
                              label: const Text('Edit Profile Details'),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: AppColors.primary, width: 1.5),
                                shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
                                padding: const EdgeInsets.symmetric(vertical: 16),
                              ),
                            ),
                          )
                              .animate()
                              .fadeIn(delay: 200.ms, duration: 400.ms),
                        
                        const SizedBox(height: 16),

                        SizedBox(
                          width: double.infinity,
                          child: TextButton.icon(
                            onPressed: _handleLogout,
                            icon: const Icon(Icons.logout_rounded, color: AppColors.emergency, size: 20),
                            label: const Text('Logout from App'),
                            style: TextButton.styleFrom(
                              shape: RoundedRectangleBorder(borderRadius: AppTheme.borderM),
                              foregroundColor: AppColors.emergency,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                          ),
                        )
                            .animate()
                            .fadeIn(delay: 250.ms, duration: 400.ms),
                      ],
                    ),
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildProfileHeader(Map<String, dynamic>? user) {
    if (user == null) return const SizedBox();
    final name = user['full_name'] ?? 'User';
    final email = user['email'] ?? '';
    final initials = name.isNotEmpty ? name[0].toUpperCase() : 'U';

    return Center(
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.primary.withOpacity(0.2), width: 2),
              boxShadow: AppTheme.shadowSubtle,
            ),
            child: CircleAvatar(
              radius: 48,
              backgroundColor: AppColors.primaryLight,
              child: Text(
                initials,
                style: AppTheme.h1.copyWith(fontSize: 34, color: AppColors.primary, fontWeight: FontWeight.w800),
              ),
            ),
          )
              .animate()
              .fadeIn(duration: 400.ms)
              .scale(begin: const Offset(0.9, 0.9)),
          const SizedBox(height: 16),
          Text(
            name,
            style: AppTheme.h2.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            email,
            style: AppTheme.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 6.0),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: Text(
              'PATIENT PORTAL',
              style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.primary, letterSpacing: 0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailsSection(Map<String, dynamic>? user, Map<String, dynamic>? profile) {
    if (user == null) return const SizedBox();

    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderXL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowCard,
      ),
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Account & Clinical Info',
            style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          _buildInfoRow(Icons.phone_outlined, 'Phone Number', user['phone'] ?? 'Not Provided', AppColors.primary),
          const Divider(color: AppColors.border, height: 24),
          _buildInfoRow(Icons.cake_outlined, 'Age', profile?['age']?.toString() ?? 'Not Provided', AppColors.primary),
          const Divider(color: AppColors.border, height: 24),
          _buildInfoRow(Icons.water_drop_outlined, 'Blood Group', profile?['blood_group'] ?? 'Not Provided', AppColors.emergency),
          const Divider(color: AppColors.border, height: 24),
          _buildInfoRow(Icons.location_on_outlined, 'Home Address', profile?['address'] ?? 'Not Provided', AppColors.primary),
          const Divider(color: AppColors.border, height: 24),
          _buildInfoRow(Icons.contact_phone_outlined, 'Emergency Contact Phone', profile?['emergency_contact'] ?? 'Not Provided', AppColors.primary),
        ],
      ),
    )
        .animate()
        .fadeIn(delay: 150.ms, duration: 450.ms)
        .slideY(begin: 0.04);
  }

  Widget _buildPreferencesSection() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppTheme.borderXL,
        border: Border.all(color: AppColors.border),
        boxShadow: AppTheme.shadowCard,
      ),
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Preferences & Insurance',
            style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.bookmark_outline_rounded, size: 18, color: AppColors.primary),
            ),
            title: Text('Saved Items', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600)),
            subtitle: Text('Favorite doctors, medicines, and clinics', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SavedItemsScreen()),
              );
            },
          ),
          const Divider(color: AppColors.border),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.shield_outlined, size: 18, color: Colors.blue.shade700),
            ),
            title: Text('Insurance & Billing', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600)),
            subtitle: Text('Policy card details, coverage, and invoices', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const BillingInsuranceScreen()),
              );
            },
          ),
          const Divider(color: AppColors.border),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.language_rounded, size: 18, color: Colors.amber.shade800),
            ),
            title: Text('Language Preference', style: AppTheme.bodyMedium.copyWith(fontWeight: FontWeight.w600)),
            subtitle: Text('Select your preferred display language', style: AppTheme.bodySmall.copyWith(color: AppColors.textSecondary)),
            trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
            onTap: () {
              _showLanguageSelector();
            },
          ),
        ],
      ),
    ).animate().fadeIn(delay: 200.ms, duration: 450.ms).slideY(begin: 0.04);
  }

  void _showLanguageSelector() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Language Preference', style: AppTheme.h4.copyWith(fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildLanguageOption('English (US)'),
            _buildLanguageOption('Hindi (हिन्दी)'),
            _buildLanguageOption('Spanish (Español)'),
            _buildLanguageOption('French (Français)'),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageOption(String lang) {
    return ListTile(
      title: Text(lang, style: AppTheme.bodyMedium),
      onTap: () {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Display language set to $lang'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, Color themeColor) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: themeColor.withOpacity(0.08),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 18, color: themeColor),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label.toUpperCase(),
                style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textSecondary, letterSpacing: 0.5),
              ),
              const SizedBox(height: 4),
              Text(
                value.isNotEmpty ? value : 'Not Provided',
                style: AppTheme.bodyMedium.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
