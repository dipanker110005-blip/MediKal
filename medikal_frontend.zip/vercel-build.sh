#!/bin/bash
set -e

echo "=== Downloading Flutter SDK ==="
curl -O https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.22.2-stable.tar.xz

echo "=== Extracting Flutter SDK ==="
tar -xf flutter_linux_3.22.2-stable.tar.xz

# Add flutter to PATH
export PATH="$PATH:$(pwd)/flutter/bin"

echo "=== Configuring Flutter ==="
flutter config --enable-web --no-analytics

echo "=== Generating Web Platform Files ==="
flutter create --platforms=web .

echo "=== Building Web App ==="
flutter build web --release

echo "=== Cleaning up SDK ==="
rm -rf flutter_linux_3.22.2-stable.tar.xz
rm -rf flutter/

echo "=== Build Complete ==="
